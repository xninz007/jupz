const COLORS = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  green: '\x1b[32m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
};

function timestamp() {
  return new Date().toISOString().replace('T', ' ').slice(0, 19);
}

function formatMsg(level, color, ...args) {
  const ts = `${COLORS.gray}[${timestamp()}]${COLORS.reset}`;
  const tag = `${color}[${level}]${COLORS.reset}`;
  console.log(ts, tag, ...args);
}

const logger = {
  info: (...args) => formatMsg('INFO', COLORS.green, ...args),
  warn: (...args) => formatMsg('WARN', COLORS.yellow, ...args),
  error: (...args) => formatMsg('ERROR', COLORS.red, ...args),
  debug: (...args) => formatMsg('DEBUG', COLORS.cyan, ...args),
};

export default logger;
