import { PublicKey } from '@solana/web3.js';
import { getAssociatedTokenAddressSync } from '@solana/spl-token';
import axios from 'axios';
import config from '../../config.js';
import logger from './logger.js';

// Jupiter API headers
function jupiterHeaders() {
  const headers = { 'Content-Type': 'application/json' };
  if (config.jupiterApiKey) headers['x-api-key'] = config.jupiterApiKey;
  return headers;
}

// Rotate API keys khusus Mode 6 price monitoring
let priceKeyIndex = 0;
export function jupiterPriceHeaders() {
  const keys = config.jupiterPriceApiKeys;
  if (keys.length > 0) {
    const key = keys[priceKeyIndex % keys.length];
    priceKeyIndex++;
    return { 'Content-Type': 'application/json', 'x-api-key': key };
  }
  return jupiterHeaders();
}

// In-memory metadata cache (mint -> metadata)
const metadataCache = new Map();

/**
 * Delay execution.
 * @param {number} ms - milliseconds to sleep
 */
export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Retry a function with exponential backoff.
 * @param {Function} fn - async function to retry
 * @param {number} maxRetries - max attempts (default 3)
 * @param {number} baseDelay - initial delay in ms (default 1000)
 */
export async function retry(fn, maxRetries = 3, baseDelay = 1000) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      if (attempt === maxRetries) throw err;
      const delay = baseDelay * 2 ** (attempt - 1);
      logger.warn(`Attempt ${attempt}/${maxRetries} failed: ${err.message}. Retrying in ${delay}ms...`);
      await sleep(delay);
    }
  }
}

/**
 * Format lamports to SOL string.
 * @param {number|bigint} lamports
 * @returns {string}
 */
export function formatSOL(lamports) {
  return (Number(lamports) / 1e9).toFixed(6);
}

/**
 * Format token amount with decimals.
 * @param {number|bigint} raw - raw token amount
 * @param {number} decimals - token decimals
 * @returns {string}
 */
export function formatToken(raw, decimals = 9) {
  return (Number(raw) / 10 ** decimals).toFixed(decimals > 6 ? 6 : decimals);
}

/**
 * Shorten a Solana public key for display.
 * @param {string|import('@solana/web3.js').PublicKey} pubkey
 * @returns {string}
 */
export function shortenAddress(pubkey) {
  const s = pubkey.toString();
  return `${s.slice(0, 4)}...${s.slice(-4)}`;
}

/**
 * Get SPL token balance for a wallet.
 * @param {import('@solana/web3.js').Connection} connection
 * @param {import('@solana/web3.js').PublicKey} walletPubkey
 * @param {string} mintAddress - token mint address
 * @returns {Promise<bigint>} raw token amount
 */
export async function getTokenBalance(connection, walletPubkey, mintAddress) {
  try {
    // Cek SEMUA token accounts untuk mint ini (tidak hanya ATA)
    const accounts = await connection.getParsedTokenAccountsByOwner(
      walletPubkey,
      { mint: new PublicKey(mintAddress) }
    );
    let total = 0n;
    for (const { account } of accounts.value) {
      total += BigInt(account.data.parsed.info.tokenAmount.amount);
    }
    return total;
  } catch {
    return 0n;
  }
}

/**
 * Get native SOL balance (minus reserve for gas).
 * @param {import('@solana/web3.js').Connection} connection
 * @param {import('@solana/web3.js').PublicKey} walletPubkey
 * @param {number} reserveLamports - SOL to keep for gas fees (default 0.01 SOL)
 * @returns {Promise<bigint>} available lamports
 */
export async function getSOLBalance(connection, walletPubkey, reserveLamports = 10_000_000) {
  const balance = await connection.getBalance(walletPubkey);
  const available = balance - reserveLamports;
  return available > 0 ? BigInt(available) : 0n;
}

/**
 * Fetch token metadata dari Jupiter API.
 * Returns map of mint -> { mint, name, symbol, decimals, price, tokenProgram, image }
 *
 * @param {string[]} mints - array of mint addresses
 * @returns {Promise<Object>} metadata map
 */
export async function fetchTokenMetadata(mints) {
  // Return dari cache jika semua sudah ada
  const allCached = mints.every((m) => metadataCache.has(m));
  if (allCached) {
    const result = {};
    for (const m of mints) result[m] = metadataCache.get(m);
    return result;
  }

  try {
    const { data } = await axios.get(
      `https://api.jup.ag/tokens/v2/search?query=${mints.join(',')}`,
      { headers: jupiterHeaders(), timeout: 10000 }
    );

    const metadataMap = {};
    for (const tm of data) {
      const entry = {
        mint: tm.id,
        name: tm.name || 'Unknown Token',
        symbol: tm.symbol || 'UNK',
        decimals: tm.decimals ?? 6,
        price: tm.usdPrice || 0,
        tokenProgram: tm.tokenProgram || 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',
        image: tm.icon,
      };
      metadataMap[tm.id] = entry;
      metadataCache.set(tm.id, entry);
    }

    // Fallback: SOL metadata (selalu ada)
    if (mints.includes('So11111111111111111111111111111111111111112') && !metadataMap['So11111111111111111111111111111111111111112']) {
      const sol = { mint: 'So11111111111111111111111111111111111111112', name: 'Wrapped SOL', symbol: 'SOL', decimals: 9, price: 0, tokenProgram: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA' };
      metadataMap[sol.mint] = sol;
      metadataCache.set(sol.mint, sol);
    }

    return metadataMap;
  } catch (err) {
    logger.warn(`fetchTokenMetadata failed: ${err.message}`);
    return {};
  }
}

/**
 * Fetch token prices dari Jupiter Price API.
 *
 * @param {string[]} mints - array of mint addresses
 * @returns {Promise<Object>} map of mint -> usd price (number)
 */
export async function fetchTokenPrices(mints) {
  try {
    const { data } = await axios.get(
      `https://api.jup.ag/price/v3?ids=${mints.join(',')}`,
      { headers: jupiterHeaders(), timeout: 8000 }
    );

    const prices = {};
    for (const mint of mints) {
      prices[mint] = data?.[mint]?.usdPrice || 0;
    }
    return prices;
  } catch (err) {
    logger.warn(`fetchTokenPrices failed: ${err.message}`);
    return {};
  }
}

/**
 * Fetch token prices dengan rotate API key — khusus Mode 6.
 */
export async function fetchTokenPricesRotate(mints) {
  try {
    const { data } = await axios.get(
      `https://api.jup.ag/price/v3?ids=${mints.join(',')}`,
      { headers: jupiterPriceHeaders(), timeout: 8000 }
    );

    const prices = {};
    for (const mint of mints) {
      prices[mint] = data?.[mint]?.usdPrice || 0;
    }
    return prices;
  } catch (err) {
    logger.warn(`fetchTokenPricesRotate failed: ${err.message}`);
    return {};
  }
}

/**
 * Format raw amount ke human-readable string pakai decimals dari metadata.
 * Contoh: 28972526 dengan decimals=6 → "28.972526"
 *
 * @param {bigint|number|string} rawAmount
 * @param {number} decimals
 * @returns {string}
 */
export function formatHuman(rawAmount, decimals) {
  const num = Number(rawAmount) / 10 ** decimals;
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(2)}M`;
  if (num >= 1_000) return `${(num / 1_000).toFixed(2)}K`;
  if (num >= 1) return num.toFixed(4);
  if (num >= 0.0001) return num.toFixed(6);
  return num.toExponential(4);
}

/**
 * Resolve bin range config ke jumlah bins.
 * 'full' = 70, 'half' = 35, 'tight' = 10, atau angka langsung.
 */
const BIN_RANGE_MAP = { full: 70, half: 35, tight: 10 };

export function resolveBinRange(binRange) {
  if (typeof binRange === 'number') return binRange;
  return BIN_RANGE_MAP[binRange] || 70;
}

// ============================================================
//  JITO
// ============================================================

const JITO_TIP_ACCOUNTS = [
  '96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5',
  'HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe',
  'Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY',
  'ADaUMid9yfUytqMBgopwjb2DTLSokTSzL1zt6iGPaS49',
  'DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh',
  'ADuUkR4vqLUMWXxW9gh6D6L8pMSawimctcNZ5pGwDcEt',
  'DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL',
  '3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT',
];

export function getRandomJitoTipAccount() {
  return new PublicKey(JITO_TIP_ACCOUNTS[Math.floor(Math.random() * JITO_TIP_ACCOUNTS.length)]);
}

/**
 * Kirim signed transaction ke Jito block engine.
 * Retry 3x dengan 1s delay.
 */
export async function sendTransactionToJito(serializedTransaction) {
  const encodedTx = Buffer.from(serializedTransaction).toString('base64');
  const payload = {
    jsonrpc: '2.0',
    id: 1,
    method: 'sendTransaction',
    params: [encodedTx, { encoding: 'base64', skipPreflight: true }],
  };

  for (let i = 0; i < 3; i++) {
    try {
      const response = await axios.post(
        'https://mainnet.block-engine.jito.wtf/api/v1/transactions',
        payload,
        { headers: { 'Content-Type': 'application/json' }, timeout: 30000 },
      );
      if (response.data.error) throw new Error(response.data.error.message);
      if (!response.data.result) throw new Error('No result from Jito');
      return response.data.result;
    } catch (error) {
      if (i === 2) throw error;
      await sleep(1000);
    }
  }
}
