import config from '../../config.js';
import logger from './logger.js';

/**
 * Kirim pesan ke Telegram via Bot API.
 * Non-blocking — error tidak menghentikan bot.
 */
export async function sendTelegramAlert(message) {
  if (!config.telegramAlert) return;
  if (!config.telegramBotToken || !config.telegramChatId) {
    logger.debug('[Telegram] Bot token atau chat ID belum diset');
    return;
  }

  const url = `https://api.telegram.org/bot${config.telegramBotToken}/sendMessage`;

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: config.telegramChatId,
        text: message,
        parse_mode: 'HTML',
        disable_web_page_preview: true,
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      logger.warn(`[Telegram] Failed (${res.status}): ${body.slice(0, 200)}`);
    }
  } catch (err) {
    logger.warn(`[Telegram] Error: ${err.message}`);
  }
}
