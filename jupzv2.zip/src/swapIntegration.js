import { VersionedTransaction } from '@solana/web3.js';
import axios from 'axios';
import { getWallet } from './connection.js';
import config from '../config.js';
import logger from './utils/logger.js';
import { retry, shortenAddress } from './utils/helpers.js';

/**
 * Execute a token swap via Jupiter Ultra API (menggunakan axios).
 *
 * @param {string} inputMint   - Input token mint address
 * @param {string} outputMint  - Output token mint address
 * @param {number|string} amount - Amount in smallest unit (lamports / raw)
 * @param {number} slippageBps - Slippage in basis points (default dari config)
 * @returns {Promise<{success: boolean, signature: string, inputAmount: string, outputAmount: string}>}
 */
export async function executeSwap(inputMint, outputMint, amount, slippageBps) {
  const wallet = getWallet();
  const taker = wallet.publicKey.toBase58();
  slippageBps = slippageBps ?? config.slippageBps ?? 300;

  logger.info(`[Swap] ${shortenAddress(inputMint)} -> ${shortenAddress(outputMint)} | Amount: ${amount} | Slippage: ${slippageBps}bps`);

  // 1. Get order/quote dari Jupiter Ultra API
  const orderParams = new URLSearchParams({
    inputMint,
    outputMint,
    amount: amount.toString(),
    swapMode: 'ExactIn',
    slippageBps: slippageBps.toString(),
    broadcastFeeType: 'maxCap',
    priorityFeeLamports: '4000000',
    useWsol: 'false',
    asLegacyTransaction: 'false',
    taker,
  });

  const { data: order } = await axios.get(`https://ultra-api.jup.ag/order?${orderParams}`, { timeout: 8000 });

  if (!order?.transaction || !order?.requestId) {
    throw new Error(`Invalid Jupiter order response: ${JSON.stringify(order).slice(0, 200)}`);
  }

  logger.info(`[Swap] Order received - in: ${order.inAmount} | out: ${order.outAmount} | requestId: ${order.requestId}`);

  // 2. Deserialize & sign transaction
  const txBuffer = Buffer.from(order.transaction, 'base64');
  const tx = VersionedTransaction.deserialize(txBuffer);
  tx.sign([wallet]);

  // 3. Execute via Jupiter
  const { data: result } = await axios.post('https://ultra-api.jup.ag/execute', {
    signedTransaction: Buffer.from(tx.serialize()).toString('base64'),
    requestId: order.requestId,
  }, { timeout: 15000 });

  if (result.status !== 'Success') {
    throw new Error(`Jupiter swap failed: ${JSON.stringify(result).slice(0, 300)}`);
  }

  logger.info(`[Swap] Success! TX: ${result.signature}`);

  return {
    success: true,
    signature: result.signature,
    inputAmount: order.inAmount,
    outputAmount: order.outAmount,
  };
}

/**
 * Swap token X to token Y (atau sebaliknya) untuk rebalance portfolio.
 *
 * @param {string} fromMint
 * @param {string} toMint
 * @param {number|string} amount
 */
export async function rebalanceSwap(fromMint, toMint, amount) {
  logger.info(`[RebalanceSwap] Swapping ${amount} of ${shortenAddress(fromMint)} -> ${shortenAddress(toMint)}`);
  return retry(() => executeSwap(fromMint, toMint, amount), config.maxRetries);
}
