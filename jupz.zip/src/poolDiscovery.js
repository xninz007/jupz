import config from '../config.js';
import logger from './utils/logger.js';
import { retry, sleep, shortenAddress } from './utils/helpers.js';

const JUPITER_TOP_TRADED_URL = 'https://datapi.jup.ag/v1/assets/toptraded/5m';
const JUPITER_POOLS_URL = 'https://datapi.jup.ag/v1/pools';
const JUPITER_PNL_URL = 'https://datapi.jup.ag/v1/pnl-activity';
const JUPITER_GEMS_URL = 'https://datapi.jup.ag/v1/assets/gems';
const JUPITER_HOLDERS_URL = 'https://datapi.jup.ag/v1/holders';
const JUPITER_PNL_STATS_URL = 'https://datapi.jup.ag/v1/pnl-stats';
const JUPITER_PNL_POSITIONS_URL = 'https://datapi.jup.ag/v1/pnl-positions';
const ROCKETSCAN_API_URL = 'https://rocketscan.fun/api/pools';
const SOL_MINT = 'So11111111111111111111111111111111111111112';

let cachedResults = null;

/**
 * Fetch top traded tokens dari Jupiter API (volume 5m).
 * @returns {Promise<Array>}
 */
async function fetchTopTraded() {
  logger.info('Fetching top traded tokens dari Jupiter API...');
  const res = await fetch(JUPITER_TOP_TRADED_URL, {
    signal: AbortSignal.timeout(10000),
    headers: { 'Accept': 'application/json' },
  });
  if (!res.ok) throw new Error(`Jupiter API ${res.status} ${res.statusText}`);
  const data = await res.json();
  logger.info(`Fetched ${data.length} tokens dari Jupiter`);
  return data;
}

/**
 * Fetch DLMM pools dari Rocketscan untuk token tertentu.
 * @param {string} tokenMint
 * @param {string} tokenSymbol
 * @returns {Promise<Array>} DLMM pools
 */
export async function fetchDlmmPools(tokenMint, tokenSymbol) {
  const url = `${ROCKETSCAN_API_URL}?page=1&limit=16&sortBy=timestamps.createdAt&sortOrder=desc&poolType=DLMM&keyword=${tokenMint}&userId=${config.rocketscanUserId}&includeStats=true&includeHidden=true`;

  const res = await fetch(url, {
    signal: AbortSignal.timeout(8000),
    headers: { 'Accept': 'application/json' },
  });
  if (!res.ok) throw new Error(`Rocketscan API ${res.status} ${res.statusText}`);
  const data = await res.json();
  const pools = data.data || [];
  const dlmmPools = pools.filter((p) => p.poolType === 'DLMM');

  if (dlmmPools.length > 0) {
    logger.info(`${tokenSymbol}: ${dlmmPools.length} DLMM pool(s) found`);
  }

  return dlmmPools;
}

/**
 * Fetch newest DLMM pools dari Rocketscan (sorted by createdAt desc).
 * Dipakai oleh Mode 4 (Sniper) untuk menemukan pool terbaru.
 *
 * @param {number} limit - Jumlah pool yang diambil (default 16)
 * @returns {Promise<Array>} array of pool objects
 */
export async function fetchNewestDlmmPools(limit = 16) {
  const url = `${ROCKETSCAN_API_URL}?page=1&limit=${limit}&sortBy=timestamps.createdAt&sortOrder=desc&poolType=DLMM&userId=${config.rocketscanUserId}&includeStats=true&includeHidden=true`;

  const res = await fetch(url, {
    signal: AbortSignal.timeout(10000),
    headers: { 'Accept': 'application/json' },
  });
  if (!res.ok) throw new Error(`Rocketscan API ${res.status} ${res.statusText}`);
  const data = await res.json();
  const pools = data.data || [];
  const dlmmPools = pools.filter((p) => p.poolType === 'DLMM');

  logger.info(`[Sniper] Fetched ${dlmmPools.length} newest DLMM pool(s)`);
  return dlmmPools;
}

/**
 * Batch fetch token stats dari Jupiter Pools API.
 * Endpoint: /v1/pools?assetIds=mint1,mint2,...
 *
 * @param {string[]} tokenMints - array of token mint addresses
 * @returns {Promise<Map<string, {volume5m: number, mcap: number, symbol: string, liquidity: number}>>}
 */
export async function fetchTokenStats(tokenMints) {
  const statsMap = new Map();
  if (tokenMints.length === 0) return statsMap;

  const url = `${JUPITER_POOLS_URL}?assetIds=${tokenMints.join(',')}`;

  const res = await fetch(url, {
    signal: AbortSignal.timeout(10000),
    headers: { 'Accept': 'application/json' },
  });
  if (!res.ok) throw new Error(`Jupiter Pools API ${res.status} ${res.statusText}`);
  const data = await res.json();

  for (const pool of (data.pools || [])) {
    const mint = pool.baseAsset?.id;
    if (!mint || statsMap.has(mint)) continue;

    const stats5m = pool.baseAsset?.stats5m || {};
    const volume5m = (stats5m.buyVolume || 0) + (stats5m.sellVolume || 0);
    const organicVolume5m = (stats5m.buyOrganicVolume || 0) + (stats5m.sellOrganicVolume || 0);

    statsMap.set(mint, {
      volume5m,
      organicVolume5m,
      mcap: pool.baseAsset?.mcap || 0,
      symbol: pool.baseAsset?.symbol || '?',
      liquidity: pool.baseAsset?.liquidity || 0,
    });
  }

  logger.info(`[Sniper] Jupiter stats fetched for ${statsMap.size}/${tokenMints.length} token(s)`);
  return statsMap;
}

/**
 * Fetch PnL activity dari Jupiter untuk wallet + token tertentu.
 * Dipakai setelah sell di Mode 5 untuk mendapatkan profit aktual.
 * Returns: { profit, profitNative, cost, usdVolume, price, txHash } atau null jika tidak ada data.
 */
export async function fetchPnlActivity(walletAddress, tokenMint) {
  const url = `${JUPITER_PNL_URL}?address=${walletAddress}&assetId=${tokenMint}`;

  const res = await fetch(url, {
    signal: AbortSignal.timeout(10000),
    headers: { 'Accept': 'application/json' },
  });
  if (!res.ok) throw new Error(`Jupiter PnL API ${res.status} ${res.statusText}`);
  const data = await res.json();

  const walletData = data[walletAddress];
  if (!walletData || !walletData.userTrades) return null;

  // Cari sell trade terbaru
  const sellTrades = walletData.userTrades.filter(t => t.type === 'sell');
  if (sellTrades.length === 0) return null;

  const lastSell = sellTrades[0];
  return {
    profit: lastSell.profit || 0,
    profitNative: lastSell.profitNative || 0,
    cost: lastSell.cost || 0,
    usdVolume: lastSell.usdVolume || 0,
    price: lastSell.price || 0,
    txHash: lastSell.txHash || '',
  };
}

/**
 * Fetch graduated tokens dari Jupiter Gems API.
 * POST https://datapi.jup.ag/v1/assets/gems
 * @returns {Promise<Array>} graduated token assets
 */
export async function fetchGraduateTokens() {
  logger.info('[GemSniper] Fetching graduated tokens dari Jupiter Gems API...');
  const res = await fetch(JUPITER_GEMS_URL, {
    method: 'POST',
    signal: AbortSignal.timeout(10000),
    headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
    body: JSON.stringify({
      graduated: {
        timeframe: '24h',
        launchpads: ['pump.fun', 'letsbonk.fun', 'raydium', 'bags.fun'],
      },
    }),
  });
  if (!res.ok) throw new Error(`Jupiter Gems API ${res.status} ${res.statusText}`);
  const data = await res.json();
  const assets = data?.graduated?.assets || [];
  logger.info(`[GemSniper] Fetched ${assets.length} graduated token(s)`);
  return assets;
}

/**
 * Fetch top holders untuk token tertentu dari Jupiter.
 * GET https://datapi.jup.ag/v1/holders/{mint}
 * @param {string} mint - token mint address
 * @returns {Promise<Array>} array of holder objects
 */
export async function fetchTokenHolders(mint) {
  const res = await fetch(`${JUPITER_HOLDERS_URL}/${mint}`, {
    signal: AbortSignal.timeout(10000),
    headers: { 'Accept': 'application/json' },
  });
  if (!res.ok) throw new Error(`Jupiter Holders API ${res.status} ${res.statusText}`);
  const data = await res.json();
  return data || [];
}

/**
 * Fetch PnL stats untuk wallet tertentu dari Jupiter.
 * GET https://datapi.jup.ag/v1/pnl-stats?address={address}
 * Response: { [address]: { stats: { total: { winRate, totalBuys, ... } } } }
 * @param {string} address - wallet address
 * @returns {Promise<Object|null>} { winRate, totalBuys, totalSells, totalPnl, ... } atau null
 */
export async function fetchWalletPnlStats(address) {
  const res = await fetch(`${JUPITER_PNL_STATS_URL}?address=${address}`, {
    signal: AbortSignal.timeout(10000),
    headers: { 'Accept': 'application/json' },
  });
  if (!res.ok) return null;
  const data = await res.json();
  // Unwrap nested response: data[address].stats.total
  const walletData = data?.[address];
  if (!walletData) return null;
  const total = walletData.stats?.total;
  return total || null;
}

/**
 * Fetch active positions untuk wallet tertentu dari Jupiter.
 * GET https://datapi.jup.ag/v1/pnl-positions?address={address}&filter=activePosition
 * Response: { [address]: { tokenPositions: [...] } }
 * @param {string} address - wallet address
 * @returns {Promise<Array>} array of active positions
 */
export async function fetchWalletPositions(address) {
  const res = await fetch(`${JUPITER_PNL_POSITIONS_URL}?address=${address}&filter=activePosition`, {
    signal: AbortSignal.timeout(10000),
    headers: { 'Accept': 'application/json' },
  });
  if (!res.ok) return [];
  const data = await res.json();
  // Unwrap nested response: data[address].tokenPositions
  const walletData = data?.[address];
  return walletData?.tokenPositions || [];
}

/**
 * Format angka ke readable string ($1.2M, $50K, dll).
 */
function formatVolume(num) {
  if (num >= 1_000_000) return `$${(num / 1_000_000).toFixed(2)}M`;
  if (num >= 1_000) return `$${(num / 1_000).toFixed(2)}K`;
  return `$${num.toFixed(2)}`;
}

/**
 * Discover high-volume tokens yang sudah punya DLMM pool.
 *
 * Flow:
 *   1. Fetch top traded tokens dari Jupiter (volume 5m)
 *   2. Filter by volume threshold & mcap
 *   3. Cek masing-masing token apakah ada DLMM pool di Rocketscan
 *   4. Return token + pool info yang match
 *
 * @returns {Promise<Array>} array of { token, dlmmPools }
 */
export async function discoverPools() {
  let tokens;
  try {
    tokens = await retry(() => fetchTopTraded(), config.maxRetries);
  } catch (err) {
    logger.warn(`Jupiter API failed: ${err.message} (retry next cycle)`);
    return cachedResults || [];
  }

  if (!tokens || tokens.length === 0) {
    logger.warn('No tokens dari Jupiter API');
    return [];
  }

  // Filter by volume threshold & mcap
  const filtered = tokens.filter((t) => {
    const stats5m = t.stats5m || {};
    const vol = (stats5m.buyVolume || 0) + (stats5m.sellVolume || 0);
    if (vol < config.minVolume5m) return false;

    const mcap = t.mcap || 0;
    if (config.minMcap > 0 && mcap < config.minMcap) return false;
    if (config.maxMcap > 0 && mcap > config.maxMcap) return false;

    const liq = t.liquidity || 0;
    if (config.minLiquidity > 0 && liq < config.minLiquidity) return false;
    if (config.maxLiquidity > 0 && liq > config.maxLiquidity) return false;

    // Skip blacklisted tokens
    if (config.blacklistTokens.includes(t.id)) return false;

    return true;
  });

  logger.info(`${filtered.length} tokens di atas volume threshold (${formatVolume(config.minVolume5m)})`);

  // Cek DLMM pool di Rocketscan untuk setiap token
  const results = [];

  for (const token of filtered) {
    const symbol = token.symbol || 'Unknown';
    const mint = token.id;

    try {
      const dlmmPools = await fetchDlmmPools(mint, symbol);

      if (dlmmPools.length === 0) {
        logger.debug(`${symbol}: Tidak ada DLMM pool, skip`);
        await sleep(500);
        continue;
      }

      // Filter: SOL pair + meteoraIndexed + binStep >= minBinStep + baseFee >= minBaseFee
      const validPools = dlmmPools.filter((p) => {
        // tokenA harus SOL
        if ((p.tokenA?.mint || '') !== SOL_MINT) return false;
        const indexed = p.processingMetadata?.meteoraIndexed || false;
        if (!indexed) return false;
        const bs = p.poolData?.binStep || 0;
        if (bs < config.minBinStep) return false;
        const fee = p.poolData?.baseFeePercentage || 0;
        if (fee < config.minBaseFee) return false;
        return true;
      });

      if (validPools.length === 0) {
        logger.debug(`${symbol}: Tidak ada DLMM pool yang memenuhi filter (indexed + binStep>=${config.minBinStep} + baseFee>=${config.minBaseFee}), skip`);
        await sleep(500);
        continue;
      }

      // Sort by liquidity descending, ambil 1 terbaik
      validPools.sort((a, b) => {
        const liqA = parseFloat(a.poolData?.liquidity || 0);
        const liqB = parseFloat(b.poolData?.liquidity || 0);
        return liqB - liqA;
      });

      const bestPool = validPools[0];
      const stats5m = token.stats5m || {};
      const volume5m = (stats5m.buyVolume || 0) + (stats5m.sellVolume || 0);

      results.push({
        token: {
          mint,
          symbol,
          mcap: token.mcap || 0,
          liquidity: token.liquidity || 0,
          volume5m,
          holders: token.holderCount || 0,
          launchpad: token.launchpad || 'unknown',
        },
        bestPool: {
          poolId: bestPool.poolId,
          poolAddress: bestPool.poolId,
          pairName: `${bestPool.tokenA?.symbol || '?'}/${bestPool.tokenB?.symbol || '?'}`,
          mintX: bestPool.tokenA?.mint,
          mintY: bestPool.tokenB?.mint,
          binStep: bestPool.poolData?.binStep,
          baseFee: bestPool.poolData?.baseFeePercentage,
          liquidity: parseFloat(bestPool.poolData?.liquidity || 0),
        },
      });

      if (results.length >= config.topPoolCount) break;
    } catch (err) {
      logger.error(`Error checking DLMM for ${symbol}: ${err.message}`);
    }

    await sleep(1500); // Rate limit antar Rocketscan calls
  }

  cachedResults = results;

  logger.info(`Discovered ${results.length} token(s) dengan DLMM pool`);
  return results;
}

/**
 * Print discovery results ke console.
 * @param {Array} results - array dari discoverPools()
 */
export function printDiscoveryTable(results) {
  if (results.length === 0) {
    console.log('\n  No tokens with DLMM pools found.\n');
    return;
  }

  console.log('\n┌─────────────────────────────────────────────────────────────────────────────────────────────────────────┐');
  console.log('│  TOP TRADED TOKENS WITH DLMM POOLS (indexed, binStep>=' + String(config.minBinStep).padEnd(3) + ', baseFee>=' + config.minBaseFee + '%)                           │');
  console.log('├─────┬────────────┬──────────────┬──────────────┬──────────────┬──────────┬──────┬────────────┤');
  console.log('│  #  │ Symbol     │ Volume 5m    │ MCap         │ Liquidity    │ BinStep  │ Fee% │ Pool Liq   │');
  console.log('├─────┼────────────┼──────────────┼──────────────┼──────────────┼──────────┼──────┼────────────┤');

  results.forEach((r, i) => {
    const idx = String(i + 1).padStart(3);
    const sym = r.token.symbol.padEnd(10).slice(0, 10);
    const vol = formatVolume(r.token.volume5m).padStart(12);
    const mcap = formatVolume(r.token.mcap).padStart(12);
    const liq = formatVolume(r.token.liquidity).padStart(12);
    const p = r.bestPool;
    const bs = String(p.binStep || '?').padStart(8);
    const fee = String(p.baseFee || '?').padStart(4);
    const poolLiq = formatVolume(p.liquidity).padStart(10);

    console.log(`│ ${idx} │ ${sym} │ ${vol} │ ${mcap} │ ${liq} │ ${bs} │ ${fee} │ ${poolLiq} │`);
  });

  console.log('└─────┴────────────┴──────────────┴──────────────┴──────────────┴──────────┴──────┴────────────┘\n');
}
