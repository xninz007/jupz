import { PublicKey } from '@solana/web3.js';
import config from '../config.js';
import { getConnection, getWallet } from './connection.js';
import { loadPool, getUserPositions } from './liquidityManager.js';
import { executeSwap } from './swapIntegration.js';
import { trackClaimedFees } from './monitor.js';
import logger from './utils/logger.js';
import { retry, sleep, shortenAddress, fetchTokenMetadata, fetchTokenPrices } from './utils/helpers.js';

const SOL_MINT = 'So11111111111111111111111111111111111111112';

/**
 * Claim all rewards (swap fees + LM rewards) for all positions in a pool.
 * @param {string} poolAddress
 */
export async function claimAllPoolRewards(poolAddress) {
  const connection = getConnection();
  const wallet = getWallet();
  const dlmmPool = await loadPool(poolAddress);
  const positions = await getUserPositions(dlmmPool);

  if (positions.length === 0) {
    logger.debug(`No positions to claim rewards for in pool ${shortenAddress(poolAddress)}`);
    return;
  }

  // Hitung pending fees sebelum claim (untuk tracking USD)
  const mintX = dlmmPool.lbPair.tokenXMint.toBase58();
  const mintY = dlmmPool.lbPair.tokenYMint.toBase58();
  let pendingFeeX = BigInt(0);
  let pendingFeeY = BigInt(0);
  for (const pos of positions) {
    if (pos.positionData.feeX) pendingFeeX += BigInt(pos.positionData.feeX.toString());
    if (pos.positionData.feeY) pendingFeeY += BigInt(pos.positionData.feeY.toString());
  }

  // Fetch metadata & prices untuk hitung USD
  const prices = await fetchTokenPrices([mintX, mintY]);
  const metadata = await fetchTokenMetadata([mintX, mintY]);
  const metaX = metadata[mintX] || { decimals: 9 };
  const metaY = metadata[mintY] || { decimals: 9 };
  const feeValueX = (Number(pendingFeeX) / 10 ** metaX.decimals) * (prices[mintX] || 0);
  const feeValueY = (Number(pendingFeeY) / 10 ** metaY.decimals) * (prices[mintY] || 0);
  const totalFeeUSD = feeValueX + feeValueY;

  const tokenMint = mintX === SOL_MINT ? mintY : mintX;
  const isXToken = tokenMint === mintX;
  logger.info(`[AutoClaim] Pending feeX: ${pendingFeeX} raw ($${feeValueX.toFixed(6)}) | feeY: ${pendingFeeY} raw ($${feeValueY.toFixed(6)}) | Token side: ${isXToken ? 'X' : 'Y'}`);

  // Claim swap fees — semua posisi sekaligus
  try {
    const feeTxs = await dlmmPool.claimAllSwapFee({
      owner: wallet.publicKey,
      positions,
    });

    for (const tx of feeTxs) {
      const sig = await connection.sendTransaction(tx, [wallet], { skipPreflight: false });
      await connection.confirmTransaction(sig, 'confirmed');
      logger.info(`Swap fee claimed for ${shortenAddress(poolAddress)}: ${sig}`);
    }
  } catch (err) {
    if (err.message?.includes('0x0') || err.message?.includes('no fee')) {
      logger.debug(`No swap fees to claim for ${shortenAddress(poolAddress)}`);
    } else {
      logger.error(`Error claiming swap fees: ${err.message}`);
    }
  }

  // Claim LM rewards — semua posisi sekaligus
  if (config.claimLM) {
    try {
      const rewardTxs = await dlmmPool.claimAllRewards({
        owner: wallet.publicKey,
        positions,
      });

      for (const tx of rewardTxs) {
        const sig = await connection.sendTransaction(tx, [wallet], { skipPreflight: false });
        await connection.confirmTransaction(sig, 'confirmed');
        logger.info(`LM rewards claimed for ${shortenAddress(poolAddress)}: ${sig}`);
      }
    } catch (err) {
      if (err.message?.includes('0x0') || err.message?.includes('no reward')) {
        logger.debug(`No LM rewards to claim for ${shortenAddress(poolAddress)}`);
      } else {
        logger.error(`Error claiming LM rewards: ${err.message}`);
      }
    }
  }

  // Track claimed fees in USD
  if (totalFeeUSD > 0) {
    trackClaimedFees(poolAddress, totalFeeUSD);
    logger.info(`[AutoClaim] Tracked $${totalFeeUSD.toFixed(4)} claimed fees for ${shortenAddress(poolAddress)}`);
  }

  // Swap claimed fees (non-SOL token) ke SOL
  if (config.autoClaimAndSwap) {
    if (tokenMint !== SOL_MINT) {
      // Tunggu balance terupdate setelah claim TX confirmed
      await sleep(1000);

      try {
        // Cek SEMUA token accounts untuk mint ini (lebih robust daripada ATA saja)
        const accounts = await connection.getParsedTokenAccountsByOwner(
          wallet.publicKey,
          { mint: new PublicKey(tokenMint) }
        );

        let tokenBal = 0n;
        for (const { account } of accounts.value) {
          tokenBal += BigInt(account.data.parsed.info.tokenAmount.amount);
        }

        logger.info(`[AutoClaimSwap] Token balance: ${tokenBal} (${accounts.value.length} account(s)) for ${shortenAddress(poolAddress)}`);

        if (tokenBal > 0n) {
          logger.info(`[AutoClaimSwap] Swapping ${tokenBal} to SOL...`);
          await retry(() => executeSwap(tokenMint, SOL_MINT, tokenBal.toString()), config.maxRetries);
          logger.info(`[AutoClaimSwap] Swap to SOL done for ${shortenAddress(poolAddress)}`);
        } else {
          logger.debug(`[AutoClaimSwap] No token balance to swap for ${shortenAddress(poolAddress)}`);
        }
      } catch (swapErr) {
        logger.error(`[AutoClaimSwap] Swap to SOL failed: ${swapErr.message}`);
      }
    }
  }
}

/**
 * Claim rewards for multiple pools.
 * @param {string[]} poolAddresses
 */
export async function claimAllRewards(poolAddresses) {
  logger.info(`Claiming rewards for ${poolAddresses.length} pool(s)...`);

  for (const addr of poolAddresses) {
    try {
      await retry(() => claimAllPoolRewards(addr), config.maxRetries);
    } catch (err) {
      logger.error(`Failed to claim rewards for pool ${shortenAddress(addr)}: ${err.message}`);
    }
  }

  logger.info('Reward claim cycle complete.');
}
