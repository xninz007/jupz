import 'dotenv/config';
import readline from 'readline';
import cron from 'node-cron';
import { createRequire } from 'module';
import { PublicKey } from '@solana/web3.js';
import config from '../config.js';
import { init as initConnection, getWallet, getConnection } from './connection.js';
import { discoverPools, printDiscoveryTable, fetchDlmmPools, fetchNewestDlmmPools, fetchTokenStats, fetchPnlActivity, fetchGraduateTokens, fetchTokenHolders, fetchWalletPnlStats, fetchWalletPositions } from './poolDiscovery.js';
import { loadPool, getActiveBin, getUserPositions, checkBinArrays, checkAndRebalance, removeAllLiquidity, addLiquidityToPool, DLMM, StrategyType, inferStrategy, getTargetPositions, addLiquidityWithBinRange, getPoolOnChainInfo } from './liquidityManager.js';
import { claimAllRewards } from './rewardClaimer.js';
import { printDashboard, trackDeposit, clearPoolTracking, getPoolStatus, trackSwapDeposit, getSwapDepositUSD, clearSwapTracking } from './monitor.js';
import { executeSwap } from './swapIntegration.js';
import logger from './utils/logger.js';
import { sleep, retry, shortenAddress, formatSOL, formatHuman, getTokenBalance, getSOLBalance, fetchTokenMetadata, fetchTokenPrices, resolveBinRange } from './utils/helpers.js';
import { sendTelegramAlert } from './utils/telegram.js';

const require = createRequire(import.meta.url);
const { BN } = require('bn.js');

const SOL_MINT = 'So11111111111111111111111111111111111111112';
const GAS_RESERVE_LAMPORTS = 10_000_000; // 0.01 SOL reserve untuk gas

// State
let activePools = [];
let isShuttingDown = false;
let rl = null;

// Cooldown: tokenMint -> { until: timestamp, poolAddr }
const tokenCooldowns = new Map();

// Per-pool claim timers
const claimTimers = new Map(); // poolAddr -> intervalId

// Track token mint per pool (voor cooldown bij remove)
const poolToMint = new Map(); // poolAddr -> tokenMint
const poolSolBefore = new Map(); // poolAddr -> SOL balance (lamports BigInt) sebelum deposit

// Copy Trade state
let previousTargetSnapshot = new Map(); // poolAddr -> Map<positionPubkey, totalLiquidity bigint>
const copyTradePools = new Set(); // pools opened via copy trade

// Sniper Mode state (Mode 4)
const seenPools = new Set();       // pool addresses yang sudah diproses (skip di loop berikutnya)
const sniperPools = new Set();     // pools yang dibuka via mode 4 (untuk skip cooldown flag)

// Swap Sniper Mode state (Mode 5)
const activeSwaps = new Map();     // tokenMint -> { symbol, poolAddr, depositSOL }

// Gem Sniper Mode state (Mode 6)
const activeGemSwaps = new Map();     // tokenMint -> { symbol, depositSOL, smartScore, holderSnapshot }
const seenGemTokens = new Set();      // token mints yang sudah diproses permanent
const gemHolderSnapshots = new Map();  // tokenMint -> initial holder count

// ============================================================
//  READLINE HELPER
// ============================================================

function ask(question) {
  return new Promise((resolve) => {
    rl.question(question, (answer) => resolve(answer.trim()));
  });
}

// ============================================================
//  POSITION DISPLAY
// ============================================================

async function printPositions(dlmmPool, activeBinId) {
  const positions = await getUserPositions(dlmmPool);
  if (positions.length === 0) {
    console.log('  Positions: 0');
    return;
  }

  console.log(`  Positions: ${positions.length}`);
  for (const pos of positions) {
    const bins = pos.positionData.positionBinData;
    const binIds = bins.map((b) => b.binId);
    const minBin = binIds.length > 0 ? Math.min(...binIds) : 0;
    const maxBin = binIds.length > 0 ? Math.max(...binIds) : 0;
    const inRange = activeBinId >= minBin && activeBinId <= maxBin;
    const tag = inRange ? '\x1b[32mIN RANGE\x1b[0m' : '\x1b[31mOUT OF RANGE\x1b[0m';

    let totalX = BigInt(0);
    let totalY = BigInt(0);
    for (const bin of bins) {
      totalX += BigInt(bin.positionXAmount?.toString() || '0');
      totalY += BigInt(bin.positionYAmount?.toString() || '0');
    }

    const relMin = minBin - activeBinId;
    const relMax = maxBin - activeBinId;

    console.log(`    Position ${shortenAddress(pos.publicKey)} [${tag}]`);
    console.log(`      Range: bin ${relMin} - ${relMax} (${binIds.length} bins)`);
    console.log(`      Token X: ${totalX.toString()} | Token Y: ${totalY.toString()}`);
  }
}

// ============================================================
//  MANUAL POOL INPUT - ONE SIDE SOL
// ============================================================

/**
 * Proses satu pool address secara manual.
 * Flow: Load pool → Check bins → Add liquidity ONE SIDE SOL saja (tanpa swap)
 */
async function processManualPool(poolAddress) {
  logger.info(`\n--- Manual Pool: ${poolAddress} ---`);

  // 1. Load pool
  logger.info('[Step 0] Loading pool dari blockchain...');
  const dlmmPool = await loadPool(poolAddress);
  const { binId: activeBinId, price } = await getActiveBin(dlmmPool);

  const mintX = dlmmPool.lbPair.tokenXMint.toBase58();
  const mintY = dlmmPool.lbPair.tokenYMint.toBase58();
  const binStep = dlmmPool.lbPair.binStep;

  // Fetch metadata
  logger.info('[Step 0] Fetching token metadata...');
  const metadata = await fetchTokenMetadata([mintX, mintY]);
  const metaX = metadata[mintX] || { symbol: shortenAddress(mintX), decimals: 9, name: 'Unknown' };
  const metaY = metadata[mintY] || { symbol: shortenAddress(mintY), decimals: 9, name: 'Unknown' };

  const prices = await fetchTokenPrices([mintX, mintY]);
  const priceX = prices[mintX] || 0;
  const priceY = prices[mintY] || 0;

  // Detect SOL side
  const xIsSOL = mintX === SOL_MINT;
  const yIsSOL = mintY === SOL_MINT;
  const solSide = xIsSOL ? 'X' : (yIsSOL ? 'Y' : null);

  console.log('\n  ┌─────────────────────────────────────────────────────┐');
  console.log(`  │  Pool:       ${shortenAddress(poolAddress).padEnd(38)}│`);
  console.log(`  │  Token X:    ${(metaX.symbol + ' (' + metaX.name + ')').padEnd(38).slice(0, 38)}│`);
  console.log(`  │    Mint:     ${mintX.slice(0, 38).padEnd(38)}│`);
  console.log(`  │    Decimals: ${String(metaX.decimals).padEnd(38)}│`);
  console.log(`  │    Price:    ${('$' + (priceX ? priceX.toFixed(6) : 'N/A')).padEnd(38)}│`);
  console.log(`  │  Token Y:    ${(metaY.symbol + ' (' + metaY.name + ')').padEnd(38).slice(0, 38)}│`);
  console.log(`  │    Mint:     ${mintY.slice(0, 38).padEnd(38)}│`);
  console.log(`  │    Decimals: ${String(metaY.decimals).padEnd(38)}│`);
  console.log(`  │    Price:    ${('$' + (priceY ? priceY.toFixed(6) : 'N/A')).padEnd(38)}│`);
  console.log(`  │  Bin Step:   ${String(binStep).padEnd(38)}│`);
  console.log(`  │  Active Bin: ${String(activeBinId).padEnd(38)}│`);
  console.log(`  │  Price:      ${String(price).slice(0, 36).padEnd(38)}│`);
  console.log(`  │  SOL side:   ${(solSide || 'NONE').padEnd(38)}│`);
  console.log(`  │  Mode:       ${'ONE-SIDE SOL DEPOSIT'.padEnd(38)}│`);
  console.log('  └─────────────────────────────────────────────────────┘\n');

  if (!solSide) {
    logger.warn('Pool ini bukan pair SOL. Tidak bisa one-side SOL deposit.');
    return false;
  }

  // Show existing positions
  await printPositions(dlmmPool, activeBinId);
  console.log('');

  // 2. Check bins - arah range sesuai SOL side
  const totalBins = resolveBinRange(config.binRange);
  let minBinId, maxBinId;
  if (yIsSOL) {
    maxBinId = activeBinId;
    minBinId = activeBinId - (totalBins - 1);
  } else {
    minBinId = activeBinId;
    maxBinId = activeBinId + (totalBins - 1);
  }

  logger.info(`[Bin Check] Range: ${minBinId} to ${maxBinId} (${totalBins} bins | ${config.binRange})`);
  const binCheck = await checkBinArrays(dlmmPool, minBinId, maxBinId);

  if (!binCheck.safe) {
    console.log('\n  ┌─────────────────────────────────────────────────────┐');
    console.log('  │  !! BINS BELUM DIBAYAR !!                            │');
    console.log(`  │  New bin arrays needed: ${String(binCheck.newBinArrays).padEnd(26)}│`);
    console.log(`  │  Cost: ${binCheck.newBinArrays} x ${config.binArrayCostPerUnit} SOL = ${(binCheck.costSOL).toFixed(2)} SOL (non-refundable)  │`);
    console.log('  └─────────────────────────────────────────────────────┘\n');

    if (binCheck.costSOL > config.maxBinArrayCostSOL) {
      logger.warn(`SKIP - Bin array cost ${binCheck.costSOL} SOL > max ${config.maxBinArrayCostSOL} SOL`);
      return false;
    }
  } else {
    logger.info('Bins OK.');
  }

  // 3. Add liquidity ONE SIDE SOL
  const depositLamports = Math.floor(config.depositAmountSOL * 1e9);
  const manualConnection = getConnection();
  const manualWallet = getWallet();
  const solBeforeManual = await getSOLBalance(manualConnection, manualWallet.publicKey);
  logger.info(`[Step 1] Adding ${config.depositAmountSOL} SOL one-side to ${metaX.symbol}/${metaY.symbol}...`);

  // SOL side = depositLamports, token side = 0
  let amountX, amountY;
  if (xIsSOL) {
    amountX = new BN(depositLamports);
    amountY = new BN(0);
  } else {
    amountX = new BN(0);
    amountY = new BN(depositLamports);
  }

  logger.info(`  Amount X (${metaX.symbol}): ${formatHuman(amountX.toString(), metaX.decimals)}`);
  logger.info(`  Amount Y (${metaY.symbol}): ${formatHuman(amountY.toString(), metaY.decimals)}`);

  const added = await retry(() => addLiquidityToPool(poolAddress, amountX, amountY), config.maxRetries);

  if (added) {
    logger.info(`Liquidity added! ${config.depositAmountSOL} SOL deposited one-side.`);
    poolSolBefore.set(poolAddress, solBeforeManual);
    await trackDeposit(poolAddress, depositLamports);

    // Show positions after add
    const dlmmPoolAfter = await loadPool(poolAddress);
    const { binId: newActiveBin } = await getActiveBin(dlmmPoolAfter);
    await printPositions(dlmmPoolAfter, newActiveBin);

    activePools.push(poolAddress);
    startClaimTimer(poolAddress);
    // Track token mint untuk cooldown
    const tokenMint = xIsSOL ? mintY : mintX;
    poolToMint.set(poolAddress, tokenMint);

    sendTelegramAlert(
      `✅ <b>Add Liquidity</b>\nPool: <code>${poolAddress}</code>\nPair: ${metaX.symbol}/${metaY.symbol}\nDeposit: ${config.depositAmountSOL} SOL\nSOL balance: ${formatSOL(solBeforeManual)}\nMode: Manual`
    );
    return true;
  } else {
    logger.warn('Add liquidity di-skip (bins belum dibayar).');
    return false;
  }
}

/**
 * Interactive mode.
 */
async function manualInputMode() {
  console.log('\n  ┌─────────────────────────────────────────────┐');
  console.log('  │         MANUAL POOL INPUT MODE               │');
  console.log('  │  Strategy: ONE-SIDE SOL (no swap needed)     │');
  console.log('  │                                               │');
  console.log('  │  Ketik pool address lalu Enter                │');
  console.log('  │  Ketik "list" untuk lihat active pools        │');
  console.log('  │  Ketik "status" untuk dashboard               │');
  console.log('  │  Ketik "auto" untuk switch ke auto mode       │');
  console.log('  │  Ketik "quit" untuk exit                      │');
  console.log('  └─────────────────────────────────────────────┘\n');

  while (!isShuttingDown) {
    const input = await ask('\nPool address (atau command): ');
    if (!input) continue;

    if (input.toLowerCase() === 'quit' || input.toLowerCase() === 'exit') {
      await shutdown();
      return 'quit';
    }
    if (input.toLowerCase() === 'auto') {
      logger.info('Switching ke auto-discovery mode...');
      return 'auto';
    }
    if (input.toLowerCase() === 'list') {
      if (activePools.length === 0) {
        console.log('  Belum ada active pools.');
      } else {
        console.log(`\n  Active pools (${activePools.length}):`);
        activePools.forEach((p, i) => console.log(`    ${i + 1}. ${p}`));
      }
      continue;
    }
    if (input.toLowerCase() === 'status') {
      await monitorCycle();
      continue;
    }

    if (input.length < 32 || input.length > 50) {
      logger.warn('Invalid address format.');
      continue;
    }

    try {
      const success = await processManualPool(input);
      if (success) {
        logger.info(`Pool ${shortenAddress(input)} active. Total: ${activePools.length}`);
      }
    } catch (err) {
      logger.error(`Gagal proses pool ${shortenAddress(input)}: ${err.message}`);
    }
  }
  return 'quit';
}

// ============================================================
//  AUTO DISCOVERY - ONE SIDE SOL
// ============================================================

async function discoverAndExecute() {
  logger.info('=== Discovery Cycle (One-Side SOL) ===');

  const results = await discoverPools();
  printDiscoveryTable(results);

  if (results.length === 0) {
    logger.info('No tokens with DLMM pools found.');
    return;
  }

  for (const result of results) {
    const { token, bestPool } = result;

    // Cek cooldown — skip jika token masih dalam cooldown atau sedang aktif
    const cd = tokenCooldowns.get(token.mint);
    if (cd) {
      if (Date.now() < cd.until) {
        const remainSec = Math.ceil((cd.until - Date.now()) / 1000);
        logger.debug(`${token.symbol}: cooldown ${remainSec}s remaining, skip`);
        continue;
      }
      // Cooldown expired, hapus
      tokenCooldowns.delete(token.mint);
    }
    // Skip jika token sudah ada di active pools
    if (activePools.some((p) => poolToMint.get(p) === token.mint)) continue;

    if (activePools.length >= config.maxActivePositions) {
      logger.warn(`Max positions (${config.maxActivePositions}) reached.`);
      break;
    }

    if (!bestPool) continue;

    // Load pool on-chain untuk deteksi SOL side yang benar
    // (Rocketscan tokenA/B bisa beda urutan dari on-chain tokenX/Y)
    let dlmmPool;
    try {
      dlmmPool = await loadPool(bestPool.poolAddress);
    } catch (err) {
      logger.error(`${token.symbol}: Failed to load pool: ${err.message}`);
      continue;
    }
    const onChainMintX = dlmmPool.lbPair.tokenXMint.toBase58();
    const onChainMintY = dlmmPool.lbPair.tokenYMint.toBase58();
    const xIsSOL = onChainMintX === SOL_MINT;
    const yIsSOL = onChainMintY === SOL_MINT;
    if (!xIsSOL && !yIsSOL) {
      logger.debug(`${token.symbol}: Pool bukan pair SOL (on-chain), skip.`);
      continue;
    }

    logger.info(`\n--- ${token.symbol} | ${bestPool.pairName} (${shortenAddress(bestPool.poolAddress)}) ---`);
    logger.info(`[REASON] ${token.symbol} lolos filter:`);
    logger.info(`  Volume 5m: $${token.volume5m.toLocaleString()} (min: $${config.minVolume5m.toLocaleString()})`);
    logger.info(`  MCap: $${token.mcap.toLocaleString()} (range: $${config.minMcap.toLocaleString()}-$${config.maxMcap.toLocaleString()})`);
    logger.info(`  Liquidity: $${token.liquidity.toLocaleString()} (range: $${config.minLiquidity.toLocaleString()}-${config.maxLiquidity > 0 ? '$' + config.maxLiquidity.toLocaleString() : 'unlimited'})`);
    logger.info(`  BinStep: ${bestPool.binStep} (min: ${config.minBinStep}) | BaseFee: ${bestPool.baseFee}% (min: ${config.minBaseFee}%)`);
    logger.info(`  Pool Liq: $${bestPool.liquidity.toLocaleString()} | Meteora Indexed: YES`);
    logger.info(`  SOL side: ${xIsSOL ? 'X' : 'Y'} (on-chain) | Pool: ${bestPool.poolAddress}`);

    const depositLamports = Math.floor(config.depositAmountSOL * 1e9);

    try {
      const autoConnection = getConnection();
      const autoWallet = getWallet();
      const solBeforeAuto = await getSOLBalance(autoConnection, autoWallet.publicKey);

      let amountX, amountY;
      if (xIsSOL) {
        amountX = new BN(depositLamports);
        amountY = new BN(0);
      } else {
        amountX = new BN(0);
        amountY = new BN(depositLamports);
      }

      logger.info(`Adding ${config.depositAmountSOL} SOL one-side...`);

      const added = await retry(() => addLiquidityToPool(bestPool.poolAddress, amountX, amountY), config.maxRetries);

      if (added) {
        logger.info(`LP added for ${token.symbol}!`);
        poolSolBefore.set(bestPool.poolAddress, solBeforeAuto);
        await trackDeposit(bestPool.poolAddress, depositLamports);
        activePools.push(bestPool.poolAddress);
        startClaimTimer(bestPool.poolAddress);
        poolToMint.set(bestPool.poolAddress, token.mint);
        sendTelegramAlert(
          `✅ <b>Add Liquidity</b>\nToken: ${token.symbol}\nPool: <code>${bestPool.poolAddress}</code>\nPair: ${bestPool.pairName}\nDeposit: ${config.depositAmountSOL} SOL\nSOL balance: ${formatSOL(solBeforeAuto)}\nBinStep: ${bestPool.binStep} | Fee: ${bestPool.baseFee}%\nMode: Auto`
        );
      } else {
        logger.warn(`SKIP ${token.symbol}: Bins belum dibayar. (akan dicek lagi next cycle)`);
      }
    } catch (err) {
      logger.error(`Failed ${token.symbol}: ${err.message}`);
    }

    await sleep(2000);
  }

  logger.info('=== Discovery Cycle End ===\n');
}

// ============================================================
//  REBALANCE & CLAIM
// ============================================================

async function rebalanceCycle() {
  if (activePools.length === 0) return;
  logger.info('--- Rebalance Cycle ---');
  for (const poolAddr of activePools) {
    try {
      await checkAndRebalance(poolAddr);
    } catch (err) {
      logger.error(`Rebalance failed ${shortenAddress(poolAddr)}: ${err.message}`);
    }
  }
}

async function claimSinglePool(poolAddr) {
  if (isShuttingDown) return;
  logger.info(`--- Claim Fees: ${shortenAddress(poolAddr)} ---`);
  try {
    await claimAllRewards([poolAddr]);
  } catch (err) {
    logger.error(`Claim error ${shortenAddress(poolAddr)}: ${err.message}`);
  }
}

function startClaimTimer(poolAddr) {
  if (!config.autoClaim) return;
  if (claimTimers.has(poolAddr)) return; // sudah ada timer

  const intervalMs = config.claimIntervalMin * 60 * 1000;
  const timerId = setInterval(() => claimSinglePool(poolAddr), intervalMs);
  claimTimers.set(poolAddr, timerId);
  logger.info(`[Claim] Timer started for ${shortenAddress(poolAddr)} (every ${config.claimIntervalMin} min)`);
}

function stopClaimTimer(poolAddr) {
  const timerId = claimTimers.get(poolAddr);
  if (timerId) {
    clearInterval(timerId);
    claimTimers.delete(poolAddr);
    logger.info(`[Claim] Timer stopped for ${shortenAddress(poolAddr)}`);
  }
}

async function monitorCycle() {
  if (activePools.length === 0 && activeSwaps.size === 0 && activeGemSwaps.size === 0) return;
  try {
    if (activePools.length > 0) {
      await printDashboard(activePools);
      await checkOutOfRange();
      await checkTpSl();
    }
    if (activeSwaps.size > 0) {
      await printSwapDashboard();
      await checkSwapTpSl();
    }
    if (activeGemSwaps.size > 0) {
      await printGemDashboard();
      await checkGemTpSl();
    }
  } catch (err) {
    logger.error(`Monitor error: ${err.message}`);
  }
}

// ============================================================
//  REMOVE + SWAP BACK TO SOL (reusable)
// ============================================================

async function removeAndSwapToSOL(poolAddr, reason, permanentBlacklist = false, skipCooldown = false) {
  logger.warn(`${reason} — Removing liquidity from ${shortenAddress(poolAddr)}...`);

  const connection = getConnection();
  const wallet = getWallet();

  // Capture PnL & SOL balance BEFORE remove
  let pnlPercent = 0, pnlUSD = 0;
  try {
    const status = await getPoolStatus(poolAddr);
    pnlPercent = status.pnlPercent;
    pnlUSD = status.pnlUSD;
  } catch {}
  const solBefore = await getSOLBalance(connection, wallet.publicKey);

  await retry(() => removeAllLiquidity(poolAddr), config.maxRetries);

  // Swap leftover tokens back to SOL
  await sleep(1000); // tunggu balance on-chain terupdate setelah remove

  const dlmmPool = await loadPool(poolAddr);
  const mintX = dlmmPool.lbPair.tokenXMint.toBase58();
  const mintY = dlmmPool.lbPair.tokenYMint.toBase58();
  const tokenMint = mintX === SOL_MINT ? mintY : mintX;

  const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
  logger.info(`[SwapBack] Token balance: ${tokenBal} for ${shortenAddress(poolAddr)}`);

  if (tokenBal > 0n) {
    logger.info(`Swapping ${tokenBal} token back to SOL...`);
    try {
      await retry(() => executeSwap(tokenMint, SOL_MINT, tokenBal.toString()), config.maxRetries);
      logger.info('Swap back to SOL done.');
    } catch (swapErr) {
      logger.error(`Swap back failed: ${swapErr.message}`);
    }
  } else {
    logger.warn(`[SwapBack] No token to swap for ${shortenAddress(poolAddr)}`);
  }

  // SOL balance AFTER remove + swap
  await sleep(1000);
  const solAfter = await getSOLBalance(connection, wallet.publicKey);
  const solDiff = solAfter - solBefore;

  // Fetch token metadata for pair name
  const metadata = await fetchTokenMetadata([mintX, mintY]);
  const metaX = metadata[mintX] || { symbol: shortenAddress(mintX) };
  const metaY = metadata[mintY] || { symbol: shortenAddress(mintY) };

  const pnlSign = pnlPercent >= 0 ? '+' : '';
  const solAtDeposit = poolSolBefore.get(poolAddr);
  const depositLine = solAtDeposit != null ? `\nSOL saat deposit: ${formatSOL(solAtDeposit)}` : '';
  sendTelegramAlert(
    `🔻 <b>Remove Liquidity</b>\nPool: <code>${poolAddr}</code>\nPair: ${metaX.symbol}/${metaY.symbol}\nReason: ${reason}\nPnL: <b>${pnlSign}${pnlPercent.toFixed(2)}%</b> ($${pnlUSD.toFixed(4)})${depositLine}\nSOL before remove: ${formatSOL(solBefore)}\nSOL after remove: ${formatSOL(solAfter)}\nDiff: ${solDiff >= 0 ? '+' : ''}${formatSOL(solDiff)} SOL`
  );
  poolSolBefore.delete(poolAddr);

  // Set cooldown / blacklist untuk token ini
  const removedMint = poolToMint.get(poolAddr);
  if (removedMint) {
    if (skipCooldown) {
      // CopyTrade remove → no cooldown, bisa re-entry kapan saja
      logger.info(`[NoCooldown] ${shortenAddress(poolAddr)} token ready for re-entry (copy trade)`);
    } else if (permanentBlacklist) {
      // SL hit → blacklist selamanya
      tokenCooldowns.set(removedMint, { until: Infinity, poolAddr });
      logger.warn(`[Blacklist] ${shortenAddress(poolAddr)} token permanently blacklisted (SL hit)`);
    } else if (config.cooldownHours > 0) {
      const until = Date.now() + config.cooldownHours * 60 * 60 * 1000;
      tokenCooldowns.set(removedMint, { until, poolAddr });
      logger.info(`[Cooldown] ${shortenAddress(poolAddr)} token cooldown ${config.cooldownHours}h`);
    } else {
      // cooldownHours = 0 → permanent blacklist
      tokenCooldowns.set(removedMint, { until: Infinity, poolAddr });
      logger.info(`[Blacklist] ${shortenAddress(poolAddr)} token permanently skipped`);
    }
    poolToMint.delete(poolAddr);
  }

  // Stop claim timer, clear tracking & remove dari activePools
  stopClaimTimer(poolAddr);
  clearPoolTracking(poolAddr);
  copyTradePools.delete(poolAddr);
  sniperPools.delete(poolAddr);
  const idx = activePools.indexOf(poolAddr);
  if (idx !== -1) activePools.splice(idx, 1);
}

// ============================================================
//  OUT OF RANGE HANDLER
// ============================================================

// Track kapan posisi pertama kali OOR kanan: poolAddr -> timestamp
const oorRightTimestamps = new Map();
// Track kapan posisi sniper pertama kali OOR kiri: poolAddr -> timestamp
const oorLeftTimestamps = new Map();

async function checkOutOfRange() {
  if (activePools.length === 0) return;

  const pools = [...activePools];

  for (const poolAddr of pools) {
    try {
      const dlmmPool = await loadPool(poolAddr);
      const { binId: activeBinId } = await getActiveBin(dlmmPool);
      const positions = await getUserPositions(dlmmPool);

      if (positions.length === 0) continue;

      for (const pos of positions) {
        const binIds = pos.positionData.positionBinData.map((b) => b.binId);
        if (binIds.length === 0) continue;

        const minBin = Math.min(...binIds);
        const maxBin = Math.max(...binIds);
        const addr = shortenAddress(poolAddr);

        if (activeBinId >= minBin && activeBinId <= maxBin) {
          // IN RANGE — reset timer jika ada
          if (oorRightTimestamps.has(poolAddr)) {
            logger.info(`[OOR] ${addr} back IN RANGE — right timer reset`);
            oorRightTimestamps.delete(poolAddr);
          }
          if (oorLeftTimestamps.has(poolAddr)) {
            logger.info(`[OOR] ${addr} back IN RANGE — left timer reset`);
            oorLeftTimestamps.delete(poolAddr);
          }
          continue;
        }

        const isSniper = sniperPools.has(poolAddr);

        // === OUT OF RANGE KIRI (price turun, active bin < minBin) ===
        if (activeBinId < minBin) {
          if (isSniper && config.sniperOorLeftWaitMin > 0) {
            // Sniper: tunggu dulu sebelum cut loss
            if (!oorLeftTimestamps.has(poolAddr)) {
              oorLeftTimestamps.set(poolAddr, Date.now());
              logger.info(`[OOR LEFT][Sniper] ${addr} active bin ${activeBinId} < min ${minBin} — timer started (${config.sniperOorLeftWaitMin} min)`);
              continue;
            }

            const elapsed = (Date.now() - oorLeftTimestamps.get(poolAddr)) / 1000 / 60;
            logger.info(`[OOR LEFT][Sniper] ${addr} waiting... ${elapsed.toFixed(1)}/${config.sniperOorLeftWaitMin} min`);

            if (elapsed < config.sniperOorLeftWaitMin) continue;

            logger.warn(`[OOR LEFT][Sniper] ${addr} timeout ${config.sniperOorLeftWaitMin} min — remove + swap + blacklist`);
            oorLeftTimestamps.delete(poolAddr);
          }

          // Remove + swap + blacklist (langsung untuk non-sniper, atau setelah timeout untuk sniper)
          logger.warn(`[OOR LEFT] ${addr} active bin ${activeBinId} < min ${minBin} — price turun, cabut + swap ke SOL`);
          sendTelegramAlert(
            `🔴 <b>OOR LEFT</b>\nPool: <code>${poolAddr}</code>\nActive bin ${activeBinId} < min ${minBin}\nPrice turun — cut loss\n⛔ Token blacklisted${isSniper ? '\nMode: Sniper' : ''}`
          );
          oorRightTimestamps.delete(poolAddr);
          const oorSkipCD = copyTradePools.has(poolAddr) && config.copyTradeSkipCooldown;
          await removeAndSwapToSOL(poolAddr, `OOR LEFT (active ${activeBinId} < min ${minBin})`, !oorSkipCD, oorSkipCD);
          break; // pool sudah di-remove, lanjut pool berikutnya
        }

        // === OUT OF RANGE KANAN (price naik, active bin > maxBin) ===
        if (activeBinId > maxBin) {
          if (isSniper) {
            // Sniper: langsung remove + swap back ke SOL (no wait, no re-add)
            logger.warn(`[OOR RIGHT][Sniper] ${addr} active bin ${activeBinId} > max ${maxBin} — remove + swap back to SOL`);
            sendTelegramAlert(
              `🟡 <b>OOR RIGHT (Sniper)</b>\nPool: <code>${poolAddr}</code>\nActive bin ${activeBinId} > max ${maxBin}\nPrice naik — remove + swap back\nMode: Sniper`
            );
            oorRightTimestamps.delete(poolAddr);
            await removeAndSwapToSOL(poolAddr, `OOR RIGHT Sniper (active ${activeBinId} > max ${maxBin})`);
            break;
          }

          // Non-sniper: tunggu dulu, mungkin balik → remove + re-add
          if (!oorRightTimestamps.has(poolAddr)) {
            oorRightTimestamps.set(poolAddr, Date.now());
            logger.info(`[OOR RIGHT] ${addr} active bin ${activeBinId} > max ${maxBin} — timer started (${config.oorRightWaitMin} min)`);
            continue;
          }

          const elapsed = (Date.now() - oorRightTimestamps.get(poolAddr)) / 1000 / 60;
          logger.info(`[OOR RIGHT] ${addr} waiting... ${elapsed.toFixed(1)}/${config.oorRightWaitMin} min`);

          if (elapsed >= config.oorRightWaitMin) {
            logger.warn(`[OOR RIGHT] ${addr} timeout ${config.oorRightWaitMin} min — remove + re-add`);
            oorRightTimestamps.delete(poolAddr);

            // Remove liquidity
            await retry(() => removeAllLiquidity(poolAddr), config.maxRetries);

            // Clear old deposit & claimed fees tracker (posisi lama sudah di-remove)
            clearPoolTracking(poolAddr);
            // Reset trailing state (posisi baru = fresh)
            peakPnl.delete(poolAddr);
            tpTrailing.delete(poolAddr);

            // Re-add one-side SOL di posisi baru
            const mintX = dlmmPool.lbPair.tokenXMint.toBase58();
            const mintY = dlmmPool.lbPair.tokenYMint.toBase58();
            const xIsSOL = mintX === SOL_MINT;
            const yIsSOL = mintY === SOL_MINT;

            // Swap leftover token back ke SOL dulu
            await sleep(1000); // tunggu balance on-chain terupdate
            const tokenMint = xIsSOL ? mintY : mintX;
            const connection = getConnection();
            const wallet = getWallet();
            const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
            logger.info(`[OOR RIGHT] Token balance: ${tokenBal} for ${addr}`);

            if (tokenBal > 0n) {
              logger.info(`Swapping leftover token back to SOL...`);
              try {
                await retry(() => executeSwap(tokenMint, SOL_MINT, tokenBal.toString()), config.maxRetries);
              } catch (swapErr) {
                logger.error(`Swap failed: ${swapErr.message}`);
              }
            }

            // Re-add one-side SOL
            const depositLamports = Math.floor(config.depositAmountSOL * 1e9);
            let amountX, amountY;
            if (xIsSOL) {
              amountX = new BN(depositLamports);
              amountY = new BN(0);
            } else {
              amountX = new BN(0);
              amountY = new BN(depositLamports);
            }

            try {
              const added = await retry(() => addLiquidityToPool(poolAddr, amountX, amountY), config.maxRetries);
              if (added) {
                logger.info(`[OOR RIGHT] ${addr} re-added ${config.depositAmountSOL} SOL one-side`);
                await trackDeposit(poolAddr, depositLamports);
              } else {
                logger.warn(`[OOR RIGHT] ${addr} re-add skipped (bins belum dibayar)`);
              }
            } catch (addErr) {
              logger.error(`[OOR RIGHT] ${addr} re-add failed: ${addErr.message}`);
            }

            break; // lanjut pool berikutnya
          }
        }
      }
    } catch (err) {
      logger.error(`OOR check failed ${shortenAddress(poolAddr)}: ${err.message}`);
    }
  }
}

// ============================================================
//  TAKE PROFIT & STOP LOSS (with trailing support)
// ============================================================

// Trailing state per pool
const peakPnl = new Map();       // poolAddr -> highest PnL %
const tpTrailing = new Set();    // pools yang sudah activate trailing TP

async function checkTpSl() {
  const tp = config.takeProfitPercent;
  const sl = config.stopLossPercent;
  if (!tp && !sl) return;

  const pools = [...activePools];

  for (const poolAddr of pools) {
    try {
      const isCopyTrade = copyTradePools.has(poolAddr);

      const status = await getPoolStatus(poolAddr);
      const pnl = status.pnlPercent;
      const peak = peakPnl.get(poolAddr) || 0;
      const addr = shortenAddress(poolAddr);

      // Update peak
      if (pnl > peak) {
        peakPnl.set(poolAddr, pnl);
      }
      const currentPeak = peakPnl.get(poolAddr) || 0;

      // === TAKE PROFIT ===
      if (tp) {
        if (config.trailingTP) {
          // Trailing TP: aktifkan trailing saat PnL >= TP
          if (pnl >= tp && !tpTrailing.has(poolAddr)) {
            tpTrailing.add(poolAddr);
            logger.info(`[Trailing TP] ${addr} activated (PnL: +${pnl.toFixed(2)}% >= TP +${tp}%)`);
          }
          if (tpTrailing.has(poolAddr)) {
            const trailTrigger = currentPeak - config.trailingTPPercent;
            logger.info(`[Trailing TP] ${addr} PnL: +${pnl.toFixed(2)}% | Peak: +${currentPeak.toFixed(2)}% | Trail exit: +${trailTrigger.toFixed(2)}%`);
            if (pnl <= trailTrigger) {
              logger.warn(`TRAILING TP HIT! ${addr} PnL: +${pnl.toFixed(2)}% (peak: +${currentPeak.toFixed(2)}%)`);
              sendTelegramAlert(
                `🟢 <b>TRAILING TP HIT</b>\nPool: <code>${poolAddr}</code>\nPnL: <b>+${pnl.toFixed(2)}%</b> ($${status.pnlUSD.toFixed(4)})\nPeak: +${currentPeak.toFixed(2)}% | Trail: ${config.trailingTPPercent}%\n⏳ Cooldown ${config.cooldownHours}h`
              );
              tpTrailing.delete(poolAddr);
              peakPnl.delete(poolAddr);
              const skipCD = isCopyTrade && config.copyTradeSkipCooldown;
              await removeAndSwapToSOL(poolAddr, `Trailing TP (peak +${currentPeak.toFixed(2)}%, exit +${pnl.toFixed(2)}%)`, false, skipCD);
              continue;
            }
          }
        } else {
          // Fixed TP
          if (pnl >= tp) {
            logger.warn(`TAKE PROFIT HIT! ${addr} PnL: +${pnl.toFixed(2)}% >= +${tp}%`);
            sendTelegramAlert(
              `🟢 <b>TAKE PROFIT HIT</b>\nPool: <code>${poolAddr}</code>\nPnL: <b>+${pnl.toFixed(2)}%</b> ($${status.pnlUSD.toFixed(4)})\nTP: +${tp}%\n⏳ Cooldown ${config.cooldownHours}h`
            );
            const skipCD3 = isCopyTrade && config.copyTradeSkipCooldown;
            await removeAndSwapToSOL(poolAddr, `TP +${tp}% hit (PnL: +${pnl.toFixed(2)}%)`, false, skipCD3);
            continue;
          }
        }
      }

      // === STOP LOSS ===
      if (sl) {
        if (config.trailingSL) {
          // Trailing SL: SL naik ikut peak
          const effectiveSL = currentPeak > 0 ? currentPeak - config.trailingSLPercent : sl;
          const finalSL = Math.max(effectiveSL, sl);
          if (pnl <= finalSL) {
            logger.warn(`TRAILING SL HIT! ${addr} PnL: ${pnl.toFixed(2)}% <= ${finalSL.toFixed(2)}% (peak: +${currentPeak.toFixed(2)}%)`);
            sendTelegramAlert(
              `🔴 <b>TRAILING SL HIT</b>\nPool: <code>${poolAddr}</code>\nPnL: <b>${pnl.toFixed(2)}%</b> ($${status.pnlUSD.toFixed(4)})\nEffective SL: ${finalSL.toFixed(2)}% | Peak: +${currentPeak.toFixed(2)}%\n⛔ Token blacklisted`
            );
            tpTrailing.delete(poolAddr);
            peakPnl.delete(poolAddr);
            const skipCD2 = isCopyTrade && config.copyTradeSkipCooldown;
            await removeAndSwapToSOL(poolAddr, `Trailing SL (effective ${finalSL.toFixed(2)}%, PnL ${pnl.toFixed(2)}%)`, !skipCD2, skipCD2);
            continue;
          }
        } else {
          // Fixed SL
          if (pnl <= sl) {
            logger.warn(`STOP LOSS HIT! ${addr} PnL: ${pnl.toFixed(2)}% <= ${sl}%`);
            sendTelegramAlert(
              `🔴 <b>STOP LOSS HIT</b>\nPool: <code>${poolAddr}</code>\nPnL: <b>${pnl.toFixed(2)}%</b> ($${status.pnlUSD.toFixed(4)})\nSL: ${sl}%\n⛔ Token blacklisted`
            );
            const skipCD4 = isCopyTrade && config.copyTradeSkipCooldown;
            await removeAndSwapToSOL(poolAddr, `SL ${sl}% hit (PnL: ${pnl.toFixed(2)}%)`, !skipCD4, skipCD4);
            continue;
          }
        }
      }
    } catch (err) {
      logger.error(`TP/SL check failed ${shortenAddress(poolAddr)}: ${err.message}`);
    }
  }
}

// ============================================================
//  COPY TRADE (MODE 3)
// ============================================================

/**
 * Start copy trade polling mode.
 * Asks for target wallet (or uses config), then polls every copyTradeIntervalSec.
 */
async function copyTradeMode() {
  let targetWalletStr = config.copyTradeWallet;

  if (!targetWalletStr) {
    targetWalletStr = await ask('Target wallet address: ');
  }

  let targetWallet;
  try {
    targetWallet = new PublicKey(targetWalletStr);
  } catch {
    logger.error('Invalid wallet address.');
    return;
  }

  console.log('\n  ┌─────────────────────────────────────────────┐');
  console.log('  │         COPY TRADE MODE (DLMM)               │');
  console.log(`  │  Target: ${shortenAddress(targetWalletStr).padEnd(34)}│`);
  console.log(`  │  Interval: ${String(config.copyTradeIntervalSec + 's').padEnd(32)}│`);
  console.log(`  │  SOL pairs only: ${String(config.copyTradeOnlySOLPairs).padEnd(25)}│`);
  console.log(`  │  Deposit: ${String(config.depositAmountSOL + ' SOL').padEnd(32)}│`);
  console.log('  └─────────────────────────────────────────────┘\n');

  logger.info('Starting copy trade... Fetching initial target positions...');

  // Initial snapshot (don't act on existing positions — only track new ones)
  try {
    const initialPositions = await getTargetPositions(targetWallet);
    previousTargetSnapshot = buildSnapshot(initialPositions);
    logger.info(`Initial snapshot: ${previousTargetSnapshot.size} pool(s) with positions`);
    for (const [pool, posKeys] of previousTargetSnapshot) {
      logger.info(`  ${shortenAddress(pool)}: ${posKeys.size} position(s)`);
    }
  } catch (err) {
    logger.error(`Failed to fetch initial positions: ${err.message}`);
    previousTargetSnapshot = new Map();
  }

  // Start polling
  const intervalMs = config.copyTradeIntervalSec * 1000;
  setInterval(() => {
    if (!isShuttingDown) copyTradeCycle(targetWallet);
  }, intervalMs);
  logger.info(`Copy trade polling started (every ${config.copyTradeIntervalSec}s)`);
}

/**
 * Build snapshot: Map<poolAddr, Map<positionPubkey, totalLiquidity>>
 * totalLiquidity = sum of raw X+Y amounts across all bins (bigint)
 * Used to detect both position removal AND liquidity withdrawal without close.
 */
function buildSnapshot(positionsMap) {
  const snapshot = new Map();
  for (const [poolAddr, posInfo] of positionsMap) {
    const posMap = new Map();
    if (posInfo.lbPairPositionsData) {
      for (const pos of posInfo.lbPairPositionsData) {
        let totalLiq = 0n;
        for (const bin of (pos.positionData.positionBinData || [])) {
          totalLiq += BigInt(bin.positionXAmount?.toString() || '0');
          totalLiq += BigInt(bin.positionYAmount?.toString() || '0');
        }
        posMap.set(pos.publicKey.toBase58(), totalLiq);
      }
    }
    snapshot.set(poolAddr, posMap);
  }
  return snapshot;
}

/**
 * Single copy trade polling cycle.
 * Fetches target positions, compares with previous snapshot,
 * copies new positions and removes when target removes.
 */
async function copyTradeCycle(targetWallet) {
  try {
    logger.info('[CopyTrade] Fetching target positions...');
    const currentPositions = await getTargetPositions(targetWallet);
    const currentSnapshot = buildSnapshot(currentPositions);

    // Detect NEW positions (pool+position combos in current but not in previous)
    for (const [poolAddr, currentPosMap] of currentSnapshot) {
      const prevPosMap = previousTargetSnapshot.get(poolAddr) || new Map();
      for (const [posKey] of currentPosMap) {
        if (!prevPosMap.has(posKey)) {
          logger.info(`[CopyTrade] NEW position detected: ${shortenAddress(posKey)} in pool ${shortenAddress(poolAddr)}`);
          await handleNewTargetPosition(poolAddr, posKey, currentPositions.get(poolAddr));
        }
      }
    }

    // Helper: check if pool has any position with active liquidity
    const hasActiveLiquidity = (posMap) => {
      for (const [, liq] of posMap) {
        if (liq > 0n) return true;
      }
      return false;
    };

    // Detect REMOVED positions (in previous but not in current)
    for (const [poolAddr, prevPosMap] of previousTargetSnapshot) {
      const currentPosMap = currentSnapshot.get(poolAddr) || new Map();
      for (const [posKey] of prevPosMap) {
        if (!currentPosMap.has(posKey)) {
          logger.info(`[CopyTrade] REMOVED position detected: ${shortenAddress(posKey)} in pool ${shortenAddress(poolAddr)}`);
          if (hasActiveLiquidity(currentPosMap)) {
            logger.info(`[CopyTrade] Target still has active liquidity in ${shortenAddress(poolAddr)}, keep ours.`);
            continue;
          }
          await handleRemovedTargetPosition(poolAddr);
        }
      }
    }

    // Detect DRAINED positions (position still exists but liquidity withdrawn to 0)
    for (const [poolAddr, currentPosMap] of currentSnapshot) {
      const prevPosMap = previousTargetSnapshot.get(poolAddr);
      if (!prevPosMap) continue;
      if (!activePools.includes(poolAddr)) continue; // only care about pools we're in

      let poolDrained = false;
      for (const [posKey, currentLiq] of currentPosMap) {
        const prevLiq = prevPosMap.get(posKey);
        if (prevLiq != null && prevLiq > 0n && currentLiq === 0n) {
          logger.info(`[CopyTrade] DRAINED position: ${shortenAddress(posKey)} in ${shortenAddress(poolAddr)} (liq: ${prevLiq} -> 0)`);
          if (hasActiveLiquidity(currentPosMap)) {
            logger.info(`[CopyTrade] Target still has active liquidity in other positions in ${shortenAddress(poolAddr)}, keep ours.`);
            break;
          }
          poolDrained = true;
          break;
        }
      }
      if (poolDrained) {
        logger.warn(`[CopyTrade] All liquidity drained in ${shortenAddress(poolAddr)} — treating as remove`);
        sendTelegramAlert(
          `🟡 <b>Copy Trade: Liquidity Drained</b>\nPool: <code>${poolAddr}</code>\nTarget withdrew liquidity without closing position\nRemoving our position + swap to SOL...`
        );
        await handleRemovedTargetPosition(poolAddr);
      }
    }

    // Update snapshot
    previousTargetSnapshot = currentSnapshot;
  } catch (err) {
    logger.error(`[CopyTrade] Cycle error: ${err.message}`);
  }
}

/**
 * Handle a new position from the target — copy add liquidity.
 */
async function handleNewTargetPosition(poolAddr, posKey, posInfo) {
  const SOL_MINT_ADDR = SOL_MINT;

  try {
    // Check max active positions
    if (activePools.length >= config.maxActivePositions) {
      logger.warn(`[CopyTrade] Max positions (${config.maxActivePositions}) reached, skip.`);
      return;
    }

    // Skip if we already have a position in this pool
    if (activePools.includes(poolAddr)) {
      logger.info(`[CopyTrade] Already have position in ${shortenAddress(poolAddr)}, skip.`);
      return;
    }

    // Get pool info from target data
    const lbPair = posInfo.lbPair;
    const mintX = lbPair.tokenXMint.toBase58();
    const mintY = lbPair.tokenYMint.toBase58();

    // SOL pair check
    const xIsSOL = mintX === SOL_MINT_ADDR;
    const yIsSOL = mintY === SOL_MINT_ADDR;

    if (config.copyTradeOnlySOLPairs && !xIsSOL && !yIsSOL) {
      logger.info(`[CopyTrade] Pool ${shortenAddress(poolAddr)} is not a SOL pair, skip.`);
      return;
    }

    // Find the specific position data
    const targetPos = posInfo.lbPairPositionsData.find(
      (p) => p.publicKey.toBase58() === posKey
    );
    if (!targetPos) {
      logger.warn(`[CopyTrade] Position data not found for ${shortenAddress(posKey)}`);
      return;
    }

    const posData = targetPos.positionData;
    const lowerBinId = posData.lowerBinId;
    const upperBinId = posData.upperBinId;

    // Check if target position is one-side SOL (compare in USD)
    const metadata = await fetchTokenMetadata([mintX, mintY]);
    const prices = await fetchTokenPrices([mintX, mintY]);
    const metaX = metadata[mintX] || { symbol: shortenAddress(mintX), decimals: 9 };
    const metaY = metadata[mintY] || { symbol: shortenAddress(mintY), decimals: 9 };
    const priceX = prices[mintX] || 0;
    const priceY = prices[mintY] || 0;

    let totalXRaw = 0n, totalYRaw = 0n;
    for (const bin of posData.positionBinData) {
      totalXRaw += BigInt(bin.positionXAmount?.toString() || '0');
      totalYRaw += BigInt(bin.positionYAmount?.toString() || '0');
    }

    const usdX = (Number(totalXRaw) / 10 ** metaX.decimals) * priceX;
    const usdY = (Number(totalYRaw) / 10 ** metaY.decimals) * priceY;
    const solUSD = xIsSOL ? usdX : usdY;
    const tokenUSD = xIsSOL ? usdY : usdX;

    logger.info(`[CopyTrade] Position value — SOL side: $${solUSD.toFixed(2)} | Token side: $${tokenUSD.toFixed(2)}`);

    if (solUSD <= 0) {
      logger.info(`[CopyTrade] Skip ${shortenAddress(poolAddr)} — target has no SOL in position (not one-side SOL)`);
      return;
    }
    // Tolerate up to 5% non-SOL side in USD
    if (tokenUSD > solUSD * 0.05) {
      logger.info(`[CopyTrade] Skip ${shortenAddress(poolAddr)} — target position is two-sided ($${tokenUSD.toFixed(2)} token > 5% of $${solUSD.toFixed(2)} SOL)`);
      return;
    }

    // Infer strategy from position bin data
    const strategy = inferStrategy(posData.positionBinData);
    logger.info(`[CopyTrade] Target bin range: ${lowerBinId} - ${upperBinId} | Inferred strategy: ${strategy}`);

    // Determine deposit amounts (one-side SOL)
    const depositLamports = Math.floor(config.depositAmountSOL * 1e9);
    const ctConnection = getConnection();
    const ctWallet = getWallet();
    const solBeforeCT = await getSOLBalance(ctConnection, ctWallet.publicKey);

    let amountX, amountY;
    if (xIsSOL) {
      amountX = new BN(depositLamports);
      amountY = new BN(0);
    } else if (yIsSOL) {
      amountX = new BN(0);
      amountY = new BN(depositLamports);
    } else {
      // Both-side — split evenly (rare case when copyTradeOnlySOLPairs=false)
      amountX = new BN(Math.floor(depositLamports / 2));
      amountY = new BN(Math.floor(depositLamports / 2));
    }

    // Copy add liquidity
    const added = await retry(
      () => addLiquidityWithBinRange(poolAddr, lowerBinId, upperBinId, strategy, amountX, amountY),
      config.maxRetries
    );

    if (added) {
      logger.info(`[CopyTrade] Liquidity added to ${shortenAddress(poolAddr)}!`);
      poolSolBefore.set(poolAddr, solBeforeCT);
      await trackDeposit(poolAddr, depositLamports);
      activePools.push(poolAddr);
      copyTradePools.add(poolAddr);
      startClaimTimer(poolAddr);

      const tokenMint = xIsSOL ? mintY : (yIsSOL ? mintX : mintX);
      poolToMint.set(poolAddr, tokenMint);

      sendTelegramAlert(
        `✅ <b>Copy Trade: Add Liquidity</b>\nPool: <code>${poolAddr}</code>\nPair: ${metaX.symbol}/${metaY.symbol}\nBin range: ${lowerBinId} - ${upperBinId}\nStrategy: ${strategy}\nDeposit: ${config.depositAmountSOL} SOL\nSOL balance: ${formatSOL(solBeforeCT)}\nTarget: <code>${config.copyTradeWallet || 'manual'}</code>`
      );
    } else {
      logger.warn(`[CopyTrade] Add liquidity skipped for ${shortenAddress(poolAddr)} (bins not safe)`);
    }
  } catch (err) {
    logger.error(`[CopyTrade] Failed to copy position in ${shortenAddress(poolAddr)}: ${err.message}`);
  }
}

/**
 * Handle target removing a position — remove our position + swap to SOL.
 */
async function handleRemovedTargetPosition(poolAddr) {
  try {
    // Only act if we have an active position in this pool
    if (!activePools.includes(poolAddr)) {
      logger.info(`[CopyTrade] No active position in ${shortenAddress(poolAddr)}, nothing to remove.`);
      return;
    }

    sendTelegramAlert(
      `🔴 <b>Copy Trade: Target Removed</b>\nPool: <code>${poolAddr}</code>\nRemoving our position + swap to SOL...`
    );

    await removeAndSwapToSOL(poolAddr, 'CopyTrade: target removed', false, true);
  } catch (err) {
    logger.error(`[CopyTrade] Failed to remove position ${shortenAddress(poolAddr)}: ${err.message}`);
  }
}

// ============================================================
//  SNIPER MODE (MODE 4) - Fresh Token X-Only BidAsk
// ============================================================

/**
 * Resolve bin count berdasarkan binStep untuk Mode 4 (Sniper).
 * BinStep lebih besar → bin range lebih kecil (price range per bin lebih lebar).
 */
const SNIPER_BIN_MAP = {
  80: 70,
  100: 70,
  125: 57,
  200: 36,
  300: 25,
  400: 19,
};

function sniperBinCount(binStep) {
  return SNIPER_BIN_MAP[binStep] || 70;
}

/**
 * Start sniper polling mode.
 * Fetches newest DLMM pools, detects fresh tokens, swaps SOL → token, adds liquidity token-only BidAsk.
 */
async function sniperMode() {
  console.log('\n  ┌─────────────────────────────────────────────┐');
  console.log('  │       SNIPER MODE - Fresh Token BidAsk       │');
  console.log(`  │  Deposit: ${String(config.sniperDepositSOL + ' SOL (swap → token)').padEnd(32)}│`);
  console.log(`  │  Max Token: ${String(config.sniperMaxToken + ' (1 token = 1 pool)').padEnd(29)}│`);
  console.log(`  │  Max MCap: ${String('$' + config.sniperMaxMcap.toLocaleString()).padEnd(31)}│`);
  console.log(`  │  Min Vol5m: ${String('$' + config.sniperMinVolume5m.toLocaleString()).padEnd(29)}│`);
  console.log(`  │  Interval: ${String(config.sniperIntervalSec + 's').padEnd(31)}│`);
  console.log(`  │  Min BinStep: ${String(config.minBinStep).padEnd(28)}│`);
  console.log(`  │  Min BaseFee: ${String(config.minBaseFee + '%').padEnd(28)}│`);
  console.log(`  │  Strategy: ${'BidAsk (hardcoded)'.padEnd(31)}│`);
  console.log('  └─────────────────────────────────────────────┘\n');

  logger.info('[Sniper] Starting sniper mode... polling every ' + config.sniperIntervalSec + 's');

  // Run first cycle immediately
  await sniperCycle();

  // Start polling loop
  setInterval(() => {
    if (!isShuttingDown) sniperCycle();
  }, config.sniperIntervalSec * 1000);
}

/**
 * Single sniper polling cycle.
 * 1. Fetch newest DLMM pools from Rocketscan
 * 2. Filter: SOL pair, mcap, freshness, binStep, baseFee
 * 3. Check bins paid
 * 4. Swap SOL → token
 * 5. Add liquidity token-only BidAsk
 */
async function sniperCycle() {
  try {
    logger.info('[Sniper] === Sniper Cycle ===');

    let newestPools;
    try {
      newestPools = await retry(() => fetchNewestDlmmPools(16), config.maxRetries);
    } catch (err) {
      logger.warn(`[Sniper] Failed to fetch newest pools: ${err.message}`);
      return;
    }

    if (!newestPools || newestPools.length === 0) {
      logger.info('[Sniper] No newest DLMM pools found.');
      return;
    }

    // Batch fetch token stats dari Jupiter (volume, mcap)
    const candidateMints = [];
    for (const p of newestPools) {
      if (seenPools.has(p.poolId)) continue;
      const tA = p.tokenA?.mint || '';
      const tB = p.tokenB?.mint || '';
      const mint = tA === SOL_MINT ? tB : (tB === SOL_MINT ? tA : null);
      if (mint && !candidateMints.includes(mint)) candidateMints.push(mint);
    }

    let tokenStatsMap = new Map();
    if (candidateMints.length > 0) {
      try {
        tokenStatsMap = await retry(() => fetchTokenStats(candidateMints), config.maxRetries);
      } catch (err) {
        logger.warn(`[Sniper] Jupiter stats fetch failed: ${err.message} (skip volume filter this cycle)`);
      }
    }

    const checkedMintsM4 = new Set(); // avoid duplicate token checks within same cycle

    for (const pool of newestPools) {
      const poolAddr = pool.poolId;
      const poolName = `${pool.tokenA?.symbol || '?'}/${pool.tokenB?.symbol || '?'}`;

      // a. Skip jika sudah di-process atau sudah aktif
      if (seenPools.has(poolAddr)) continue;
      if (activePools.includes(poolAddr)) {
        seenPools.add(poolAddr);
        continue;
      }

      // b. Skip jika sniperMaxToken tercapai (1 token = 1 pool = 1 posisi)
      const activeSniperCount = activePools.filter((p) => sniperPools.has(p)).length;
      if (activeSniperCount >= config.sniperMaxToken) {
        logger.warn(`[Sniper] Max tokens (${config.sniperMaxToken}) reached, stop scanning.`);
        break;
      }

      // c. Skip jika bukan SOL pair (tokenA.mint !== SOL_MINT)
      const tokenAMint = pool.tokenA?.mint || '';
      const tokenBMint = pool.tokenB?.mint || '';
      if (tokenAMint !== SOL_MINT && tokenBMint !== SOL_MINT) {
        logger.debug(`[Sniper] ${poolName} (${shortenAddress(poolAddr)}): not a SOL pair, skip`);
        seenPools.add(poolAddr);
        continue;
      }

      // d. Determine token mint & skip if already checked this cycle
      const tokenMint = tokenAMint === SOL_MINT ? tokenBMint : tokenAMint;
      const tokenSymbol = tokenAMint === SOL_MINT ? (pool.tokenB?.symbol || '?') : (pool.tokenA?.symbol || '?');

      if (checkedMintsM4.has(tokenMint)) {
        seenPools.add(poolAddr);
        continue;
      }

      // e. Skip jika mcap > sniperMaxMcap
      const mcap = pool.poolData?.mcap || pool.tokenB?.mcap || 0;
      if (config.sniperMaxMcap > 0 && mcap > config.sniperMaxMcap) {
        logger.debug(`[Sniper] ${poolName}: mcap $${mcap.toLocaleString()} > max $${config.sniperMaxMcap.toLocaleString()}, skip`);
        seenPools.add(poolAddr);
        checkedMintsM4.add(tokenMint);
        continue;
      }

      // f. Skip jika token di blacklist/cooldown
      if (config.blacklistTokens.includes(tokenMint)) {
        logger.debug(`[Sniper] ${tokenSymbol}: blacklisted, skip`);
        seenPools.add(poolAddr);
        checkedMintsM4.add(tokenMint);
        continue;
      }

      const cd = tokenCooldowns.get(tokenMint);
      if (cd && Date.now() < cd.until) {
        logger.debug(`[Sniper] ${tokenSymbol}: cooldown active, skip`);
        seenPools.add(poolAddr);
        checkedMintsM4.add(tokenMint);
        continue;
      }
      if (cd) tokenCooldowns.delete(tokenMint); // expired

      // Skip jika token sudah ada di active pools
      if (activePools.some((p) => poolToMint.get(p) === tokenMint)) {
        logger.debug(`[Sniper] ${tokenSymbol}: already active in another pool, skip`);
        seenPools.add(poolAddr);
        checkedMintsM4.add(tokenMint);
        continue;
      }

      // g. Freshness check (SEBELUM volume — supaya token 1+ pool langsung skip permanent)
      let dlmmPoolsForToken;
      try {
        dlmmPoolsForToken = await fetchDlmmPools(tokenMint, tokenSymbol);
      } catch (err) {
        logger.warn(`[Sniper] Freshness check failed for ${tokenSymbol}: ${err.message}`);
        checkedMintsM4.add(tokenMint);
        continue; // retry next cycle
      }

      if (dlmmPoolsForToken.length > 1) {
        logger.info(`[Sniper] ${tokenSymbol}: has ${dlmmPoolsForToken.length} DLMM pool(s) — NOT fresh, skip`);
        seenPools.add(poolAddr);
        checkedMintsM4.add(tokenMint);
        continue;
      }
      logger.info(`[Sniper] ${tokenSymbol}: ${dlmmPoolsForToken.length} DLMM pool(s) — FRESH`);

      // h. Volume filter dari Jupiter (setelah freshness — volume bisa naik, retry next cycle)
      const jupStats = tokenStatsMap.get(tokenMint);
      const volume5m = jupStats?.volume5m || 0;
      if (config.sniperMinVolume5m > 0 && volume5m < config.sniperMinVolume5m) {
        logger.debug(`[Sniper] ${tokenSymbol}: volume5m $${volume5m.toLocaleString()} < min $${config.sniperMinVolume5m.toLocaleString()}, retry next cycle`);
        checkedMintsM4.add(tokenMint);
        continue;
      }

      // h2. Organic ratio filter
      const organicVolume5mM4 = jupStats?.organicVolume5m || 0;
      const organicRatioM4 = volume5m > 0 ? (organicVolume5mM4 / volume5m) * 100 : 0;
      if (config.sniperMinOrganicRatio > 0 && organicRatioM4 < config.sniperMinOrganicRatio) {
        logger.debug(`[Sniper] ${tokenSymbol}: organic ratio ${organicRatioM4.toFixed(1)}% < min ${config.sniperMinOrganicRatio}% (organic $${organicVolume5mM4.toLocaleString()} / total $${volume5m.toLocaleString()}), retry next cycle`);
        checkedMintsM4.add(tokenMint);
        continue;
      }

      if (volume5m > 0) {
        logger.info(`[Sniper] ${tokenSymbol}: volume5m $${volume5m.toLocaleString()} | organic $${organicVolume5mM4.toLocaleString()} (${organicRatioM4.toFixed(1)}%) — OK`);
      }

      // i. Get binStep & baseFee
      let binStep, baseFeePercent;
      const meteoraIndexed = pool.processingMetadata?.meteoraIndexed || false;

      if (meteoraIndexed) {
        binStep = pool.poolData?.binStep || 0;
        baseFeePercent = pool.poolData?.baseFeePercentage || 0;
        logger.info(`[Sniper] ${tokenSymbol}: binStep=${binStep}, baseFee=${baseFeePercent}% (from Rocketscan)`);
      } else {
        try {
          const onChainInfo = await getPoolOnChainInfo(poolAddr);
          binStep = onChainInfo.binStep;
          baseFeePercent = onChainInfo.baseFeePercent;
          logger.info(`[Sniper] ${tokenSymbol}: binStep=${binStep}, baseFee=${baseFeePercent.toFixed(2)}% (from on-chain)`);
        } catch (err) {
          logger.warn(`[Sniper] ${tokenSymbol}: Failed to load on-chain info: ${err.message}`);
          continue; // retry next cycle, DON'T add to seenPools
        }
      }

      // h. Filter binStep >= config.minBinStep, baseFee >= config.minBaseFee
      if (binStep < config.minBinStep) {
        logger.debug(`[Sniper] ${tokenSymbol}: binStep ${binStep} < min ${config.minBinStep}, skip`);
        seenPools.add(poolAddr);
        continue;
      }
      if (baseFeePercent < config.minBaseFee) {
        logger.debug(`[Sniper] ${tokenSymbol}: baseFee ${baseFeePercent}% < min ${config.minBaseFee}%, skip`);
        seenPools.add(poolAddr);
        continue;
      }

      // i. Load pool on-chain → check bin arrays paid
      let dlmmPool;
      try {
        dlmmPool = await loadPool(poolAddr);
      } catch (err) {
        logger.warn(`[Sniper] ${tokenSymbol}: Failed to load pool: ${err.message}`);
        continue; // retry next cycle
      }

      const { binId: activeBinId, price } = await getActiveBin(dlmmPool);
      const onChainMintX = dlmmPool.lbPair.tokenXMint.toBase58();
      const onChainMintY = dlmmPool.lbPair.tokenYMint.toBase58();
      const xIsSOL = onChainMintX === SOL_MINT;
      const yIsSOL = onChainMintY === SOL_MINT;

      if (!xIsSOL && !yIsSOL) {
        logger.debug(`[Sniper] ${tokenSymbol}: Pool bukan pair SOL (on-chain), skip`);
        seenPools.add(poolAddr);
        continue;
      }

      // Determine token-only side bin range (berdasarkan binStep)
      const totalBins = sniperBinCount(binStep);
      logger.info(`[Sniper] ${tokenSymbol}: binStep=${binStep} → ${totalBins} bins`);
      let minBinId, maxBinId;

      if (yIsSOL) {
        // Token = X → deposit di ATAS active bin
        minBinId = activeBinId;
        maxBinId = activeBinId + (totalBins - 1);
      } else {
        // Token = Y → deposit di BAWAH active bin
        maxBinId = activeBinId;
        minBinId = activeBinId - (totalBins - 1);
      }

      const binCheck = await checkBinArrays(dlmmPool, minBinId, maxBinId);
      logger.info(`[Sniper] ${tokenSymbol}: Bin check — ${binCheck.totalBins} bins | ${binCheck.newBinArrays} new arrays | Cost: ${binCheck.costSOL} SOL`);

      if (!binCheck.safe) {
        // NOT paid → skip but DON'T add to seenPools (retry next loop)
        logger.warn(`[Sniper] ${tokenSymbol}: Bins NOT paid — will retry next cycle`);
        continue;
      }

      // === BINS PAID — PROCEED ===
      logger.info(`[Sniper] ${tokenSymbol}: Bins PAID. Sniping ${poolName} (${shortenAddress(poolAddr)})...`);
      logger.info(`[Sniper]   MCap: $${mcap.toLocaleString()} | BinStep: ${binStep} | Fee: ${baseFeePercent}% | Active bin: ${activeBinId} | Price: ${price}`);

      // j. Swap SOL → token
      const depositLamports = Math.floor(config.sniperDepositSOL * 1e9);
      const connection = getConnection();
      const wallet = getWallet();
      const solBefore = await getSOLBalance(connection, wallet.publicKey);

      logger.info(`[Sniper] Swapping ${config.sniperDepositSOL} SOL → ${tokenSymbol}...`);
      try {
        await retry(
          () => executeSwap(SOL_MINT, tokenMint, depositLamports),
          config.maxRetries
        );
      } catch (swapErr) {
        logger.error(`[Sniper] Swap failed for ${tokenSymbol}: ${swapErr.message}, retry next cycle`);
        continue; // JANGAN seenPools — bisa retry next cycle
      }

      // k. Wait 1s → get token balance
      await sleep(1000);
      const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
      logger.info(`[Sniper] Token balance after swap: ${tokenBal} (${tokenSymbol})`);

      if (tokenBal <= 0n) {
        logger.warn(`[Sniper] ${tokenSymbol}: No token balance after swap, skip`);
        seenPools.add(poolAddr);
        continue;
      }

      // l. Add liquidity token-only side, strategy BidAsk
      // Refresh active bin (price may have changed after swap)
      const { binId: freshActiveBinId } = await getActiveBin(dlmmPool);
      let sniperMinBin, sniperMaxBin;
      let amountX, amountY;

      if (yIsSOL) {
        // Token = X → deposit di ATAS active bin
        sniperMinBin = freshActiveBinId;
        sniperMaxBin = freshActiveBinId + (totalBins - 1);
        amountX = new BN(tokenBal.toString());
        amountY = new BN(0);
      } else {
        // Token = Y → deposit di BAWAH active bin
        sniperMaxBin = freshActiveBinId;
        sniperMinBin = freshActiveBinId - (totalBins - 1);
        amountX = new BN(0);
        amountY = new BN(tokenBal.toString());
      }

      logger.info(`[Sniper] Adding liquidity token-only BidAsk: bins ${sniperMinBin}-${sniperMaxBin} | amountX=${amountX.toString()} | amountY=${amountY.toString()}`);

      let addSuccess = false;
      try {
        const added = await retry(
          () => addLiquidityWithBinRange(poolAddr, sniperMinBin, sniperMaxBin, 'BidAsk', amountX, amountY),
          config.maxRetries
        );
        addSuccess = !!added;

        if (added) {
          logger.info(`[Sniper] LP added for ${tokenSymbol}!`);
          poolSolBefore.set(poolAddr, solBefore);
          await trackDeposit(poolAddr, depositLamports);
          activePools.push(poolAddr);
          sniperPools.add(poolAddr);
          startClaimTimer(poolAddr);
          poolToMint.set(poolAddr, tokenMint);

          sendTelegramAlert(
            `🎯 <b>Sniper: Add Liquidity</b>\nToken: ${tokenSymbol}\nPool: <code>${poolAddr}</code>\nPair: ${poolName}\nSwap: ${config.sniperDepositSOL} SOL → ${tokenSymbol}\nStrategy: BidAsk (token-only)\nBin range: ${sniperMinBin} - ${sniperMaxBin}\nBinStep: ${binStep} | Fee: ${baseFeePercent}%\nMCap: $${mcap.toLocaleString()}\nSOL balance: ${formatSOL(solBefore)}\nMode: Sniper`
          );
        } else {
          logger.warn(`[Sniper] Add liquidity skipped for ${tokenSymbol} (bins not safe)`);
        }
      } catch (addErr) {
        logger.error(`[Sniper] Add liquidity failed for ${tokenSymbol}: ${addErr.message}`);
      }

      if (!addSuccess) {
        // Add liq gagal — swap token balik ke SOL, jangan blacklist
        logger.warn(`[Sniper] ${tokenSymbol}: Add liq failed, swapping token back to SOL...`);
        await sleep(1000);
        const remainingBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
        if (remainingBal > 0n) {
          try {
            await retry(() => executeSwap(tokenMint, SOL_MINT, remainingBal.toString()), config.maxRetries);
            logger.info(`[Sniper] ${tokenSymbol}: Token swapped back to SOL`);
          } catch (swapBackErr) {
            logger.error(`[Sniper] ${tokenSymbol}: Swap back failed: ${swapBackErr.message}`);
          }
        }
        // JANGAN add ke seenPools — bisa retry next cycle
        await sleep(2000);
        continue;
      }

      // m. Mark as processed (hanya jika sukses)
      seenPools.add(poolAddr);
      await sleep(2000); // Rate limit
    }

    logger.info('[Sniper] === Sniper Cycle End ===\n');
  } catch (err) {
    logger.error(`[Sniper] Cycle error: ${err.message}`);
  }
}

// ============================================================
//  SWAP SNIPER MODE (MODE 5) - Fresh Token Swap Only
// ============================================================

/**
 * Start swap sniper polling mode.
 * Same scanning as Mode 4 but swap only (no add liquidity).
 * PnL tracked via token balance value vs deposit cost.
 */
async function swapSniperMode() {
  console.log('\n  ┌─────────────────────────────────────────────┐');
  console.log('  │     SWAP SNIPER MODE - Fresh Token Buy       │');
  console.log(`  │  Deposit: ${String(config.sniperDepositSOL + ' SOL (swap → token)').padEnd(32)}│`);
  console.log(`  │  Max Token: ${String(config.sniperMaxToken + ' (1 token = 1 swap)').padEnd(29)}│`);
  console.log(`  │  Max MCap: ${String('$' + config.sniperMaxMcap.toLocaleString()).padEnd(31)}│`);
  console.log(`  │  Min Vol5m: ${String('$' + config.sniperMinVolume5m.toLocaleString()).padEnd(29)}│`);
  console.log(`  │  Interval: ${String(config.sniperIntervalSec + 's').padEnd(31)}│`);
  console.log(`  │  Min BinStep: ${String(config.minBinStep).padEnd(28)}│`);
  console.log(`  │  Min BaseFee: ${String(config.minBaseFee + '%').padEnd(28)}│`);
  console.log(`  │  Mode: ${'Swap only (no LP)'.padEnd(36)}│`);
  console.log('  └─────────────────────────────────────────────┘\n');

  logger.info('[SwapSniper] Starting swap sniper mode... polling every ' + config.sniperIntervalSec + 's');

  // First run: skip existing data (hanya catat ke seenPools, jangan swap)
  logger.info('[SwapSniper] First run — skipping existing pools...');
  try {
    const initialPools = await retry(() => fetchNewestDlmmPools(16), config.maxRetries);
    if (initialPools && initialPools.length > 0) {
      for (const p of initialPools) {
        seenPools.add(p.poolId);
      }
      logger.info(`[SwapSniper] Skipped ${initialPools.length} existing pool(s). Only new pools will be sniped.`);
    }
  } catch (err) {
    logger.warn(`[SwapSniper] First run fetch failed: ${err.message}`);
  }

  // Start polling loop (cycle pertama setelah interval, bukan langsung)
  setInterval(() => {
    if (!isShuttingDown) swapSniperCycle();
  }, config.sniperIntervalSec * 1000);
}

/**
 * Single swap sniper polling cycle.
 * Same filtering as Mode 4 but:
 * - No bin array check (no LP)
 * - No add liquidity (just swap)
 * - PnL tracked via token balance
 */
async function swapSniperCycle() {
  try {
    logger.info('[SwapSniper] === Swap Sniper Cycle ===');

    let newestPools;
    try {
      newestPools = await retry(() => fetchNewestDlmmPools(16), config.maxRetries);
    } catch (err) {
      logger.warn(`[SwapSniper] Failed to fetch newest pools: ${err.message}`);
      return;
    }

    if (!newestPools || newestPools.length === 0) {
      logger.info('[SwapSniper] No newest DLMM pools found.');
      return;
    }

    // Batch fetch token stats dari Jupiter (volume, mcap)
    const candidateMints = [];
    for (const p of newestPools) {
      if (seenPools.has(p.poolId)) continue;
      const tA = p.tokenA?.mint || '';
      const tB = p.tokenB?.mint || '';
      const mint = tA === SOL_MINT ? tB : (tB === SOL_MINT ? tA : null);
      if (mint && !candidateMints.includes(mint)) candidateMints.push(mint);
    }

    let tokenStatsMap = new Map();
    if (candidateMints.length > 0) {
      try {
        tokenStatsMap = await retry(() => fetchTokenStats(candidateMints), config.maxRetries);
      } catch (err) {
        logger.warn(`[SwapSniper] Jupiter stats fetch failed: ${err.message} (skip volume filter this cycle)`);
      }
    }

    const checkedMints = new Set(); // avoid duplicate token checks within same cycle

    for (const pool of newestPools) {
      const poolAddr = pool.poolId;
      const poolName = `${pool.tokenA?.symbol || '?'}/${pool.tokenB?.symbol || '?'}`;

      // a. Skip jika sudah di-process
      if (seenPools.has(poolAddr)) continue;

      // b. Skip jika max tokens reached
      if (activeSwaps.size >= config.sniperMaxToken) {
        logger.warn(`[SwapSniper] Max tokens (${config.sniperMaxToken}) reached, stop scanning.`);
        break;
      }

      // c. SOL pair check
      const tokenAMint = pool.tokenA?.mint || '';
      const tokenBMint = pool.tokenB?.mint || '';
      if (tokenAMint !== SOL_MINT && tokenBMint !== SOL_MINT) {
        logger.debug(`[SwapSniper] ${poolName} (${shortenAddress(poolAddr)}): not a SOL pair, skip`);
        seenPools.add(poolAddr);
        continue;
      }

      // d. Determine token mint & skip if already checked this cycle
      const tokenMint = tokenAMint === SOL_MINT ? tokenBMint : tokenAMint;
      const tokenSymbol = tokenAMint === SOL_MINT ? (pool.tokenB?.symbol || '?') : (pool.tokenA?.symbol || '?');

      if (checkedMints.has(tokenMint)) {
        seenPools.add(poolAddr);
        continue;
      }

      // e. MCap filter
      const mcap = pool.poolData?.mcap || pool.tokenB?.mcap || 0;
      if (config.sniperMaxMcap > 0 && mcap > config.sniperMaxMcap) {
        logger.debug(`[SwapSniper] ${poolName}: mcap $${mcap.toLocaleString()} > max $${config.sniperMaxMcap.toLocaleString()}, skip`);
        seenPools.add(poolAddr);
        checkedMints.add(tokenMint);
        continue;
      }

      // f. Blacklist / cooldown / already active
      if (config.blacklistTokens.includes(tokenMint)) {
        logger.debug(`[SwapSniper] ${tokenSymbol}: blacklisted, skip`);
        seenPools.add(poolAddr);
        checkedMints.add(tokenMint);
        continue;
      }

      const cd = tokenCooldowns.get(tokenMint);
      if (cd && Date.now() < cd.until) {
        logger.debug(`[SwapSniper] ${tokenSymbol}: cooldown active, skip`);
        seenPools.add(poolAddr);
        checkedMints.add(tokenMint);
        continue;
      }
      if (cd) tokenCooldowns.delete(tokenMint); // expired

      if (activeSwaps.has(tokenMint)) {
        logger.debug(`[SwapSniper] ${tokenSymbol}: already holding, skip`);
        seenPools.add(poolAddr);
        checkedMints.add(tokenMint);
        continue;
      }

      // g. Freshness check (SEBELUM volume — supaya token 1+ pool langsung skip permanent)
      let dlmmPoolsForToken;
      try {
        dlmmPoolsForToken = await fetchDlmmPools(tokenMint, tokenSymbol);
      } catch (err) {
        logger.warn(`[SwapSniper] Freshness check failed for ${tokenSymbol}: ${err.message}`);
        checkedMints.add(tokenMint);
        continue; // retry next cycle
      }

      if (dlmmPoolsForToken.length > 1) {
        logger.info(`[SwapSniper] ${tokenSymbol}: has ${dlmmPoolsForToken.length} DLMM pool(s) — NOT fresh, skip`);
        seenPools.add(poolAddr);
        checkedMints.add(tokenMint);
        continue;
      }
      logger.info(`[SwapSniper] ${tokenSymbol}: ${dlmmPoolsForToken.length} DLMM pool(s) — FRESH`);

      // h. Volume filter dari Jupiter (setelah freshness — volume bisa naik, retry next cycle)
      const jupStats = tokenStatsMap.get(tokenMint);
      const volume5m = jupStats?.volume5m || 0;
      if (config.sniperMinVolume5m > 0 && volume5m < config.sniperMinVolume5m) {
        logger.debug(`[SwapSniper] ${tokenSymbol}: volume5m $${volume5m.toLocaleString()} < min $${config.sniperMinVolume5m.toLocaleString()}, retry next cycle`);
        checkedMints.add(tokenMint);
        continue;
      }

      // h2. Organic ratio filter
      const organicVolume5m = jupStats?.organicVolume5m || 0;
      const organicRatio = volume5m > 0 ? (organicVolume5m / volume5m) * 100 : 0;
      if (config.sniperMinOrganicRatio > 0 && organicRatio < config.sniperMinOrganicRatio) {
        logger.debug(`[SwapSniper] ${tokenSymbol}: organic ratio ${organicRatio.toFixed(1)}% < min ${config.sniperMinOrganicRatio}% (organic $${organicVolume5m.toLocaleString()} / total $${volume5m.toLocaleString()}), retry next cycle`);
        checkedMints.add(tokenMint);
        continue;
      }

      if (volume5m > 0) {
        logger.info(`[SwapSniper] ${tokenSymbol}: volume5m $${volume5m.toLocaleString()} | organic $${organicVolume5m.toLocaleString()} (${organicRatio.toFixed(1)}%) — OK`);
      }

      // i. Get binStep & baseFee (filter for pool quality)
      let binStep, baseFeePercent;
      const meteoraIndexed = pool.processingMetadata?.meteoraIndexed || false;

      if (meteoraIndexed) {
        binStep = pool.poolData?.binStep || 0;
        baseFeePercent = pool.poolData?.baseFeePercentage || 0;
        logger.info(`[SwapSniper] ${tokenSymbol}: binStep=${binStep}, baseFee=${baseFeePercent}% (from Rocketscan)`);
      } else {
        try {
          const onChainInfo = await getPoolOnChainInfo(poolAddr);
          binStep = onChainInfo.binStep;
          baseFeePercent = onChainInfo.baseFeePercent;
          logger.info(`[SwapSniper] ${tokenSymbol}: binStep=${binStep}, baseFee=${baseFeePercent.toFixed(2)}% (from on-chain)`);
        } catch (err) {
          logger.warn(`[SwapSniper] ${tokenSymbol}: Failed to load on-chain info: ${err.message}`);
          continue; // retry next cycle
        }
      }

      // h. Filter binStep & baseFee
      if (binStep < config.minBinStep) {
        logger.debug(`[SwapSniper] ${tokenSymbol}: binStep ${binStep} < min ${config.minBinStep}, skip`);
        seenPools.add(poolAddr);
        continue;
      }
      if (baseFeePercent < config.minBaseFee) {
        logger.debug(`[SwapSniper] ${tokenSymbol}: baseFee ${baseFeePercent}% < min ${config.minBaseFee}%, skip`);
        seenPools.add(poolAddr);
        continue;
      }

      // i. Load pool on-chain → check bin arrays paid (sama seperti Mode 4)
      let dlmmPool;
      try {
        dlmmPool = await loadPool(poolAddr);
      } catch (err) {
        logger.warn(`[SwapSniper] ${tokenSymbol}: Failed to load pool: ${err.message}`);
        continue; // retry next cycle
      }

      const { binId: activeBinId } = await getActiveBin(dlmmPool);
      const onChainMintX = dlmmPool.lbPair.tokenXMint.toBase58();
      const onChainMintY = dlmmPool.lbPair.tokenYMint.toBase58();
      const xIsSOL = onChainMintX === SOL_MINT;
      const yIsSOL = onChainMintY === SOL_MINT;

      if (!xIsSOL && !yIsSOL) {
        logger.debug(`[SwapSniper] ${tokenSymbol}: Pool bukan pair SOL (on-chain), skip`);
        seenPools.add(poolAddr);
        continue;
      }

      const totalBins = sniperBinCount(binStep);
      let minBinId, maxBinId;

      if (yIsSOL) {
        minBinId = activeBinId;
        maxBinId = activeBinId + (totalBins - 1);
      } else {
        maxBinId = activeBinId;
        minBinId = activeBinId - (totalBins - 1);
      }

      const binCheck = await checkBinArrays(dlmmPool, minBinId, maxBinId);
      logger.info(`[SwapSniper] ${tokenSymbol}: Bin check — ${binCheck.totalBins} bins | ${binCheck.newBinArrays} new arrays | Cost: ${binCheck.costSOL} SOL`);

      if (!binCheck.safe) {
        logger.warn(`[SwapSniper] ${tokenSymbol}: Bins NOT paid — will retry next cycle`);
        continue; // DON'T add to seenPools
      }

      // === BINS PAID — PROCEED ===

      // j. Swap SOL → token
      logger.info(`[SwapSniper] ${tokenSymbol}: Buying ${poolName} (${shortenAddress(poolAddr)})...`);
      logger.info(`[SwapSniper]   MCap: $${mcap.toLocaleString()} | BinStep: ${binStep} | Fee: ${baseFeePercent}% | Active bin: ${activeBinId}`);

      const depositLamports = Math.floor(config.sniperDepositSOL * 1e9);
      const connection = getConnection();
      const wallet = getWallet();

      logger.info(`[SwapSniper] Swapping ${config.sniperDepositSOL} SOL → ${tokenSymbol}...`);
      try {
        await retry(
          () => executeSwap(SOL_MINT, tokenMint, depositLamports),
          config.maxRetries
        );
      } catch (swapErr) {
        logger.error(`[SwapSniper] Swap failed for ${tokenSymbol}: ${swapErr.message}, retry next cycle`);
        continue; // JANGAN seenPools
      }

      // j. Verify token balance
      await sleep(1000);
      const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
      logger.info(`[SwapSniper] Token balance after swap: ${tokenBal} (${tokenSymbol})`);

      if (tokenBal <= 0n) {
        logger.warn(`[SwapSniper] ${tokenSymbol}: No token balance after swap`);
        seenPools.add(poolAddr);
        continue;
      }

      // k. Track deposit & add to activeSwaps
      await trackSwapDeposit(tokenMint, depositLamports);
      activeSwaps.set(tokenMint, {
        symbol: tokenSymbol,
        poolAddr,
        depositSOL: config.sniperDepositSOL,
      });

      seenPools.add(poolAddr);

      sendTelegramAlert(
        `🎯 <b>Swap Sniper: Buy</b>\nToken: ${tokenSymbol}\nMint: <code>${tokenMint}</code>\nPool: <code>${poolAddr}</code>\nSwap: ${config.sniperDepositSOL} SOL → ${tokenSymbol}\nBalance: ${tokenBal.toString()}\nMCap: $${mcap.toLocaleString()}\nBinStep: ${binStep} | Fee: ${baseFeePercent}%\nMode: Swap Sniper`
      );

      logger.info(`[SwapSniper] ${tokenSymbol}: Bought! Tracking PnL...`);
      await sleep(2000);
    }

    logger.info('[SwapSniper] === Swap Sniper Cycle End ===\n');
  } catch (err) {
    logger.error(`[SwapSniper] Cycle error: ${err.message}`);
  }
}

/**
 * Swap token back to SOL (Mode 5 "remove").
 * Calculates PnL, swaps, applies cooldown/blacklist, cleanup.
 */
async function swapBackToSOL(tokenMint, reason, permanentBlacklist = false) {
  const entry = activeSwaps.get(tokenMint);
  if (!entry) return;

  logger.warn(`${reason} — Swapping ${entry.symbol} back to SOL...`);

  const connection = getConnection();
  const wallet = getWallet();
  const solBefore = await getSOLBalance(connection, wallet.publicKey);

  // Swap token → SOL
  const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
  if (tokenBal > 0n) {
    try {
      await retry(() => executeSwap(tokenMint, SOL_MINT, tokenBal.toString()), config.maxRetries);
      logger.info(`Swap ${entry.symbol} → SOL done.`);
    } catch (swapErr) {
      logger.error(`Swap back failed: ${swapErr.message}`);
    }
  } else {
    logger.warn(`[SwapSniper] No token balance to swap for ${entry.symbol}`);
  }

  await sleep(1000);
  const solAfter = await getSOLBalance(connection, wallet.publicKey);
  const solDiff = solAfter - solBefore;

  // Fetch actual PnL dari Jupiter PnL Activity API (setelah sell)
  let pnlUSD = 0, pnlPercent = 0, cost = 0;
  let pnlSource = 'fallback';
  try {
    await sleep(5000); // tunggu Jupiter index sell tx
    const walletAddr = wallet.publicKey.toBase58();
    const pnlData = await retry(() => fetchPnlActivity(walletAddr, tokenMint), 3);
    if (pnlData && pnlData.cost > 0) {
      pnlUSD = pnlData.profit;
      cost = pnlData.cost;
      pnlPercent = (pnlUSD / cost) * 100;
      pnlSource = 'jupiter';
      logger.info(`[SwapSniper] Jupiter PnL: profit $${pnlUSD.toFixed(4)} | cost $${cost.toFixed(4)} | ${pnlPercent.toFixed(2)}%`);
    } else {
      logger.warn(`[SwapSniper] Jupiter PnL returned cost=0, using fallback`);
      throw new Error('cost=0');
    }
  } catch (err) {
    if (err.message !== 'cost=0') {
      logger.warn(`[SwapSniper] Jupiter PnL fetch failed: ${err.message}, using fallback`);
    }
    // Fallback: depositUSD + SOL diff
    const depositUSD = getSwapDepositUSD(tokenMint);
    const prices = await fetchTokenPrices([SOL_MINT]);
    const solPrice = prices[SOL_MINT] || 0;
    const returnedUSD = (Number(solAfter - solBefore) / 1e9) * solPrice;
    cost = depositUSD;
    pnlUSD = returnedUSD - depositUSD;
    pnlPercent = depositUSD > 0 ? (pnlUSD / depositUSD) * 100 : 0;
    pnlSource = 'fallback';
    logger.info(`[SwapSniper] Fallback PnL: cost $${cost.toFixed(4)} | diff $${returnedUSD.toFixed(4)} | pnl $${pnlUSD.toFixed(4)} (${pnlPercent.toFixed(2)}%)`);
  }

  const pnlSign = pnlPercent >= 0 ? '+' : '';
  const pnlTag = pnlSource === 'jupiter' ? '' : ' (est)';
  sendTelegramAlert(
    `🔻 <b>Swap Sniper: Sell</b>\nToken: ${entry.symbol}\nMint: <code>${tokenMint}</code>\nReason: ${reason}\nCost: $${cost.toFixed(4)}\nPnL${pnlTag}: <b>${pnlSign}${pnlPercent.toFixed(2)}%</b> (${pnlSign}$${pnlUSD.toFixed(4)})\nSOL before: ${formatSOL(solBefore)}\nSOL after: ${formatSOL(solAfter)}\nDiff: ${solDiff >= 0 ? '+' : ''}${formatSOL(solDiff)} SOL\nMode: Swap Sniper`
  );

  // Cooldown / blacklist
  if (permanentBlacklist) {
    tokenCooldowns.set(tokenMint, { until: Infinity, poolAddr: entry.poolAddr });
    logger.warn(`[Blacklist] ${entry.symbol} permanently blacklisted`);
  } else if (config.cooldownHours > 0) {
    const until = Date.now() + config.cooldownHours * 60 * 60 * 1000;
    tokenCooldowns.set(tokenMint, { until, poolAddr: entry.poolAddr });
    logger.info(`[Cooldown] ${entry.symbol} cooldown ${config.cooldownHours}h`);
  } else {
    tokenCooldowns.set(tokenMint, { until: Infinity, poolAddr: entry.poolAddr });
    logger.info(`[Blacklist] ${entry.symbol} permanently skipped`);
  }

  // Cleanup
  clearSwapTracking(tokenMint);
  peakPnl.delete(tokenMint);
  tpTrailing.delete(tokenMint);
  activeSwaps.delete(tokenMint);
}

/**
 * Check TP/SL for swap-only positions (Mode 5).
 * PnL = current token value - deposit USD.
 */
async function checkSwapTpSl() {
  const tp = config.takeProfitPercent;
  const sl = config.stopLossPercent;
  if (!tp && !sl) return;

  const connection = getConnection();
  const wallet = getWallet();

  const tokenMints = [...activeSwaps.keys()];
  if (tokenMints.length === 0) return;

  // Batch fetch prices & metadata
  const prices = await fetchTokenPrices(tokenMints);
  const metadata = await fetchTokenMetadata(tokenMints);

  for (const tokenMint of tokenMints) {
    if (!activeSwaps.has(tokenMint)) continue; // might've been sold
    const entry = activeSwaps.get(tokenMint);

    try {
      const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
      const meta = metadata[tokenMint] || { decimals: 9 };
      const tokenPrice = prices[tokenMint] || 0;

      const currentUSD = (Number(tokenBal) / 10 ** meta.decimals) * tokenPrice;
      const depositUSD = getSwapDepositUSD(tokenMint);
      const pnlUSD = currentUSD - depositUSD;
      const pnl = depositUSD > 0 ? (pnlUSD / depositUSD) * 100 : 0;

      const peak = peakPnl.get(tokenMint) || 0;
      if (pnl > peak) peakPnl.set(tokenMint, pnl);
      const currentPeak = peakPnl.get(tokenMint) || 0;

      // === TAKE PROFIT ===
      if (tp) {
        if (config.trailingTP) {
          // Trailing TP: aktifkan trailing saat PnL >= TP
          if (pnl >= tp && !tpTrailing.has(tokenMint)) {
            tpTrailing.add(tokenMint);
            logger.info(`[Trailing TP][Swap] ${entry.symbol} activated (PnL: +${pnl.toFixed(2)}% >= TP +${tp}%)`);
          }
          if (tpTrailing.has(tokenMint)) {
            const trailTrigger = currentPeak - config.trailingTPPercent;
            logger.info(`[Trailing TP][Swap] ${entry.symbol} PnL: +${pnl.toFixed(2)}% | Peak: +${currentPeak.toFixed(2)}% | Trail exit: +${trailTrigger.toFixed(2)}%`);
            if (pnl <= trailTrigger) {
              logger.warn(`TRAILING TP HIT! ${entry.symbol} PnL: +${pnl.toFixed(2)}% (peak: +${currentPeak.toFixed(2)}%)`);
              sendTelegramAlert(
                `🟢 <b>TRAILING TP HIT (Swap)</b>\nToken: ${entry.symbol}\nPnL: <b>+${pnl.toFixed(2)}%</b> ($${pnlUSD.toFixed(4)})\nPeak: +${currentPeak.toFixed(2)}% | Trail: ${config.trailingTPPercent}%\n⏳ Cooldown ${config.cooldownHours}h\nMode: Swap Sniper`
              );
              await swapBackToSOL(tokenMint, `Trailing TP (peak +${currentPeak.toFixed(2)}%, exit +${pnl.toFixed(2)}%)`);
              continue;
            }
          }
        } else {
          // Fixed TP
          if (pnl >= tp) {
            logger.warn(`TAKE PROFIT HIT! ${entry.symbol} PnL: +${pnl.toFixed(2)}% >= +${tp}%`);
            sendTelegramAlert(
              `🟢 <b>TAKE PROFIT HIT (Swap)</b>\nToken: ${entry.symbol}\nPnL: <b>+${pnl.toFixed(2)}%</b> ($${pnlUSD.toFixed(4)})\nTP: +${tp}%\n⏳ Cooldown ${config.cooldownHours}h\nMode: Swap Sniper`
            );
            await swapBackToSOL(tokenMint, `TP +${tp}% hit (PnL: +${pnl.toFixed(2)}%)`);
            continue;
          }
        }
      }

      // === STOP LOSS ===
      if (sl) {
        if (config.trailingSL) {
          // Trailing SL: SL naik ikut peak
          const effectiveSL = currentPeak > 0 ? currentPeak - config.trailingSLPercent : sl;
          const finalSL = Math.max(effectiveSL, sl);
          if (pnl <= finalSL) {
            logger.warn(`TRAILING SL HIT! ${entry.symbol} PnL: ${pnl.toFixed(2)}% <= ${finalSL.toFixed(2)}% (peak: +${currentPeak.toFixed(2)}%)`);
            sendTelegramAlert(
              `🔴 <b>TRAILING SL HIT (Swap)</b>\nToken: ${entry.symbol}\nPnL: <b>${pnl.toFixed(2)}%</b> ($${pnlUSD.toFixed(4)})\nEffective SL: ${finalSL.toFixed(2)}% | Peak: +${currentPeak.toFixed(2)}%\n⛔ Token blacklisted\nMode: Swap Sniper`
            );
            await swapBackToSOL(tokenMint, `Trailing SL (effective ${finalSL.toFixed(2)}%, PnL ${pnl.toFixed(2)}%)`, true);
            continue;
          }
        } else {
          // Fixed SL
          if (pnl <= sl) {
            logger.warn(`STOP LOSS HIT! ${entry.symbol} PnL: ${pnl.toFixed(2)}% <= ${sl}%`);
            sendTelegramAlert(
              `🔴 <b>STOP LOSS HIT (Swap)</b>\nToken: ${entry.symbol}\nPnL: <b>${pnl.toFixed(2)}%</b> ($${pnlUSD.toFixed(4)})\nSL: ${sl}%\n⛔ Token blacklisted\nMode: Swap Sniper`
            );
            await swapBackToSOL(tokenMint, `SL ${sl}% hit (PnL: ${pnl.toFixed(2)}%)`, true);
            continue;
          }
        }
      }
    } catch (err) {
      logger.error(`[SwapTP/SL] ${entry.symbol} check failed: ${err.message}`);
    }
  }
}

/**
 * Print dashboard for swap-only positions (Mode 5).
 */
async function printSwapDashboard() {
  if (activeSwaps.size === 0) return;

  const connection = getConnection();
  const wallet = getWallet();

  const tokenMints = [...activeSwaps.keys()];
  const prices = await fetchTokenPrices(tokenMints);
  const metadata = await fetchTokenMetadata(tokenMints);

  console.log('\n' + '─'.repeat(60));
  console.log('  SWAP SNIPER POSITIONS');
  console.log('  ' + new Date().toISOString());
  console.log('─'.repeat(60));

  let grandDeposit = 0, grandCurrent = 0;

  for (const tokenMint of tokenMints) {
    const entry = activeSwaps.get(tokenMint);
    if (!entry) continue;

    const meta = metadata[tokenMint] || { symbol: entry.symbol, decimals: 9 };
    const tokenPrice = prices[tokenMint] || 0;
    const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);

    const currentUSD = (Number(tokenBal) / 10 ** meta.decimals) * tokenPrice;
    const depositUSD = getSwapDepositUSD(tokenMint);
    const pnlUSD = currentUSD - depositUSD;
    const pnlPercent = depositUSD > 0 ? (pnlUSD / depositUSD) * 100 : 0;

    const pnlColor = pnlUSD >= 0 ? '\x1b[32m' : '\x1b[31m';
    const pnlSign = pnlUSD >= 0 ? '+' : '';

    console.log(`\n  ${entry.symbol} | ${shortenAddress(tokenMint)}`);
    console.log(`    Price: $${tokenPrice.toFixed(8)}`);
    console.log(`    Balance: ${formatHuman(tokenBal.toString(), meta.decimals)} ($${currentUSD.toFixed(4)})`);
    console.log(`    Deposit: $${depositUSD.toFixed(4)} (${entry.depositSOL} SOL)`);
    console.log(`    PnL: ${pnlColor}${pnlSign}$${pnlUSD.toFixed(4)} (${pnlSign}${pnlPercent.toFixed(2)}%)\x1b[0m`);

    grandDeposit += depositUSD;
    grandCurrent += currentUSD;
  }

  if (activeSwaps.size > 1) {
    const grandPnl = grandCurrent - grandDeposit;
    const grandPct = grandDeposit > 0 ? (grandPnl / grandDeposit) * 100 : 0;
    const gc = grandPnl >= 0 ? '\x1b[32m' : '\x1b[31m';
    const gs = grandPnl >= 0 ? '+' : '';
    console.log('\n  ' + '─'.repeat(47));
    console.log(`  TOTAL | Current: $${grandCurrent.toFixed(4)} | Deposit: $${grandDeposit.toFixed(4)}`);
    console.log(`  TOTAL | PnL: ${gc}${gs}$${grandPnl.toFixed(4)} (${gs}${grandPct.toFixed(2)}%)\x1b[0m`);
  }

  console.log('\n' + '─'.repeat(60) + '\n');
}

// ============================================================
//  GEM SNIPER MODE (Mode 6)
// ============================================================

async function gemSniperMode() {
  console.log('\n  ┌─────────────────────────────────────────────┐');
  console.log('  │     GEM SNIPER MODE - Graduated Tokens       │');
  console.log(`  │  Deposit: ${String(config.gemSniperDepositSOL + ' SOL (swap → token)').padEnd(32)}│`);
  console.log(`  │  Max Token: ${String(config.gemSniperMaxToken + ' (1 token = 1 swap)').padEnd(29)}│`);
  console.log(`  │  Smart WinRate: ${String('>=' + config.gemSniperSmartWinRate + '%').padEnd(24)}│`);
  console.log(`  │  Min Smart %: ${String(config.gemSniperMinSmartPct + '%').padEnd(27)}│`);
  console.log(`  │  Interval: ${String(config.gemSniperIntervalSec + 's').padEnd(31)}│`);
  console.log(`  │  Mode: ${'Graduated gems + smart wallet'.padEnd(36)}│`);
  console.log('  └─────────────────────────────────────────────┘\n');

  logger.info('[GemSniper] Starting gem sniper mode... polling every ' + config.gemSniperIntervalSec + 's');

  // First run: skip existing graduated tokens
  logger.info('[GemSniper] First run — skipping existing graduated tokens...');
  try {
    const initialTokens = await retry(() => fetchGraduateTokens(), config.maxRetries);
    if (initialTokens && initialTokens.length > 0) {
      for (const t of initialTokens) {
        const mint = t.id || t.mint;
        if (mint) seenGemTokens.add(mint);
      }
      logger.info(`[GemSniper] Skipped ${initialTokens.length} existing token(s). Only new graduates will be sniped.`);
    }
  } catch (err) {
    logger.warn(`[GemSniper] First run fetch failed: ${err.message}`);
  }

  // Start polling loop
  setInterval(() => {
    if (!isShuttingDown) gemSniperCycle();
  }, config.gemSniperIntervalSec * 1000);
}

/**
 * Single gem sniper polling cycle.
 * Source: Jupiter Graduated Gems API
 * Filter: vol/mcap/organic → smart wallet scoring → optional DLMM bonus → swap
 */
async function gemSniperCycle() {
  try {
    logger.info('[GemSniper] === Gem Sniper Cycle ===');

    let graduatedTokens;
    try {
      graduatedTokens = await retry(() => fetchGraduateTokens(), config.maxRetries);
    } catch (err) {
      logger.warn(`[GemSniper] Failed to fetch graduated tokens: ${err.message}`);
      return;
    }

    if (!graduatedTokens || graduatedTokens.length === 0) {
      logger.info('[GemSniper] No graduated tokens found.');
      return;
    }

    // Collect new token mints for batch stats fetch
    const candidateMints = [];
    for (const t of graduatedTokens) {
      const mint = t.id || t.mint;
      if (!mint) continue;
      if (seenGemTokens.has(mint)) continue;
      if (!candidateMints.includes(mint)) candidateMints.push(mint);
    }

    if (candidateMints.length === 0) {
      logger.info('[GemSniper] No new graduated tokens this cycle.');
      return;
    }

    logger.info(`[GemSniper] ${candidateMints.length} new graduated token(s) to evaluate`);

    // Batch fetch token stats dari Jupiter
    let tokenStatsMap = new Map();
    try {
      tokenStatsMap = await retry(() => fetchTokenStats(candidateMints), config.maxRetries);
    } catch (err) {
      logger.warn(`[GemSniper] Jupiter stats fetch failed: ${err.message}`);
    }

    for (const token of graduatedTokens) {
      const tokenMint = token.id || token.mint;
      const tokenSymbol = token.symbol || '?';
      if (!tokenMint) continue;

      // 1. Skip already seen
      if (seenGemTokens.has(tokenMint)) continue;

      // 2. Max token check
      if (activeGemSwaps.size >= config.gemSniperMaxToken) {
        logger.warn(`[GemSniper] Max tokens (${config.gemSniperMaxToken}) reached, stop scanning.`);
        break;
      }

      // 3. Blacklist / cooldown / already active
      if (config.blacklistTokens.includes(tokenMint)) {
        logger.debug(`[GemSniper] ${tokenSymbol}: blacklisted, skip`);
        seenGemTokens.add(tokenMint);
        continue;
      }

      const cd = tokenCooldowns.get(tokenMint);
      if (cd && Date.now() < cd.until) {
        logger.debug(`[GemSniper] ${tokenSymbol}: cooldown active, skip`);
        seenGemTokens.add(tokenMint);
        continue;
      }
      if (cd) tokenCooldowns.delete(tokenMint);

      if (activeGemSwaps.has(tokenMint)) {
        logger.debug(`[GemSniper] ${tokenSymbol}: already holding, skip`);
        continue;
      }

      // 4. Volume / MCap / Organic ratio filter (reuse existing stats)
      const jupStats = tokenStatsMap.get(tokenMint);
      const volume5m = jupStats?.volume5m || 0;
      const mcap = jupStats?.mcap || token.mcap || 0;
      const organicVolume5m = jupStats?.organicVolume5m || 0;
      const organicRatio = volume5m > 0 ? (organicVolume5m / volume5m) * 100 : 0;

      if (config.sniperMinVolume5m > 0 && volume5m < config.sniperMinVolume5m) {
        logger.debug(`[GemSniper] ${tokenSymbol}: volume5m $${volume5m.toLocaleString()} < min $${config.sniperMinVolume5m.toLocaleString()}, retry next cycle`);
        continue; // Don't add to seenGemTokens — retry
      }

      if (config.sniperMaxMcap > 0 && mcap > config.sniperMaxMcap) {
        logger.debug(`[GemSniper] ${tokenSymbol}: mcap $${mcap.toLocaleString()} > max $${config.sniperMaxMcap.toLocaleString()}, skip`);
        seenGemTokens.add(tokenMint);
        continue;
      }

      if (config.sniperMinOrganicRatio > 0 && organicRatio < config.sniperMinOrganicRatio) {
        logger.debug(`[GemSniper] ${tokenSymbol}: organic ratio ${organicRatio.toFixed(1)}% < min ${config.sniperMinOrganicRatio}%, retry next cycle`);
        continue;
      }

      logger.info(`[GemSniper] ${tokenSymbol}: vol5m $${volume5m.toLocaleString()} | mcap $${mcap.toLocaleString()} | organic ${organicRatio.toFixed(1)}% — stats OK`);

      // 5. Smart wallet scoring (WAJIB)
      let smartScore = 0;
      let holderCount = 0;
      try {
        const holders = await fetchTokenHolders(tokenMint);
        holderCount = Array.isArray(holders) ? holders.length : (holders?.count || 0);
        const holderList = Array.isArray(holders) ? holders : (holders?.holders || holders?.data || []);
        const topHolders = holderList.slice(0, config.gemSniperTopHolders);

        let smartCount = 0;
        let checkedCount = 0;

        for (const holder of topHolders) {
          const addr = holder.address || holder.owner || holder.wallet;
          if (!addr) continue;

          try {
            const [pnlStats, positions] = await Promise.all([
              fetchWalletPnlStats(addr),
              fetchWalletPositions(addr),
            ]);

            const winRate = pnlStats?.winRate || pnlStats?.win_rate || 0;
            const totalTrades = (pnlStats?.totalBuys || 0) + (pnlStats?.totalSells || 0);
            const hasActivePositions = Array.isArray(positions) && positions.length > 0;
            const hasEnoughTrades = totalTrades >= config.gemSniperMinTrades;
            const isSmart = winRate >= config.gemSniperSmartWinRate && hasActivePositions && hasEnoughTrades;

            checkedCount++;
            if (isSmart) smartCount++;

            logger.debug(`[GemSniper] ${tokenSymbol} holder ${shortenAddress(addr)}: winRate=${winRate.toFixed(1)}% trades=${totalTrades} active=${hasActivePositions} → ${isSmart ? 'SMART' : 'not smart'}`);
          } catch (err) {
            logger.debug(`[GemSniper] Failed to check holder ${shortenAddress(addr)}: ${err.message}`);
          }

          await sleep(200); // Rate limiting
        }

        smartScore = checkedCount > 0 ? (smartCount / checkedCount) * 100 : 0;
        logger.info(`[GemSniper] ${tokenSymbol}: Smart wallet score = ${smartScore.toFixed(1)}% (${smartCount}/${checkedCount} smart)`);
      } catch (err) {
        logger.warn(`[GemSniper] ${tokenSymbol}: Smart wallet check failed: ${err.message}, retry next cycle`);
        continue;
      }

      // 6. Holder snapshot
      gemHolderSnapshots.set(tokenMint, holderCount);

      // 7. Smart threshold check
      if (config.gemSniperMinSmartPct > 0 && smartScore < config.gemSniperMinSmartPct) {
        logger.info(`[GemSniper] ${tokenSymbol}: Smart score ${smartScore.toFixed(1)}% < min ${config.gemSniperMinSmartPct}%, retry next cycle`);
        continue;
      }

      // 8. DLMM pool + bin paid check (configurable)
      let dlmmBonusInfo = '';
      if (config.gemSniperRequireDlmm) {
        let dlmmPassed = false;
        try {
          const dlmmPools = await fetchDlmmPools(tokenMint, tokenSymbol);
          if (dlmmPools.length > 0) {
            const solPools = dlmmPools.filter(p => (p.tokenA?.mint || '') === SOL_MINT);
            if (solPools.length > 0) {
              const hasBinsPaid = solPools.some(p => p.processingMetadata?.meteoraIndexed);
              if (hasBinsPaid) {
                dlmmPassed = true;
                dlmmBonusInfo = 'DLMM + bins paid';
                logger.info(`[GemSniper] ${tokenSymbol}: ${dlmmBonusInfo} — OK`);
              } else {
                logger.info(`[GemSniper] ${tokenSymbol}: DLMM pool found but bins NOT paid, retry next cycle`);
              }
            } else {
              logger.info(`[GemSniper] ${tokenSymbol}: No DLMM SOL pair, retry next cycle`);
            }
          } else {
            logger.info(`[GemSniper] ${tokenSymbol}: No DLMM pool, retry next cycle`);
          }
        } catch (err) {
          logger.warn(`[GemSniper] ${tokenSymbol}: DLMM check failed: ${err.message}, retry next cycle`);
        }

        if (!dlmmPassed) continue;
      } else {
        logger.info(`[GemSniper] ${tokenSymbol}: DLMM check disabled, skip`);
      }

      // 8. Swap SOL → token via Jupiter
      logger.info(`[GemSniper] ${tokenSymbol}: Buying — smart score ${smartScore.toFixed(1)}% | holders ${holderCount}`);

      const depositLamports = Math.floor(config.gemSniperDepositSOL * 1e9);

      logger.info(`[GemSniper] Swapping ${config.gemSniperDepositSOL} SOL → ${tokenSymbol}...`);
      try {
        await retry(
          () => executeSwap(SOL_MINT, tokenMint, depositLamports),
          config.maxRetries
        );
      } catch (swapErr) {
        logger.error(`[GemSniper] Swap failed for ${tokenSymbol}: ${swapErr.message}, retry next cycle`);
        continue;
      }

      // Verify token balance
      await sleep(1000);
      const connection = getConnection();
      const wallet = getWallet();
      const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
      logger.info(`[GemSniper] Token balance after swap: ${tokenBal} (${tokenSymbol})`);

      if (tokenBal <= 0n) {
        logger.warn(`[GemSniper] ${tokenSymbol}: No token balance after swap`);
        seenGemTokens.add(tokenMint);
        continue;
      }

      // 9. Track deposit + add to activeGemSwaps
      await trackSwapDeposit(tokenMint, depositLamports);
      activeGemSwaps.set(tokenMint, {
        symbol: tokenSymbol,
        depositSOL: config.gemSniperDepositSOL,
        smartScore,
        holderSnapshot: holderCount,
      });

      seenGemTokens.add(tokenMint);

      sendTelegramAlert(
        `💎 <b>Gem Sniper: Buy</b>\nToken: ${tokenSymbol}\nMint: <code>${tokenMint}</code>\nSwap: ${config.gemSniperDepositSOL} SOL → ${tokenSymbol}\nBalance: ${tokenBal.toString()}\nMCap: $${mcap.toLocaleString()}\nSmart Score: ${smartScore.toFixed(1)}%\nHolders: ${holderCount}\n${dlmmBonusInfo ? dlmmBonusInfo + '\n' : ''}Mode: Gem Sniper`
      );

      logger.info(`[GemSniper] ${tokenSymbol}: Bought! Tracking PnL...`);
      await sleep(2000);
    }

    logger.info('[GemSniper] === Gem Sniper Cycle End ===\n');
  } catch (err) {
    logger.error(`[GemSniper] Cycle error: ${err.message}`);
  }
}

/**
 * Swap gem token back to SOL (Mode 6 "remove").
 */
async function swapGemBackToSOL(tokenMint, reason, permanentBlacklist = false) {
  const entry = activeGemSwaps.get(tokenMint);
  if (!entry) return;

  logger.warn(`${reason} — Swapping ${entry.symbol} back to SOL...`);

  const connection = getConnection();
  const wallet = getWallet();
  const solBefore = await getSOLBalance(connection, wallet.publicKey);

  // Swap token → SOL
  const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
  if (tokenBal > 0n) {
    try {
      await retry(() => executeSwap(tokenMint, SOL_MINT, tokenBal.toString()), config.maxRetries);
      logger.info(`Swap ${entry.symbol} → SOL done.`);
    } catch (swapErr) {
      logger.error(`Swap back failed: ${swapErr.message}`);
    }
  } else {
    logger.warn(`[GemSniper] No token balance to swap for ${entry.symbol}`);
  }

  await sleep(1000);
  const solAfter = await getSOLBalance(connection, wallet.publicKey);
  const solDiff = solAfter - solBefore;

  // Fetch actual PnL dari Jupiter PnL Activity API
  let pnlUSD = 0, pnlPercent = 0, cost = 0;
  let pnlSource = 'fallback';
  try {
    await sleep(5000);
    const walletAddr = wallet.publicKey.toBase58();
    const pnlData = await retry(() => fetchPnlActivity(walletAddr, tokenMint), 3);
    if (pnlData && pnlData.cost > 0) {
      pnlUSD = pnlData.profit;
      cost = pnlData.cost;
      pnlPercent = (pnlUSD / cost) * 100;
      pnlSource = 'jupiter';
      logger.info(`[GemSniper] Jupiter PnL: profit $${pnlUSD.toFixed(4)} | cost $${cost.toFixed(4)} | ${pnlPercent.toFixed(2)}%`);
    } else {
      throw new Error('cost=0');
    }
  } catch (err) {
    if (err.message !== 'cost=0') {
      logger.warn(`[GemSniper] Jupiter PnL fetch failed: ${err.message}, using fallback`);
    }
    const depositUSD = getSwapDepositUSD(tokenMint);
    const prices = await fetchTokenPrices([SOL_MINT]);
    const solPrice = prices[SOL_MINT] || 0;
    const returnedUSD = (Number(solAfter - solBefore) / 1e9) * solPrice;
    cost = depositUSD;
    pnlUSD = returnedUSD - depositUSD;
    pnlPercent = depositUSD > 0 ? (pnlUSD / depositUSD) * 100 : 0;
    pnlSource = 'fallback';
    logger.info(`[GemSniper] Fallback PnL: cost $${cost.toFixed(4)} | diff $${returnedUSD.toFixed(4)} | pnl $${pnlUSD.toFixed(4)} (${pnlPercent.toFixed(2)}%)`);
  }

  const pnlSign = pnlPercent >= 0 ? '+' : '';
  const pnlTag = pnlSource === 'jupiter' ? '' : ' (est)';
  sendTelegramAlert(
    `🔻 <b>Gem Sniper: Sell</b>\nToken: ${entry.symbol}\nMint: <code>${tokenMint}</code>\nReason: ${reason}\nCost: $${cost.toFixed(4)}\nPnL${pnlTag}: <b>${pnlSign}${pnlPercent.toFixed(2)}%</b> (${pnlSign}$${pnlUSD.toFixed(4)})\nSmart Score: ${entry.smartScore.toFixed(1)}%\nSOL before: ${formatSOL(solBefore)}\nSOL after: ${formatSOL(solAfter)}\nDiff: ${solDiff >= 0 ? '+' : ''}${formatSOL(solDiff)} SOL\nMode: Gem Sniper`
  );

  // Cooldown / blacklist
  if (permanentBlacklist) {
    tokenCooldowns.set(tokenMint, { until: Infinity });
    logger.warn(`[Blacklist] ${entry.symbol} permanently blacklisted`);
  } else if (config.cooldownHours > 0) {
    const until = Date.now() + config.cooldownHours * 60 * 60 * 1000;
    tokenCooldowns.set(tokenMint, { until });
    logger.info(`[Cooldown] ${entry.symbol} cooldown ${config.cooldownHours}h`);
  } else {
    tokenCooldowns.set(tokenMint, { until: Infinity });
    logger.info(`[Blacklist] ${entry.symbol} permanently skipped`);
  }

  // Cleanup
  clearSwapTracking(tokenMint);
  peakPnl.delete(tokenMint);
  tpTrailing.delete(tokenMint);
  gemHolderSnapshots.delete(tokenMint);
  activeGemSwaps.delete(tokenMint);
}

/**
 * Check TP/SL for gem swap positions (Mode 6).
 * Same trailing TP/SL logic as Mode 5 + holder increase tracking.
 */
async function checkGemTpSl() {
  const tp = config.takeProfitPercent;
  const sl = config.stopLossPercent;
  if (!tp && !sl) return;

  const connection = getConnection();
  const wallet = getWallet();

  const tokenMints = [...activeGemSwaps.keys()];
  if (tokenMints.length === 0) return;

  const prices = await fetchTokenPrices(tokenMints);
  const metadata = await fetchTokenMetadata(tokenMints);

  for (const tokenMint of tokenMints) {
    if (!activeGemSwaps.has(tokenMint)) continue;
    const entry = activeGemSwaps.get(tokenMint);

    try {
      const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);
      const meta = metadata[tokenMint] || { decimals: 9 };
      const tokenPrice = prices[tokenMint] || 0;

      const currentUSD = (Number(tokenBal) / 10 ** meta.decimals) * tokenPrice;
      const depositUSD = getSwapDepositUSD(tokenMint);
      const pnlUSD = currentUSD - depositUSD;
      const pnl = depositUSD > 0 ? (pnlUSD / depositUSD) * 100 : 0;

      const peak = peakPnl.get(tokenMint) || 0;
      if (pnl > peak) peakPnl.set(tokenMint, pnl);
      const currentPeak = peakPnl.get(tokenMint) || 0;

      // Holder increase tracking
      try {
        const holders = await fetchTokenHolders(tokenMint);
        const currentHolderCount = Array.isArray(holders) ? holders.length : (holders?.count || 0);
        const snapshotCount = gemHolderSnapshots.get(tokenMint) || 0;
        if (snapshotCount > 0 && currentHolderCount > 0) {
          const holderChange = ((currentHolderCount - snapshotCount) / snapshotCount) * 100;
          logger.info(`[GemSniper] ${entry.symbol} Holders: ${snapshotCount} → ${currentHolderCount} (${holderChange >= 0 ? '+' : ''}${holderChange.toFixed(1)}%)`);
        }
      } catch (err) {
        logger.debug(`[GemSniper] Holder re-fetch failed for ${entry.symbol}: ${err.message}`);
      }

      // === TAKE PROFIT ===
      if (tp) {
        if (config.trailingTP) {
          if (pnl >= tp && !tpTrailing.has(tokenMint)) {
            tpTrailing.add(tokenMint);
            logger.info(`[Trailing TP][Gem] ${entry.symbol} activated (PnL: +${pnl.toFixed(2)}% >= TP +${tp}%)`);
          }
          if (tpTrailing.has(tokenMint)) {
            const trailTrigger = currentPeak - config.trailingTPPercent;
            logger.info(`[Trailing TP][Gem] ${entry.symbol} PnL: +${pnl.toFixed(2)}% | Peak: +${currentPeak.toFixed(2)}% | Trail exit: +${trailTrigger.toFixed(2)}%`);
            if (pnl <= trailTrigger) {
              logger.warn(`TRAILING TP HIT! ${entry.symbol} PnL: +${pnl.toFixed(2)}% (peak: +${currentPeak.toFixed(2)}%)`);
              sendTelegramAlert(
                `🟢 <b>TRAILING TP HIT (Gem)</b>\nToken: ${entry.symbol}\nPnL: <b>+${pnl.toFixed(2)}%</b> ($${pnlUSD.toFixed(4)})\nPeak: +${currentPeak.toFixed(2)}% | Trail: ${config.trailingTPPercent}%\nSmart Score: ${entry.smartScore.toFixed(1)}%\n⏳ Cooldown ${config.cooldownHours}h\nMode: Gem Sniper`
              );
              await swapGemBackToSOL(tokenMint, `Trailing TP (peak +${currentPeak.toFixed(2)}%, exit +${pnl.toFixed(2)}%)`);
              continue;
            }
          }
        } else {
          if (pnl >= tp) {
            logger.warn(`TAKE PROFIT HIT! ${entry.symbol} PnL: +${pnl.toFixed(2)}% >= +${tp}%`);
            sendTelegramAlert(
              `🟢 <b>TAKE PROFIT HIT (Gem)</b>\nToken: ${entry.symbol}\nPnL: <b>+${pnl.toFixed(2)}%</b> ($${pnlUSD.toFixed(4)})\nTP: +${tp}%\nSmart Score: ${entry.smartScore.toFixed(1)}%\n⏳ Cooldown ${config.cooldownHours}h\nMode: Gem Sniper`
            );
            await swapGemBackToSOL(tokenMint, `TP +${tp}% hit (PnL: +${pnl.toFixed(2)}%)`);
            continue;
          }
        }
      }

      // === STOP LOSS ===
      if (sl) {
        if (config.trailingSL) {
          const effectiveSL = currentPeak > 0 ? currentPeak - config.trailingSLPercent : sl;
          const finalSL = Math.max(effectiveSL, sl);
          if (pnl <= finalSL) {
            logger.warn(`TRAILING SL HIT! ${entry.symbol} PnL: ${pnl.toFixed(2)}% <= ${finalSL.toFixed(2)}% (peak: +${currentPeak.toFixed(2)}%)`);
            sendTelegramAlert(
              `🔴 <b>TRAILING SL HIT (Gem)</b>\nToken: ${entry.symbol}\nPnL: <b>${pnl.toFixed(2)}%</b> ($${pnlUSD.toFixed(4)})\nEffective SL: ${finalSL.toFixed(2)}% | Peak: +${currentPeak.toFixed(2)}%\nSmart Score: ${entry.smartScore.toFixed(1)}%\n⛔ Token blacklisted\nMode: Gem Sniper`
            );
            await swapGemBackToSOL(tokenMint, `Trailing SL (effective ${finalSL.toFixed(2)}%, PnL ${pnl.toFixed(2)}%)`, true);
            continue;
          }
        } else {
          if (pnl <= sl) {
            logger.warn(`STOP LOSS HIT! ${entry.symbol} PnL: ${pnl.toFixed(2)}% <= ${sl}%`);
            sendTelegramAlert(
              `🔴 <b>STOP LOSS HIT (Gem)</b>\nToken: ${entry.symbol}\nPnL: <b>${pnl.toFixed(2)}%</b> ($${pnlUSD.toFixed(4)})\nSL: ${sl}%\nSmart Score: ${entry.smartScore.toFixed(1)}%\n⛔ Token blacklisted\nMode: Gem Sniper`
            );
            await swapGemBackToSOL(tokenMint, `SL ${sl}% hit (PnL: ${pnl.toFixed(2)}%)`, true);
            continue;
          }
        }
      }
    } catch (err) {
      logger.error(`[GemTP/SL] ${entry.symbol} check failed: ${err.message}`);
    }
  }
}

/**
 * Print dashboard for gem swap positions (Mode 6).
 * Includes smart wallet score and holder change columns.
 */
async function printGemDashboard() {
  if (activeGemSwaps.size === 0) return;

  const connection = getConnection();
  const wallet = getWallet();

  const tokenMints = [...activeGemSwaps.keys()];
  const prices = await fetchTokenPrices(tokenMints);
  const metadata = await fetchTokenMetadata(tokenMints);

  console.log('\n' + '─'.repeat(70));
  console.log('  GEM SNIPER POSITIONS');
  console.log('  ' + new Date().toISOString());
  console.log('─'.repeat(70));

  let grandDeposit = 0, grandCurrent = 0;

  for (const tokenMint of tokenMints) {
    const entry = activeGemSwaps.get(tokenMint);
    if (!entry) continue;

    const meta = metadata[tokenMint] || { symbol: entry.symbol, decimals: 9 };
    const tokenPrice = prices[tokenMint] || 0;
    const tokenBal = await getTokenBalance(connection, wallet.publicKey, tokenMint);

    const currentUSD = (Number(tokenBal) / 10 ** meta.decimals) * tokenPrice;
    const depositUSD = getSwapDepositUSD(tokenMint);
    const pnlUSD = currentUSD - depositUSD;
    const pnlPercent = depositUSD > 0 ? (pnlUSD / depositUSD) * 100 : 0;

    const pnlColor = pnlUSD >= 0 ? '\x1b[32m' : '\x1b[31m';
    const pnlSign = pnlUSD >= 0 ? '+' : '';

    // Holder change
    let holderInfo = '';
    try {
      const holders = await fetchTokenHolders(tokenMint);
      const currentHolderCount = Array.isArray(holders) ? holders.length : (holders?.count || 0);
      const snapshotCount = entry.holderSnapshot || 0;
      if (snapshotCount > 0 && currentHolderCount > 0) {
        const holderChange = ((currentHolderCount - snapshotCount) / snapshotCount) * 100;
        holderInfo = `${snapshotCount} → ${currentHolderCount} (${holderChange >= 0 ? '+' : ''}${holderChange.toFixed(1)}%)`;
      }
    } catch {
      holderInfo = 'N/A';
    }

    console.log(`\n  ${entry.symbol} | ${shortenAddress(tokenMint)}`);
    console.log(`    Price: $${tokenPrice.toFixed(8)}`);
    console.log(`    Balance: ${formatHuman(tokenBal.toString(), meta.decimals)} ($${currentUSD.toFixed(4)})`);
    console.log(`    Deposit: $${depositUSD.toFixed(4)} (${entry.depositSOL} SOL)`);
    console.log(`    PnL: ${pnlColor}${pnlSign}$${pnlUSD.toFixed(4)} (${pnlSign}${pnlPercent.toFixed(2)}%)\x1b[0m`);
    console.log(`    Smart Score: ${entry.smartScore.toFixed(1)}%`);
    if (holderInfo) console.log(`    Holders: ${holderInfo}`);

    grandDeposit += depositUSD;
    grandCurrent += currentUSD;
  }

  if (activeGemSwaps.size > 1) {
    const grandPnl = grandCurrent - grandDeposit;
    const grandPct = grandDeposit > 0 ? (grandPnl / grandDeposit) * 100 : 0;
    const gc = grandPnl >= 0 ? '\x1b[32m' : '\x1b[31m';
    const gs = grandPnl >= 0 ? '+' : '';
    console.log('\n  ' + '─'.repeat(47));
    console.log(`  TOTAL | Current: $${grandCurrent.toFixed(4)} | Deposit: $${grandDeposit.toFixed(4)}`);
    console.log(`  TOTAL | PnL: ${gc}${gs}$${grandPnl.toFixed(4)} (${gs}${grandPct.toFixed(2)}%)\x1b[0m`);
  }

  console.log('\n' + '─'.repeat(70) + '\n');
}

// ============================================================
//  SHUTDOWN
// ============================================================

async function shutdown() {
  if (isShuttingDown) return;
  isShuttingDown = true;
  logger.warn('\nShutting down...');

  if (rl) rl.close();

  if (config.removeOnShutdown && activePools.length > 0) {
    logger.warn('Removing all liquidity + swap back to SOL...');
    const pools = [...activePools];
    for (const poolAddr of pools) {
      try {
        await removeAndSwapToSOL(poolAddr, 'Shutdown');
      } catch (err) {
        logger.error(`Shutdown cleanup failed ${shortenAddress(poolAddr)}: ${err.message}`);
      }
    }
  }

  if (config.removeOnShutdown && activeSwaps.size > 0) {
    logger.warn('Swapping all tokens back to SOL (Mode 5)...');
    const tokens = [...activeSwaps.keys()];
    for (const tokenMint of tokens) {
      try {
        await swapBackToSOL(tokenMint, 'Shutdown');
      } catch (err) {
        logger.error(`Shutdown swap failed ${shortenAddress(tokenMint)}: ${err.message}`);
      }
    }
  }

  if (config.removeOnShutdown && activeGemSwaps.size > 0) {
    logger.warn('Swapping all gem tokens back to SOL (Mode 6)...');
    const tokens = [...activeGemSwaps.keys()];
    for (const tokenMint of tokens) {
      try {
        await swapGemBackToSOL(tokenMint, 'Shutdown');
      } catch (err) {
        logger.error(`Shutdown gem swap failed ${shortenAddress(tokenMint)}: ${err.message}`);
      }
    }
  }

  logger.info('Bot stopped.');
  process.exit(0);
}

// ============================================================
//  SCHEDULED TASKS
// ============================================================

function startScheduledTasks() {
  if (config.rebalance) {
    cron.schedule(`*/${config.rebalanceIntervalMin} * * * *`, () => {
      if (!isShuttingDown) rebalanceCycle();
    });
    logger.info(`Rebalance every ${config.rebalanceIntervalMin} min`);
  } else {
    logger.info('Rebalance: DISABLED');
  }

  if (config.autoClaim) {
    logger.info(`Auto Claim: ON (per-pool timer, every ${config.claimIntervalMin} min after add)`);
  } else {
    logger.info('Auto Claim: DISABLED (fees otomatis ikut saat remove liq)');
  }

  setInterval(() => {
    if (!isShuttingDown) monitorCycle();
  }, config.monitorIntervalSec * 1000);
  logger.info(`Monitor every ${config.monitorIntervalSec}s`);
}

// ============================================================
//  MAIN
// ============================================================

async function main() {
  console.log('\n');
  console.log('  ╔══════════════════════════════════════════╗');
  console.log('  ║       DLMM METEORA AUTO BOT v2.1        ║');
  console.log('  ║    One-Side SOL | Rebalance | Claim      ║');
  console.log('  ╚══════════════════════════════════════════╝');
  console.log('\n');

  try {
    initConnection();
  } catch (err) {
    logger.error(`Init failed: ${err.message}`);
    process.exit(1);
  }

  logger.info('Config:');
  logger.info(`  Strategy: ${config.strategy} | Bin range: ${config.binRange} (${resolveBinRange(config.binRange)} bins)`);
  logger.info(`  Deposit: ${config.depositAmountSOL} SOL (one-side) | Slippage: ${config.slippageBps}bps`);
  logger.info(`  Max positions: ${config.maxActivePositions} | Bin array cost limit: ${config.maxBinArrayCostSOL} SOL`);
  logger.info(`  TP: ${config.takeProfitPercent ? '+' + config.takeProfitPercent + '%' : 'OFF'} | SL: ${config.stopLossPercent ? config.stopLossPercent + '%' : 'OFF'} | Trailing: ${config.trailing ? 'ON (' + config.trailingPercent + '%)' : 'OFF'}`);
  logger.info(`  OOR Right: wait ${config.oorRightWaitMin} min → re-add | OOR Left: remove + swap SOL`);

  rl = readline.createInterface({ input: process.stdin, output: process.stdout });

  console.log('\n  Mode:');
  console.log('    1. Manual     - Input pool address (one-side SOL)');
  console.log('    2. Auto       - Auto-discover + one-side SOL');
  console.log('    3. Copy Trade - Copy target wallet DLMM positions');
  console.log('    4. Sniper     - Fresh token X-only BidAsk');
  console.log('    5. Swap Sniper- Fresh token swap only (no LP)');
  console.log('    6. Gem Sniper - Graduated tokens + smart wallet');
  console.log('');

  const mode = await ask('Pilih mode (1/2/3/4/5/6): ');

  startScheduledTasks();

  if (mode === '1' || mode.toLowerCase() === 'manual') {
    const result = await manualInputMode();
    if (result === 'auto') {
      logger.info('Starting auto-discovery...');
      await discoverAndExecute();
      setInterval(() => {
        if (!isShuttingDown) discoverAndExecute();
      }, config.discoveryIntervalSec * 1000);
    }
  } else if (mode === '3' || mode.toLowerCase() === 'copy') {
    await copyTradeMode();
  } else if (mode === '4' || mode.toLowerCase() === 'sniper') {
    await sniperMode();
  } else if (mode === '5' || mode.toLowerCase() === 'swap') {
    await swapSniperMode();
  } else if (mode === '6' || mode.toLowerCase() === 'gem') {
    await gemSniperMode();
  } else {
    logger.info(`  Min volume: $${config.minVolume5m.toLocaleString()} | MCap: $${config.minMcap}-$${config.maxMcap.toLocaleString()}`);
    await discoverAndExecute();
    setInterval(() => {
      if (!isShuttingDown) discoverAndExecute();
    }, config.discoveryIntervalSec * 1000);
  }

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  logger.info('\nBot running. Ctrl+C to stop.\n');
}

main().catch((err) => {
  logger.error(`Fatal: ${err.message}`);
  console.error(err);
  process.exit(1);
});
