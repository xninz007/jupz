import config from '../config.js';
import { loadPool, getActiveBin, getUserPositions } from './liquidityManager.js';
import logger from './utils/logger.js';
import { shortenAddress, fetchTokenMetadata, fetchTokenPrices, formatHuman } from './utils/helpers.js';

const SOL_MINT = 'So11111111111111111111111111111111111111112';

// Track deposit cost per pool in USD (locked at deposit time)
const depositTracker = new Map();    // poolAddress -> USD value

// Track total claimed fees per pool in USD
const claimedFeesTracker = new Map(); // poolAddress -> USD value

// Track swap-only deposits for Mode 5 (Swap Sniper)
const swapDepositTracker = new Map(); // tokenMint -> USD value

/**
 * Record a deposit for PnL tracking.
 * Fetch SOL price saat ini dan lock sebagai deposit cost USD.
 */
export async function trackDeposit(poolAddress, solLamports) {
  const prices = await fetchTokenPrices([SOL_MINT]);
  const solPrice = prices[SOL_MINT] || 0;
  const usd = (solLamports / 1e9) * solPrice;
  const current = depositTracker.get(poolAddress) || 0;
  depositTracker.set(poolAddress, current + usd);
  logger.info(`[Deposit] ${poolAddress.slice(0, 8)}... locked at $${usd.toFixed(4)} (SOL=$${solPrice.toFixed(2)})`);
}

/**
 * Record claimed fees in USD (kumulatif per pool).
 */
export function trackClaimedFees(poolAddress, usdAmount) {
  const current = claimedFeesTracker.get(poolAddress) || 0;
  claimedFeesTracker.set(poolAddress, current + usdAmount);
}

/**
 * Clear tracking data saat pool di-remove.
 */
export function clearPoolTracking(poolAddress) {
  depositTracker.delete(poolAddress);
  claimedFeesTracker.delete(poolAddress);
}

/**
 * Record a swap-only deposit for Mode 5 PnL tracking.
 * Lock SOL price saat swap sebagai deposit cost USD.
 */
export async function trackSwapDeposit(tokenMint, solLamports) {
  const prices = await fetchTokenPrices([SOL_MINT]);
  const solPrice = prices[SOL_MINT] || 0;
  const usd = (solLamports / 1e9) * solPrice;
  swapDepositTracker.set(tokenMint, usd);
  logger.info(`[SwapDeposit] ${tokenMint.slice(0, 8)}... locked at $${usd.toFixed(4)} (SOL=$${solPrice.toFixed(2)})`);
}

/**
 * Get deposit USD for a swap-only position (Mode 5).
 */
export function getSwapDepositUSD(tokenMint) {
  return swapDepositTracker.get(tokenMint) || 0;
}

/**
 * Clear swap tracking data saat token di-sell.
 */
export function clearSwapTracking(tokenMint) {
  swapDepositTracker.delete(tokenMint);
}

/**
 * Get full status for a pool including active bin, positions, and PnL.
 */
export async function getPoolStatus(poolAddress) {
  const dlmmPool = await loadPool(poolAddress);
  const { binId, price } = await getActiveBin(dlmmPool);
  const positions = await getUserPositions(dlmmPool);

  const mintX = dlmmPool.lbPair.tokenXMint.toBase58();
  const mintY = dlmmPool.lbPair.tokenYMint.toBase58();

  // Fetch metadata & prices
  const metadata = await fetchTokenMetadata([mintX, mintY]);
  const metaX = metadata[mintX] || { symbol: 'X', decimals: 9 };
  const metaY = metadata[mintY] || { symbol: 'Y', decimals: 9 };

  const prices = await fetchTokenPrices([mintX, mintY]);
  const priceX = prices[mintX] || 0;
  const priceY = prices[mintY] || 0;

  const positionDetails = positions.map((pos) => {
    const bins = pos.positionData.positionBinData;
    const binIds = bins.map((b) => b.binId);
    const minBin = binIds.length > 0 ? Math.min(...binIds) : 0;
    const maxBin = binIds.length > 0 ? Math.max(...binIds) : 0;
    const inRange = binId >= minBin && binId <= maxBin;
    const oorSide = inRange ? null : (binId < minBin ? 'LEFT' : 'RIGHT');

    let totalX = BigInt(0);
    let totalY = BigInt(0);
    let feeX = BigInt(0);
    let feeY = BigInt(0);

    for (const bin of bins) {
      totalX += BigInt(bin.positionXAmount?.toString() || '0');
      totalY += BigInt(bin.positionYAmount?.toString() || '0');
    }

    if (pos.positionData.feeX) feeX = BigInt(pos.positionData.feeX.toString());
    if (pos.positionData.feeY) feeY = BigInt(pos.positionData.feeY.toString());

    // Hitung USD value
    const valueX = (Number(totalX) / 10 ** metaX.decimals) * priceX;
    const valueY = (Number(totalY) / 10 ** metaY.decimals) * priceY;
    const feeValueX = (Number(feeX) / 10 ** metaX.decimals) * priceX;
    const feeValueY = (Number(feeY) / 10 ** metaY.decimals) * priceY;

    const relMin = minBin - binId;
    const relMax = maxBin - binId;

    return {
      publicKey: pos.publicKey.toBase58(),
      range: `${relMin} - ${relMax}`,
      inRange,
      oorSide,
      totalX, totalY,
      feeX, feeY,
      binCount: binIds.length,
      valueUSD: valueX + valueY,
      feeUSD: feeValueX + feeValueY,
    };
  });

  // Total value & fees across all positions
  const totalValueUSD = positionDetails.reduce((sum, p) => sum + p.valueUSD, 0);
  const totalFeeUSD = positionDetails.reduce((sum, p) => sum + p.feeUSD, 0);

  // Deposit cost (sudah di-lock dalam USD saat deposit)
  const depositUSD = depositTracker.get(poolAddress) || 0;

  // Claimed fees (kumulatif USD dari semua claim sebelumnya)
  const claimedFeesUSD = claimedFeesTracker.get(poolAddress) || 0;

  // PnL = (posisi value + pending fees + claimed fees) - deposit cost
  const pnlUSD = (totalValueUSD + totalFeeUSD + claimedFeesUSD) - depositUSD;
  const pnlPercent = depositUSD > 0 ? (pnlUSD / depositUSD) * 100 : 0;

  return {
    poolAddress,
    activeBinId: binId,
    price,
    mintX, mintY,
    metaX, metaY,
    priceX, priceY,
    positions: positionDetails,
    totalValueUSD,
    totalFeeUSD,
    claimedFeesUSD,
    depositUSD,
    pnlUSD,
    pnlPercent,
  };
}

/**
 * Print dashboard for all monitored pools.
 */
export async function printDashboard(poolAddresses) {
  console.log('\n' + '='.repeat(70));
  console.log('  DLMM BOT DASHBOARD');
  console.log('  ' + new Date().toISOString());
  console.log('='.repeat(70));

  let grandValue = 0;
  let grandFees = 0;
  let grandClaimed = 0;
  let grandDeposit = 0;

  for (const addr of poolAddresses) {
    try {
      const s = await getPoolStatus(addr);

      console.log(`\n  Pool: ${shortenAddress(addr)} | ${s.metaX.symbol}/${s.metaY.symbol}`);
      console.log(`  Active Bin: ${s.activeBinId} | Price: ${s.price}`);
      console.log(`  ${s.metaX.symbol}: $${s.priceX.toFixed(6)} | ${s.metaY.symbol}: $${s.priceY.toFixed(6)}`);
      console.log(`  Positions: ${s.positions.length}`);

      if (s.positions.length === 0) {
        console.log('    (no positions)');
        continue;
      }

      for (const pos of s.positions) {
        const rangeTag = pos.inRange
          ? '\x1b[32mIN RANGE\x1b[0m'
          : `\x1b[31mOOR ${pos.oorSide}\x1b[0m`;
        console.log(`    Position ${shortenAddress(pos.publicKey)} [${rangeTag}]`);
        console.log(`      Range: bin ${pos.range} (${pos.binCount} bins)`);
        console.log(`      ${s.metaX.symbol}: ${formatHuman(pos.totalX.toString(), s.metaX.decimals)} ($${pos.valueUSD > 0 ? (((Number(pos.totalX) / 10 ** s.metaX.decimals) * s.priceX)).toFixed(4) : '0'})`);
        console.log(`      ${s.metaY.symbol}: ${formatHuman(pos.totalY.toString(), s.metaY.decimals)} ($${pos.valueUSD > 0 ? (((Number(pos.totalY) / 10 ** s.metaY.decimals) * s.priceY)).toFixed(4) : '0'})`);
        console.log(`      Value: $${pos.valueUSD.toFixed(4)} | Fees: $${pos.feeUSD.toFixed(4)}`);
      }

      // Pool PnL summary
      const pnlColor = s.pnlUSD >= 0 ? '\x1b[32m' : '\x1b[31m';
      const pnlSign = s.pnlUSD >= 0 ? '+' : '';
      console.log(`    ─────────────────────────────────────────────`);
      console.log(`    Total Value: $${s.totalValueUSD.toFixed(4)} | Pending Fees: $${s.totalFeeUSD.toFixed(4)}`);
      console.log(`    Claimed Fees: $${s.claimedFeesUSD.toFixed(4)}`);
      console.log(`    Deposit:     $${s.depositUSD.toFixed(4)} (locked at deposit)`);
      console.log(`    PnL:         ${pnlColor}${pnlSign}$${s.pnlUSD.toFixed(4)} (${pnlSign}${s.pnlPercent.toFixed(2)}%)\x1b[0m`);

      grandValue += s.totalValueUSD;
      grandFees += s.totalFeeUSD;
      grandClaimed += s.claimedFeesUSD;
      grandDeposit += s.depositUSD;
    } catch (err) {
      logger.error(`Failed to get status for pool ${shortenAddress(addr)}: ${err.message}`);
    }
  }

  // Grand total
  if (poolAddresses.length > 1) {
    const grandPnl = (grandValue + grandFees + grandClaimed) - grandDeposit;
    const grandPnlPct = grandDeposit > 0 ? (grandPnl / grandDeposit) * 100 : 0;
    const gc = grandPnl >= 0 ? '\x1b[32m' : '\x1b[31m';
    const gs = grandPnl >= 0 ? '+' : '';

    console.log('\n  ' + '─'.repeat(47));
    console.log(`  TOTAL | Value: $${grandValue.toFixed(4)} | Pending: $${grandFees.toFixed(4)} | Claimed: $${grandClaimed.toFixed(4)}`);
    console.log(`  TOTAL | Deposit: $${grandDeposit.toFixed(4)}`);
    console.log(`  TOTAL | PnL: ${gc}${gs}$${grandPnl.toFixed(4)} (${gs}${grandPnlPct.toFixed(2)}%)\x1b[0m`);
  }

  console.log('\n' + '='.repeat(70) + '\n');
}
