import { PublicKey, Keypair, SystemProgram } from '@solana/web3.js';
import { createRequire } from 'module';
import config from '../config.js';
import { getConnection, getWallet } from './connection.js';
import logger from './utils/logger.js';
import { retry, shortenAddress, formatSOL, resolveBinRange, getRandomJitoTipAccount, sendTransactionToJito } from './utils/helpers.js';

const require = createRequire(import.meta.url);
const DLMMModule = require('@meteora-ag/dlmm');
const DLMM = DLMMModule.default || DLMMModule;
const { StrategyType } = require('@meteora-ag/dlmm');

export { DLMM, StrategyType };
const { BN } = require('bn.js');

// ============================================================
//  POOL & POSITION HELPERS
// ============================================================

/**
 * Load a DLMM pool instance by address.
 */
export async function loadPool(poolAddress) {
  const connection = getConnection();
  const dlmmPool = await DLMM.create(connection, new PublicKey(poolAddress));
  return dlmmPool;
}

/**
 * Get on-chain pool info (binStep, baseFee, mints).
 * Used by Sniper mode when Rocketscan hasn't indexed the pool yet.
 *
 * @param {string} poolAddress
 * @returns {Promise<{binStep: number, baseFeePercent: number, tokenXMint: string, tokenYMint: string}>}
 */
export async function getPoolOnChainInfo(poolAddress) {
  const dlmmPool = await loadPool(poolAddress);
  const binStep = dlmmPool.lbPair.binStep;
  const baseFactor = dlmmPool.lbPair.parameters.baseFactor;
  const baseFeeBps = (baseFactor * binStep) / 10000;
  const baseFeePercent = baseFeeBps / 100;
  return {
    binStep,
    baseFeePercent,
    tokenXMint: dlmmPool.lbPair.tokenXMint.toBase58(),
    tokenYMint: dlmmPool.lbPair.tokenYMint.toBase58(),
  };
}

/**
 * Get the current active bin for a pool.
 */
export async function getActiveBin(dlmmPool) {
  const activeBin = await dlmmPool.getActiveBin();
  const price = dlmmPool.fromPricePerLamport(Number(activeBin.price));
  return { binId: activeBin.binId, price };
}

/**
 * Get user positions for a specific pool.
 */
export async function getUserPositions(dlmmPool) {
  const wallet = getWallet();
  const { userPositions } = await dlmmPool.getPositionsByUserAndLbPair(wallet.publicKey);
  return userPositions;
}

/**
 * Check if the active bin is within the user's position range.
 */
function isInRange(position, activeBinId) {
  const binIds = position.positionData.positionBinData.map((b) => b.binId);
  if (binIds.length === 0) return false;
  const minBin = Math.min(...binIds);
  const maxBin = Math.max(...binIds);
  return activeBinId >= minBin && activeBinId <= maxBin;
}

// ============================================================
//  JITO / RPC SEND HELPER
// ============================================================

/**
 * Send transaction via Jito (jika jitoTipLamports > 0) atau RPC biasa.
 * Menambahkan Jito tip instruction ke transaction sebelum sign & send.
 */
async function sendTx(tx, signers) {
  const connection = getConnection();
  const wallet = getWallet();
  const useJito = config.jitoTipLamports > 0;

  if (useJito) {
    // Tambah Jito tip instruction
    tx.add(
      SystemProgram.transfer({
        fromPubkey: wallet.publicKey,
        toPubkey: getRandomJitoTipAccount(),
        lamports: config.jitoTipLamports,
      })
    );

    // Set blockhash & feePayer
    const blockhash = await connection.getLatestBlockhash('confirmed');
    tx.recentBlockhash = blockhash.blockhash;
    tx.feePayer = wallet.publicKey;

    // Sign
    tx.sign(...signers);

    // Send via Jito
    logger.info(`Sending via Jito (tip: ${config.jitoTipLamports} lamports)...`);
    const sig = await sendTransactionToJito(tx.serialize());

    // Confirm
    await connection.confirmTransaction(
      { signature: sig, blockhash: blockhash.blockhash, lastValidBlockHeight: blockhash.lastValidBlockHeight },
      'confirmed'
    );
    return sig;
  } else {
    // Send via RPC biasa
    const sig = await connection.sendTransaction(tx, signers, { skipPreflight: false });
    await connection.confirmTransaction(sig, 'confirmed');
    return sig;
  }
}

// ============================================================
//  BIN ARRAY CHECK - JANGAN ADD LIQUIDITY JIKA BINS BELUM DIBAYAR
// ============================================================

/**
 * Cek apakah bin arrays yang dibutuhkan sudah ada (sudah dibayar).
 * Pakai SDK initializeBinArrays() — cek on-chain mana yang belum exist.
 *
 * MAX_BIN_ARRAY_SIZE = 70 (dari SDK)
 * binArrayIndex = floor(binId / 70), dengan floor untuk negatif
 *
 * @param {DLMM} dlmmPool
 * @param {number} minBinId
 * @param {number} maxBinId
 * @returns {Promise<{safe: boolean, totalBins: number, newBinArrays: number, costSOL: number}>}
 */
export async function checkBinArrays(dlmmPool, minBinId, maxBinId) {
  const totalBins = maxBinId - minBinId + 1;
  const MAX_BIN_ARRAY_SIZE = 70; // dari SDK @meteora-ag/dlmm

  try {
    // Hitung bin array indexes yang dibutuhkan (pakai formula SDK)
    const neededIndices = new Set();
    for (let binId = minBinId; binId <= maxBinId; binId++) {
      const bnBinId = new BN(binId);
      const { div: idx, mod } = bnBinId.divmod(new BN(MAX_BIN_ARRAY_SIZE));
      const arrayIdx = bnBinId.isNeg() && !mod.isZero() ? idx.sub(new BN(1)) : idx;
      neededIndices.add(arrayIdx.toNumber());
    }

    // Pakai SDK initializeBinArrays — cek on-chain mana yang belum ada
    const wallet = getWallet();
    const binArrayIndexes = [...neededIndices].map((i) => new BN(i));
    const ixs = await dlmmPool.initializeBinArrays(binArrayIndexes, wallet.publicKey);

    // Jika tidak ada instructions → semua bin arrays sudah exist
    // initializeBinArrays return instructions + 1 compute unit ix, jadi cek > 1
    const newBinArrays = ixs.length > 0 ? ixs.length - 1 : 0; // minus compute unit ix
    const costSOL = newBinArrays * config.binArrayCostPerUnit;

    return {
      safe: newBinArrays === 0,
      totalBins,
      newBinArrays,
      costSOL,
    };
  } catch (err) {
    logger.error(`Bin array check failed: ${err.message}`);
    return { safe: false, totalBins, newBinArrays: -1, costSOL: -1 };
  }
}

// ============================================================
//  REMOVE LIQUIDITY
// ============================================================

async function removePosition(dlmmPool, position) {
  const wallet = getWallet();
  const binIds = position.positionData.positionBinData.map((b) => b.binId);
  const fromBinId = Math.min(...binIds);
  const toBinId = Math.max(...binIds);

  logger.info(`Removing liquidity from position ${shortenAddress(position.publicKey)} (${binIds.length} bins, range ${fromBinId}-${toBinId})`);

  const removeTxs = await dlmmPool.removeLiquidity({
    position: position.publicKey,
    user: wallet.publicKey,
    fromBinId,
    toBinId,
    bps: new BN(10000), // 100%
    shouldClaimAndClose: true,
  });

  const txArray = Array.isArray(removeTxs) ? removeTxs : [removeTxs];
  const validTxs = txArray.filter((tx) => tx != null);

  if (validTxs.length === 0) {
    throw new Error(`removeLiquidity returned empty TX for ${shortenAddress(position.publicKey)}`);
  }

  for (const tx of validTxs) {
    const sig = await sendTx(tx, [wallet]);
    logger.info(`Remove TX confirmed: ${sig}`);
  }
}

// ============================================================
//  ADD LIQUIDITY (WITH BIN ARRAY SAFETY CHECK)
// ============================================================

/**
 * Create a new position and add liquidity.
 * AKAN DI-BLOCK jika bins belum dibayar dan maxBinArrayCostSOL = 0.
 *
 * @param {DLMM} dlmmPool
 * @param {number} activeBinId
 * @param {BN} totalXAmount
 * @param {BN} totalYAmount
 * @returns {Promise<boolean>} true jika berhasil add, false jika di-skip
 */
async function createPosition(dlmmPool, activeBinId, totalXAmount, totalYAmount) {
  const wallet = getWallet();
  const connection = getConnection();

  const totalBins = resolveBinRange(config.binRange);

  // One-side deposit: tentukan arah range berdasarkan token mana yang di-deposit
  // Y deposit (SOL=Y) → range ke BAWAH active bin (maxBin = activeBin)
  // X deposit (SOL=X) → range ke ATAS active bin (minBin = activeBin)
  const isOneSideY = totalXAmount.isZero() && !totalYAmount.isZero();
  const isOneSideX = !totalXAmount.isZero() && totalYAmount.isZero();

  let minBinId, maxBinId;
  if (isOneSideY) {
    maxBinId = activeBinId;
    minBinId = activeBinId - (totalBins - 1);
  } else if (isOneSideX) {
    minBinId = activeBinId;
    maxBinId = activeBinId + (totalBins - 1);
  } else {
    const half = Math.floor(totalBins / 2);
    minBinId = activeBinId - half;
    maxBinId = minBinId + totalBins - 1;
  }

  // === BIN ARRAY SAFETY CHECK ===
  const binCheck = await checkBinArrays(dlmmPool, minBinId, maxBinId);

  logger.info(`Bin check: ${binCheck.totalBins} total bins | ${binCheck.newBinArrays} new bin arrays needed | Cost: ${binCheck.costSOL} SOL`);

  if (!binCheck.safe) {
    if (binCheck.costSOL > config.maxBinArrayCostSOL) {
      logger.warn(
        `SKIP ADD LIQUIDITY - Bins belum dibayar!` +
        ` ${binCheck.newBinArrays} new bin array(s) x ${config.binArrayCostPerUnit} SOL = ${binCheck.costSOL} SOL (non-refundable).` +
        ` Max allowed: ${config.maxBinArrayCostSOL} SOL`
      );
      return false;
    }
    logger.warn(`Proceeding with ${binCheck.newBinArrays} new bin array(s) (cost: ${binCheck.costSOL} SOL)`);
  }

  logger.info(`Creating new position: bins ${minBinId} to ${maxBinId} (active: ${activeBinId})`);

  const newPositionKeypair = Keypair.generate();

  const createPositionTx = await dlmmPool.initializePositionAndAddLiquidityByStrategy({
    positionPubKey: newPositionKeypair.publicKey,
    user: wallet.publicKey,
    totalXAmount,
    totalYAmount,
    strategy: {
      maxBinId,
      minBinId,
      strategyType: StrategyType[config.strategy] || StrategyType.Spot,
    },
    slippage: config.slippageBps,
  });

  const sig = await sendTx(createPositionTx, [wallet, newPositionKeypair]);
  logger.info(`New position TX confirmed: ${sig}`);
  return true;
}

// ============================================================
//  REBALANCE
// ============================================================

/**
 * Main rebalance logic for a single pool.
 * Checks if active bin is in range; if not, removes old position and creates new one.
 * TIDAK AKAN add liquidity jika bins belum dibayar.
 */
export async function checkAndRebalance(poolAddress) {
  const dlmmPool = await loadPool(poolAddress);
  const { binId: activeBinId, price } = await getActiveBin(dlmmPool);
  logger.info(`Pool ${shortenAddress(poolAddress)} | Active bin: ${activeBinId} | Price: ${price}`);

  const positions = await getUserPositions(dlmmPool);

  if (positions.length === 0) {
    logger.info('No existing positions found. Skipping rebalance.');
    return;
  }

  for (const position of positions) {
    const inRange = isInRange(position, activeBinId);

    if (inRange) {
      const binIds = position.positionData.positionBinData.map((b) => b.binId);
      logger.info(`Position ${shortenAddress(position.publicKey)} is IN RANGE [${Math.min(...binIds)}-${Math.max(...binIds)}]`);
      continue;
    }

    logger.warn(`Position ${shortenAddress(position.publicKey)} is OUT OF RANGE. Rebalancing...`);

    // Get current amounts before removing
    const positionBins = position.positionData.positionBinData;
    let totalX = new BN(0);
    let totalY = new BN(0);
    for (const bin of positionBins) {
      totalX = totalX.add(new BN(bin.positionXAmount.toString()));
      totalY = totalY.add(new BN(bin.positionYAmount.toString()));
    }

    // Remove old position
    await retry(() => removePosition(dlmmPool, position), config.maxRetries);

    // Re-add around new active bin (HANYA jika bins sudah dibayar)
    if (totalX.gt(new BN(0)) || totalY.gt(new BN(0))) {
      const added = await retry(() => createPosition(dlmmPool, activeBinId, totalX, totalY), config.maxRetries);
      if (added) {
        logger.info('Rebalance complete!');
      } else {
        logger.warn('Rebalance: liquidity removed tapi TIDAK di-add ulang (bins belum dibayar)');
      }
    } else {
      logger.warn('Position had zero amounts after removal. Skipping re-add.');
    }
  }
}

/**
 * Add liquidity ke pool baru (setelah swap).
 * Cek bin arrays dulu sebelum add.
 *
 * @param {string} poolAddress
 * @param {BN} amountX
 * @param {BN} amountY
 * @returns {Promise<boolean>}
 */
export async function addLiquidityToPool(poolAddress, amountX, amountY) {
  const dlmmPool = await loadPool(poolAddress);
  const { binId: activeBinId, price } = await getActiveBin(dlmmPool);

  logger.info(`Adding liquidity to ${shortenAddress(poolAddress)} | Active bin: ${activeBinId} | Price: ${price}`);

  const added = await createPosition(dlmmPool, activeBinId, amountX, amountY);
  return added;
}

/**
 * Remove all liquidity from all positions in a pool.
 */
export async function removeAllLiquidity(poolAddress) {
  const dlmmPool = await loadPool(poolAddress);
  const positions = await getUserPositions(dlmmPool);

  if (positions.length === 0) {
    logger.info('No positions to remove.');
    return;
  }

  for (const position of positions) {
    await retry(() => removePosition(dlmmPool, position), config.maxRetries);
  }

  // Verifikasi posisi benar-benar sudah di-remove
  const dlmmPoolAfter = await loadPool(poolAddress);
  const remaining = await getUserPositions(dlmmPoolAfter);
  if (remaining.length > 0) {
    logger.warn(`${remaining.length} position(s) masih tersisa setelah remove — akan di-retry`);
    throw new Error(`removeAllLiquidity incomplete: ${remaining.length} positions still exist`);
  }

  logger.info(`Removed all ${positions.length} positions from pool ${shortenAddress(poolAddress)}`);
}

// ============================================================
//  COPY TRADE HELPERS
// ============================================================

/**
 * Infer strategy type from on-chain position bin data distribution.
 * Strategy is NOT stored on-chain, so we analyze liquidity distribution.
 *
 * @param {Array} positionBinData - array of { binId, positionXAmount, positionYAmount }
 * @returns {string} 'Spot' | 'Curve' | 'BidAsk'
 */
export function inferStrategy(positionBinData) {
  if (!positionBinData || positionBinData.length <= 3) return 'Spot';

  const sorted = [...positionBinData].sort((a, b) => a.binId - b.binId);
  const n = sorted.length;

  // Calculate per-bin liquidity and detect one-side deposit
  let totalX = 0n, totalY = 0n;
  const liqPerBin = sorted.map((b) => {
    const x = BigInt(b.positionXAmount?.toString() || '0');
    const y = BigInt(b.positionYAmount?.toString() || '0');
    totalX += x;
    totalY += y;
    return x + y;
  });

  const avg = (arr) => arr.length > 0 ? arr.reduce((a, b) => a + b, 0n) / BigInt(arr.length) : 0n;
  const third = Math.max(1, Math.floor(n / 3));

  // Detect one-side deposit: which token dominates?
  // One-side Y (SOL=Y): active bin at RIGHT end (maxBinId)
  // One-side X (SOL=X): active bin at LEFT end (minBinId)
  const isOneSideY = totalX === 0n || (totalY > 0n && totalX * 100n <= totalY * 3n);
  const isOneSideX = totalY === 0n || (totalX > 0n && totalY * 100n <= totalX * 3n);

  if (isOneSideY || isOneSideX) {
    // For one-side: compare near-active vs far-from-active
    // BidAsk = far from active is heavier
    // Curve  = near active is heavier
    // Spot   = flat
    let nearActiveBins, farFromActiveBins;
    if (isOneSideY) {
      // Active at right → near = last third, far = first third
      nearActiveBins = liqPerBin.slice(n - third);
      farFromActiveBins = liqPerBin.slice(0, third);
    } else {
      // Active at left → near = first third, far = last third
      nearActiveBins = liqPerBin.slice(0, third);
      farFromActiveBins = liqPerBin.slice(n - third);
    }

    const avgNear = avg(nearActiveBins);
    const avgFar = avg(farFromActiveBins);

    if (avgNear === 0n && avgFar === 0n) return 'Spot';
    if (avgNear === 0n) return 'BidAsk';
    if (avgFar === 0n) return 'Curve';

    // ratio > 150 = far 1.5x heavier → BidAsk
    // ratio < 70  = near 1.5x heavier → Curve
    const ratio = Number((avgFar * 100n) / avgNear);
    if (ratio > 150) return 'BidAsk';
    if (ratio < 70) return 'Curve';
    return 'Spot';
  }

  // Two-side deposit: use center vs edge comparison
  const centerStart = Math.floor(n * 0.3);
  const centerEnd = Math.ceil(n * 0.7);
  const centerBins = liqPerBin.slice(centerStart, centerEnd);
  const leftEdgeBins = liqPerBin.slice(0, Math.floor(n * 0.3));
  const rightEdgeBins = liqPerBin.slice(Math.ceil(n * 0.7));

  if (centerBins.length === 0) return 'Spot';

  const avgCenter = avg(centerBins);
  const maxEdgeAvg = (() => {
    const l = avg(leftEdgeBins);
    const r = avg(rightEdgeBins);
    return l > r ? l : r;
  })();

  if (avgCenter === 0n && maxEdgeAvg === 0n) return 'Spot';
  if (avgCenter === 0n) return 'BidAsk';
  if (maxEdgeAvg === 0n) return 'Curve';

  const edgeRatio = Number((maxEdgeAvg * 100n) / avgCenter);
  if (edgeRatio > 150) return 'BidAsk';
  if (edgeRatio < 70) return 'Curve';
  return 'Spot';
}

/**
 * Get all DLMM positions for a target wallet.
 * Wrapper around DLMM.getAllLbPairPositionsByUser.
 *
 * @param {PublicKey} walletPubkey
 * @returns {Promise<Map<string, object>>} Map<poolAddress, PositionInfo>
 */
export async function getTargetPositions(walletPubkey) {
  const connection = getConnection();
  const positionsMap = await DLMM.getAllLbPairPositionsByUser(connection, walletPubkey);
  return positionsMap;
}

/**
 * Add liquidity with explicit bin range and strategy (for copy trade).
 * Bypasses config binRange — uses the target's bin range directly.
 *
 * @param {string} poolAddress
 * @param {number} minBinId
 * @param {number} maxBinId
 * @param {string} strategyType - 'Spot' | 'Curve' | 'BidAsk'
 * @param {BN} amountX
 * @param {BN} amountY
 * @returns {Promise<boolean>} true if added successfully
 */
export async function addLiquidityWithBinRange(poolAddress, minBinId, maxBinId, strategyType, amountX, amountY) {
  const dlmmPool = await loadPool(poolAddress);
  const wallet = getWallet();

  // Bin array safety check
  const binCheck = await checkBinArrays(dlmmPool, minBinId, maxBinId);
  logger.info(`[CopyTrade] Bin check: ${binCheck.totalBins} bins | ${binCheck.newBinArrays} new arrays | Cost: ${binCheck.costSOL} SOL`);

  if (!binCheck.safe) {
    if (binCheck.costSOL > config.maxBinArrayCostSOL) {
      logger.warn(
        `[CopyTrade] SKIP — Bin array cost ${binCheck.costSOL} SOL > max ${config.maxBinArrayCostSOL} SOL`
      );
      return false;
    }
    logger.warn(`[CopyTrade] Proceeding with ${binCheck.newBinArrays} new bin array(s) (cost: ${binCheck.costSOL} SOL)`);
  }

  logger.info(`[CopyTrade] Creating position: bins ${minBinId} to ${maxBinId} | Strategy: ${strategyType}`);

  const newPositionKeypair = Keypair.generate();

  const createPositionTx = await dlmmPool.initializePositionAndAddLiquidityByStrategy({
    positionPubKey: newPositionKeypair.publicKey,
    user: wallet.publicKey,
    totalXAmount: amountX,
    totalYAmount: amountY,
    strategy: {
      maxBinId,
      minBinId,
      strategyType: StrategyType[strategyType] || StrategyType.Spot,
    },
    slippage: config.slippageBps,
  });

  const sig = await sendTx(createPositionTx, [wallet, newPositionKeypair]);
  logger.info(`[CopyTrade] Position TX confirmed: ${sig}`);
  return true;
}
