import { Connection, Keypair } from '@solana/web3.js';
import bs58 from 'bs58';
import config from '../config.js';
import logger from './utils/logger.js';

let connection;
let wallet;

/**
 * Initialize Solana connection and wallet from env.
 */
export function init() {
  const privateKey = process.env.PRIVATE_KEY;
  if (!privateKey) {
    throw new Error('PRIVATE_KEY not found in .env');
  }

  connection = new Connection(config.rpcUrl, 'confirmed');
  wallet = Keypair.fromSecretKey(bs58.decode(privateKey));

  logger.info(`Wallet loaded: ${wallet.publicKey.toBase58()}`);
  logger.info(`RPC: ${config.rpcUrl}`);

  return { connection, wallet };
}

/**
 * Get the initialized connection.
 */
export function getConnection() {
  if (!connection) throw new Error('Connection not initialized. Call init() first.');
  return connection;
}

/**
 * Get the initialized wallet keypair.
 */
export function getWallet() {
  if (!wallet) throw new Error('Wallet not initialized. Call init() first.');
  return wallet;
}
