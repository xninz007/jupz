import 'dotenv/config';

const config = {
  // Solana RPC
  rpcUrl: process.env.RPC_URL || '',

  // Strategy
  strategy: 'Spot',           // StrategyType: Spot, Curve, BidAsk
  binRange: 'full',             // Bin range: 'full' (70), 'half' (35), 'tight' (10), bisa masukkin manual contoh 50
  slippageBps: 700,            // Slippage tolerance dalam basis points (300 = 3%) ganti sesuai keinginan

  // Deposit & Swap
  depositAmountSOL: 5,      // Jumlah SOL per deposit LP (one-side)
  priorityFeeLamports: 4_000_000, // Priority fee untuk Jupiter swap

  // Jito
  jitoTipLamports: 100_000,    // Jito tip dalam lamports (0 = disable Jito, pakai RPC biasa)

  // Rebalance
  rebalance: false,            // true = auto rebalance, false = nonaktif

  // Auto Claim
  autoClaim: true,            // true = claim fees berkala, false = nonaktif (fees otomatis ikut saat remove liq)
  autoClaimAndSwap: true,     // true = otomatis swap token fee X ke SOL setelah claim
  claimLM: false,             // true = claim LM rewards juga, false = hanya swap fees

  // Intervals (menit)
  rebalanceIntervalMin: 5,     // Cek rebalance setiap X menit
  claimIntervalMin: 1,        // Claim rewards setiap Y menit (hanya jika autoClaim: true)
  monitorIntervalSec: 9,      // Monitor status setiap Z detik
  discoveryIntervalSec: 13,    // Scan token baru setiap X detik

  // Retry
  maxRetries: 3,               // Maks retry untuk add/remove/claim/swap (0 = no retry)

  // Pool Discovery - Jupiter Top Traded
  minVolume5m: 200_000,        // Minimum volume 5 menit USD untuk filter token
  topPoolCount: 10,            // Jumlah top token/pool yang diproses per discovery cycle

  // Pool Filter (hanya pool yang sudah indexed Meteora)
  minBinStep: 80,              // Minimum bin step (80 ke atas)
  minBaseFee: 1,               // Minimum base fee percentage (1 = 1%)

  // MCap filter
  minMcap: 0,                  // Minimum market cap (0 = no limit)
  maxMcap: 7_777_777,         // Maximum market cap ($21M default, 0 = no limit)

  // Liquidity filter (dari Jupiter API, total liquidity token)
  minLiquidity: 0,             // Minimum liquidity USD (0 = no limit)
  maxLiquidity: 0,             // Maximum liquidity USD (0 = no limit)

  // Jupiter API
  jupiterApiKey: process.env.JUPITER_API_KEY || '',

  // Rocketscan
  rocketscanUserId: process.env.ROCKETSCAN_USER_ID || '',

  // Blacklist
  blacklistTokens: [
    // Tambahkan mint address token yang mau di-skip
    '27G8MtK7VtTcCHkpASjSDdkWWYfoqT6ggEuKidVJidD4', // contoh: wSOL
  ],

  // Posisi
  maxActivePositions: 1,       // Maksimum posisi aktif bersamaan

  // Bin array cost protection
  maxBinArrayCostSOL: 0,       // Max SOL untuk biaya bin array baru (0 = JANGAN add jika ada bin baru)
  binArrayCostPerUnit: 0.07,   // Cost per bin array unit (SOL, non-refundable)

  // Out of Range handling
  oorRightWaitMin: 1,          // OUT OF RANGE kanan: tunggu X menit, jika tetap OOR → remove + re-add
  oorLeftAction: 'remove',     // OUT OF RANGE kiri: 'remove' = cabut liq + swap ke SOL

  // Take Profit & Stop Loss (% dari deposit)
  takeProfitPercent: 25,       // Auto remove + swap ke SOL jika PnL >= +10% (0 = disable)
  stopLossPercent: -50,         // Auto remove + swap ke SOL jika PnL <= -5% (0 = disable)

  // Cooldown setelah TP/SL hit (menit)
  cooldownHours: 1,             // Cooldown sebelum token bisa di-entry lagi (0 = permanent blacklist)

  // Trailing TP & SL (independent)
  trailingTP: true,             // true = trailing TP aktif, false = fixed TP
  trailingTPPercent: 20,         // Trail distance dari peak setelah TP hit (%)
                                 // Saat PnL >= TP → mulai trail. Exit jika turun trailingTPPercent dari peak
  trailingSL: false,             // true = trailing SL aktif, false = fixed SL
  trailingSLPercent: 20,         // Trail distance untuk SL (%)
                                 // SL naik ikut peak. Effective SL = peak - trailingSLPercent

  // Copy Trade (Mode 3)
  copyTradeWallet: process.env.COPY_TRADE_WALLET || '',
  copyTradeIntervalSec: 7,
  copyTradeOnlySOLPairs: true,
  copyTradeSkipCooldown: true,    // true = posisi copy trade skip cooldown saat TP/SL/OOR hit

  // Sniper Mode (Mode 4)
  sniperDepositSOL: 2,            // SOL untuk swap → token lalu deposit (terpisah dari depositAmountSOL)
  sniperMaxToken: 3,                // Max token aktif bersamaan di mode 4 (1 token = 1 pool = 1 posisi)
  sniperMaxMcap: 1_000_000,         // Max mcap untuk mode 4 (default 1M)
  sniperMinVolume5m: 50_000,        // Min volume 5m USD dari Jupiter (default 50K)
  sniperMinOrganicRatio: 5,        // Min organic volume ratio % (organic/total >= 10%) — 0 = disable
  sniperIntervalSec: 10,            // Polling interval (default 10s)
  sniperOorLeftWaitMin: 2,          // OOR LEFT: tunggu X menit sebelum remove + swap + blacklist (0 = langsung)

  // Gem Sniper Mode (Mode 6)
  gemSniperDepositSOL: 1,           // SOL per swap
  gemSniperMaxToken: 3,             // Max token aktif
  gemSniperIntervalSec: 15,         // Polling interval
  gemSniperTopHolders: 20,          // Jumlah top holders yang di-analyze
  gemSniperSmartWinRate: 50,        // Min winRate% untuk dianggap smart
  gemSniperMinTrades: 20,           // Min total trades (buys+sells) untuk dianggap smart (filter lucky wallets)
  gemSniperMinSmartPct: 40,         // Min % smart wallets dari top holders (0 = disable)
  gemSniperRequireDlmm: false,       // true = DLMM + bins paid wajib, false = skip DLMM check

  // Auto-remove on shutdown
  removeOnShutdown: true,     // Tarik semua liquidity saat bot dihentikan

  // Telegram Alert
  telegramAlert: true,        // true = kirim notifikasi ke Telegram
  telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || '',
  telegramChatId: process.env.TELEGRAM_CHAT_ID || '',
};

export default config;
